# Parser and verification method

Reads only two plan Markdown files, two queue JSON snapshots, signatureUnits.js and a bounded set of folder READMEs/runtime metadata. No asset blob inventory, asset downloads, model generation or repository changes.

- M parser: track `### Batch NN:` headings until `### Emblems by`; accept table rows beginning `| ` followed by a backtick id, split six columns, extract S1–S13 link. Assert 534 unique ids and equality with all current queue master-plan ids.
- Independent M 2D classifier: S1, S2, S3, S4, S10 and S12 = 293 rows. The other 241 rows become current-model aliases, explicit supersessions, or related-component references. A single S8 impostor is handled as a derived output; it does not silently change the headline classifier totals.
- Signature parser: match each one-line JS people object and exactly five quoted fields ageId, classId, model, rig, name; preserve escaped names, source line and actual runtime id. Assert 150 unique people and models, ages34/38/36/32/10, roles61/44/43/2.
- Model expansion: finite named ids/age/theme combinations from sections4–10. Use root plus bundle identity, not file count. Every provisional expansion retains a reason. D10 coverage rows are finite explicit filename requirements kept out of append_items.
- Legacy reconciliation: preserve original queue JSON objects, top-level fields and completed_checkpoints; per-record non-destructive annotations record canonical ids and dispositions. Eleven unit culture records point to one newly appended Merkava job; map culture dressings stay. Settlers alias shared workers. No delivery status is rewritten.
- Source comparison: read art HEAD queue with git show because the worktree is unmaterialized. At this snapshot both contain 884 identical item objects. All source hashes/revisions are recorded; integration is an additive merge against a freshly read queue, not replacement.
- Hand checks: base units31; commanders/raiders/mercenaries15; signature units150; mounts6; original RTS73 plus optional house5; damage65; walls5; ruins5; shared forts5; palace damage5; wonder ruins17; nodes4/herds2/vegetation7; independents12+5; ships5+4+4+1; model effects22; named town gap jobs65 plus ground meshes5.
- Artifact granularity: required roots, states and sockets are nested requirements. A shared rts-age bundle does not become fourteen separate GLBs; a damaged-and-ruined house file is one job containing exact kit-derived roots. File-only wildcard counts and invented numbered unspecified farm sets are rejected.

Output extensions are JSON and Markdown only, entirely inside this draft directory.

Final checks also enumerate the shared neutral-body task, preserve six shared module/VAT/person-frame-tank infrastructure dependencies separately, verify all1458 production ids and444 presence ids are in Markdown, and verify603 non-colliding append paths.
