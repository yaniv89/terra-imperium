# Supplemental method and limits

A bounded automatic parser reuses the explicitly enumerated first draft, then refines it using a single integration `git ls-tree -r --name-only <revision>` filename listing. Only asset/public/art-plan prefixes are saved; the full listing count and SHA256 are recorded. No GLB, texture, blend or other asset contents are read.

Presence is exact filename membership for files and descendant filename presence for directory targets. Git metadata does not cover untracked outputs, remote uploads, the parent scratch or current roots/materials/UVs/LODs. Queue uploaded/built statuses are independent evidence and are never rewritten. Filename absence alone never forces replacement geometry when a recorded delivery exists.

Current required scope excludes retained-history jobs, dropped culture-unit tasks, superseded M3D aliases and unproved improvement age multiplication. File/root binding caveats are separated from optional scope and matrix ambiguity: especially300 culture variants are explicit requirements, not speculative models. The inherited body/mount source and exact house-root binding caveats stay in metadata. Wonder roots are rebound to tracked integration wonder GLBs.

Tech metadata parsing: extract eleven requiresTech values from IMPROVEMENTS; map category line names to slug ids and age via the actual Math.floor(i / 2) tech generator and AGE_ORDER. All eight ordinary kinds become eligible by Bronze; oil is Modern-only; road has no gate; fort is Classical. Eligibility is not a five-model production matrix. Existing ancient/modern pairs are retained; shared variants can be reused.

Hand-checked cardinalities: 16 town styles x 5 ages x 3 sizes x 2 variants =480, plus four Europenorth Classical medium/big variants =484. Forty named outputs are disjoint from the remaining444. 370+74=444; 30+10=40; 400+84=484. Two absent outputs are built deliveries; 82 absent outputs lack that evidence.

Required-index accounting: 1458 original production/history rows -249 history rows -29 speculative base-age rows -30 speculative variant-age rows -5 optional house rows -1 legacy overlay +444 resolved coverage rows =1588. Holds: five optional houses +one overlay +six unresolved named families =12. Known-scope variants300, signature roster150, base improvements12, forts5. Original25 built records split17 current-required and8 history-only. Missing-target820 rows collapse to757 unique bindings (443 3D,314 2D); this is a declared-target count, not an inventory of source geometry.

Wave assignments remain from the attachment and first draft: 0 existing25 validation,1 Bronze,2 MAP,3 Classical,4 Kingdoms,5 Gunpowder,6 Modern,7 remaining/culture skins,8 independent 2D M work. New model sheets precede geometry in each wave; no approval stops. Root-level jobs inside shared bundles and 2D shader/effect companions are not merged merely because descriptions resemble one another. The ai-battle-smoke related-output pair remains a documented loader/binding ambiguity.

The supplemental outputs supersede the first draft for scheduling only. Original884 queue records, historical delivery counters and completed checkpoints remain preserved. Parent integration must re-read live state; these are additive proposals, not production status updates.
