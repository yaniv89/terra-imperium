# Required current checklist and waves

This required-scope index is not a count of remaining models. Bundled roots, 2D jobs, tracked town files and verification work are distinct canonical requirements. Original history, dropped unit kits and duplicate M3D job records are excluded from scheduling.

| Canonical id | Kind | Wave | Work bucket | Required target/root binding |
|---|---|---:|---|---|
| `battle-city/bronze/americas/houses-damage` | 3d | 1 | definitive_missing_declared_target | src/assets/battle/city/bronze-americas-houses-damage.glb |
| `battle-city/bronze/base/houses-damage` | 3d | 1 | definitive_missing_declared_target | src/assets/battle/city/bronze-base-houses-damage.glb |
| `battle-city/bronze/eastafrica/houses-damage` | 3d | 1 | definitive_missing_declared_target | src/assets/battle/city/bronze-eastafrica-houses-damage.glb |
| `battle-city/bronze/europe/houses-damage` | 3d | 1 | definitive_missing_declared_target | src/assets/battle/city/bronze-europe-houses-damage.glb |
| `battle-city/bronze/indic/houses-damage` | 3d | 1 | definitive_missing_declared_target | src/assets/battle/city/bronze-indic-houses-damage.glb |
| `battle-city/bronze/israelite/houses-damage` | 3d | 1 | definitive_missing_declared_target | src/assets/battle/city/bronze-israelite-houses-damage.glb |
| `battle-city/bronze/levant/houses-damage` | 3d | 1 | definitive_missing_declared_target | src/assets/battle/city/bronze-levant-houses-damage.glb |
| `battle-city/bronze/maghreb/houses-damage` | 3d | 1 | definitive_missing_declared_target | src/assets/battle/city/bronze-maghreb-houses-damage.glb |
| `battle-city/bronze/monsoon/houses-damage` | 3d | 1 | definitive_missing_declared_target | src/assets/battle/city/bronze-monsoon-houses-damage.glb |
| `battle-city/bronze/nile/houses-damage` | 3d | 1 | definitive_missing_declared_target | src/assets/battle/city/bronze-nile-houses-damage.glb |
| `battle-city/bronze/ruin-library` | 3d | 1 | definitive_missing_declared_target | src/assets/battle/city/ruins-bronze.glb |
| `battle-city/bronze/sinic/houses-damage` | 3d | 1 | definitive_missing_declared_target | src/assets/battle/city/bronze-sinic-houses-damage.glb |
| `battle-city/bronze/steppe/houses-damage` | 3d | 1 | definitive_missing_declared_target | src/assets/battle/city/bronze-steppe-houses-damage.glb |
| `battle-city/bronze/wall-kit` | 3d | 1 | definitive_missing_declared_target | src/assets/battle/city/walls-bronze.glb |
| `battle-city/bronze/westafrica/houses-damage` | 3d | 1 | definitive_missing_declared_target | src/assets/battle/city/bronze-westafrica-houses-damage.glb |
| `battle-terrain/bridge-wood` | 3d | 1 | definitive_missing_declared_target | src/assets/battle/terrain/bridge-wood.glb |
| `battle-terrain/ford` | 3d | 1 | definitive_missing_declared_target | src/assets/battle/terrain/ford.glb |
| `battle-terrain/river-kit` | 3d | 1 | definitive_missing_declared_target | src/assets/battle/terrain/river-kit.glb |
| `fort/bronze` | 3d | 1 | definitive_missing_declared_target | src/assets/battle/city/fort-bronze.glb; src/assets/map/improvements/fort-bronze.glb |
| `fx/dust-impact` | 2d | 1 | definitive_missing_declared_target | src/assets/fx/dust-impact/ |
| `fx/dust-march` | 2d | 1 | definitive_missing_declared_target | src/assets/fx/dust-march/ |
| `fx/fire-large` | 2d | 1 | definitive_missing_declared_target | src/assets/fx/fire-large/ |
| `fx/fire-small` | 2d | 1 | definitive_missing_declared_target | src/assets/fx/fire-small/ |
| `fx/impact-sparks` | 2d | 1 | definitive_missing_declared_target | src/assets/fx/impact-sparks/ |
| `fx/smoke-heavy` | 2d | 1 | definitive_missing_declared_target | src/assets/fx/smoke-heavy/ |
| `fx/smoke-light` | 2d | 1 | definitive_missing_declared_target | src/assets/fx/smoke-light/ |
| `ground-materials/desert-sand` | 2d | 1 | definitive_missing_declared_target | public/terrain/desert-sand/ |
| `ground-materials/dry-soil` | 2d | 1 | definitive_missing_declared_target | public/terrain/dry-soil/ |
| `ground-materials/grass` | 2d | 1 | definitive_missing_declared_target | public/terrain/grass/ |
| `ground-materials/paving` | 2d | 1 | definitive_missing_declared_target | public/terrain/paving/ |
| `ground-materials/rock` | 2d | 1 | definitive_missing_declared_target | public/terrain/rock/ |
| `ground-materials/snow` | 2d | 1 | definitive_missing_declared_target | public/terrain/snow/ |
| `ground-materials/steppe-grass` | 2d | 1 | definitive_missing_declared_target | public/terrain/steppe-grass/ |
| `ground-materials/wet-soil` | 2d | 1 | definitive_missing_declared_target | public/terrain/wet-soil/ |
| `nature/fish-shoal` | 3d | 1 | definitive_missing_declared_target | src/assets/battle/nature/fish-shoal.glb |
| `nature/gold-vein` | 3d | 1 | definitive_missing_declared_target | src/assets/battle/nature/gold-vein.glb |
| `nature/herd-cattle` | 3d | 1 | definitive_missing_declared_target | src/assets/battle/nature/herd-cattle.glb |
| `nature/herd-sheep-goat` | 3d | 1 | definitive_missing_declared_target | src/assets/battle/nature/herd-sheep-goat.glb |
| `nature/ore-outcrop` | 3d | 1 | definitive_missing_declared_target | src/assets/battle/nature/ore-outcrop.glb |
| `nature/stone-outcrop` | 3d | 1 | definitive_missing_declared_target | src/assets/battle/nature/stone-outcrop.glb |
| `nature/vegetation-desert` | 3d | 1 | definitive_missing_declared_target | src/assets/battle/nature/vegetation-desert.glb |
| `nature/vegetation-mediterranean` | 3d | 1 | definitive_missing_declared_target | src/assets/battle/nature/vegetation-mediterranean.glb |
| `nature/vegetation-temperate` | 3d | 1 | definitive_missing_declared_target | src/assets/battle/nature/vegetation-temperate.glb |
| `projectiles/bronze` | 3d | 1 | definitive_missing_declared_target | src/assets/battle/projectiles/bronze.glb |
| `props/bronze` | 3d | 1 | definitive_missing_declared_target | src/assets/battle/props/props-bronze.glb |
| `rts/bronze/aid-post` | 3d | 1 | definitive_missing_declared_target | src/assets/battle/rts/rts-bronze.glb |
| `rts/bronze/barracks` | 3d | 1 | definitive_missing_declared_target | src/assets/battle/rts/rts-bronze.glb |
| `rts/bronze/construction-set` | 3d | 1 | definitive_missing_declared_target | src/assets/battle/rts/rts-bronze.glb |
| `rts/bronze/expedition-camp` | 3d | 1 | definitive_missing_declared_target | src/assets/battle/rts/rts-bronze.glb |
| `rts/bronze/farm-plot` | 3d | 1 | definitive_missing_declared_target | src/assets/battle/rts/rts-bronze.glb |
| `rts/bronze/food-depot` | 3d | 1 | definitive_missing_declared_target | src/assets/battle/rts/rts-bronze.glb |
| `rts/bronze/materials-yard` | 3d | 1 | definitive_missing_declared_target | src/assets/battle/rts/rts-bronze.glb |
| `rts/bronze/mine` | 3d | 1 | definitive_missing_declared_target | src/assets/battle/rts/rts-bronze.glb |
| `rts/bronze/range` | 3d | 1 | definitive_missing_declared_target | src/assets/battle/rts/rts-bronze.glb |
| `rts/bronze/siege-workshop` | 3d | 1 | definitive_missing_declared_target | src/assets/battle/rts/rts-bronze.glb |
| `rts/bronze/stable` | 3d | 1 | definitive_missing_declared_target | src/assets/battle/rts/rts-bronze.glb |
| `rts/bronze/tower` | 3d | 1 | definitive_missing_declared_target | src/assets/battle/rts/rts-bronze.glb |
| `rts/bronze/town-hall` | 3d | 1 | definitive_missing_declared_target | src/assets/battle/rts/rts-bronze.glb |
| `rts/bronze/trade-post` | 3d | 1 | definitive_missing_declared_target | src/assets/battle/rts/rts-bronze.glb |
| `unit-rigs/chariot-heavy` | 3d | 1 | required_scope_binding_verification | binding unresolved; chariot-heavy |
| `unit-rigs/chariot-light` | 3d | 1 | required_scope_binding_verification | binding unresolved; chariot-light |
| `unit-rigs/horse` | 3d | 1 | required_scope_binding_verification | binding unresolved; horse |
| `unit-rigs/ox` | 3d | 1 | required_scope_binding_verification | binding unresolved; ox |
| `units/bronze-cavalry` | 3d | 1 | definitive_missing_declared_target | src/assets/units/bronze-cavalry.glb |
| `units/bronze-general` | 3d | 1 | definitive_missing_declared_target | src/assets/units/bronze-general.glb |
| `units/bronze-infantry` | 3d | 1 | definitive_missing_declared_target | src/assets/units/bronze-infantry.glb |
| `units/bronze-mercenary` | 3d | 1 | definitive_missing_declared_target | src/assets/units/bronze-mercenary.glb |
| `units/bronze-raider` | 3d | 1 | definitive_missing_declared_target | src/assets/units/bronze-raider.glb |
| `units/bronze-ranged` | 3d | 1 | definitive_missing_declared_target | src/assets/units/bronze-ranged.glb |
| `units/bronze-siege` | 3d | 1 | definitive_missing_declared_target | src/assets/units/bronze-siege.glb |
| `units/bronze-support` | 3d | 1 | definitive_missing_declared_target | src/assets/units/bronze-support.glb |
| `units/bronze-worker` | 3d | 1 | definitive_missing_declared_target | src/assets/units/bronze-worker.glb |
| `units/shared-neutral-body` | 3d | 1 | required_scope_binding_verification | binding unresolved; neutral-person-body |
| `units/signature/ahhiyawa` | 3d | 1 | definitive_missing_declared_target | src/assets/units/signature/ahhiyawa.glb |
| `units/signature/akkad` | 3d | 1 | definitive_missing_declared_target | src/assets/units/signature/akkad.glb |
| `units/signature/andronovo` | 3d | 1 | definitive_missing_declared_target | src/assets/units/signature/andronovo.glb |
| `units/signature/botai` | 3d | 1 | definitive_missing_declared_target | src/assets/units/signature/botai.glb |
| `units/signature/caral` | 3d | 1 | definitive_missing_declared_target | src/assets/units/signature/caral.glb |
| `units/signature/colchis` | 3d | 1 | definitive_missing_declared_target | src/assets/units/signature/colchis.glb |
| `units/signature/cucuteni` | 3d | 1 | definitive_missing_declared_target | src/assets/units/signature/cucuteni.glb |
| `units/signature/dilmun` | 3d | 1 | definitive_missing_declared_target | src/assets/units/signature/dilmun.glb |
| `units/signature/elam` | 3d | 1 | definitive_missing_declared_target | src/assets/units/signature/elam.glb |
| `units/signature/garamantes` | 3d | 1 | definitive_missing_declared_target | src/assets/units/signature/garamantes.glb |
| `units/signature/gojoseon` | 3d | 1 | definitive_missing_declared_target | src/assets/units/signature/gojoseon.glb |
| `units/signature/kanesh` | 3d | 1 | definitive_missing_declared_target | src/assets/units/signature/kanesh.glb |
| `units/signature/keftiu` | 3d | 1 | definitive_missing_declared_target | src/assets/units/signature/keftiu.glb |
| `units/signature/kemet` | 3d | 1 | definitive_missing_declared_target | src/assets/units/signature/kemet.glb |
| `units/signature/kerma` | 3d | 1 | definitive_missing_declared_target | src/assets/units/signature/kerma.glb |
| `units/signature/kuru` | 3d | 1 | definitive_missing_declared_target | src/assets/units/signature/kuru.glb |
| `units/signature/lapita` | 3d | 1 | definitive_missing_declared_target | src/assets/units/signature/lapita.glb |
| `units/signature/libu` | 3d | 1 | definitive_missing_declared_target | src/assets/units/signature/libu.glb |
| `units/signature/magan` | 3d | 1 | definitive_missing_declared_target | src/assets/units/signature/magan.glb |
| `units/signature/mari` | 3d | 1 | definitive_missing_declared_target | src/assets/units/signature/mari.glb |
| `units/signature/meluhha` | 3d | 1 | definitive_missing_declared_target | src/assets/units/signature/meluhha.glb |
| `units/signature/oxus` | 3d | 1 | definitive_missing_declared_target | src/assets/units/signature/oxus.glb |
| `units/signature/phrygia` | 3d | 1 | definitive_missing_declared_target | src/assets/units/signature/phrygia.glb |
| `units/signature/punt` | 3d | 1 | definitive_missing_declared_target | src/assets/units/signature/punt.glb |
| `units/signature/saurashtra` | 3d | 1 | definitive_missing_declared_target | src/assets/units/signature/saurashtra.glb |
| `units/signature/shang` | 3d | 1 | definitive_missing_declared_target | src/assets/units/signature/shang.glb |
| `units/signature/shu` | 3d | 1 | definitive_missing_declared_target | src/assets/units/signature/shu.glb |
| `units/signature/tartessos` | 3d | 1 | definitive_missing_declared_target | src/assets/units/signature/tartessos.glb |
| `units/signature/tichitt` | 3d | 1 | definitive_missing_declared_target | src/assets/units/signature/tichitt.glb |
| `units/signature/ugarit` | 3d | 1 | definitive_missing_declared_target | src/assets/units/signature/ugarit.glb |
| `units/signature/urartu` | 3d | 1 | definitive_missing_declared_target | src/assets/units/signature/urartu.glb |
| `units/signature/van-lang` | 3d | 1 | definitive_missing_declared_target | src/assets/units/signature/van-lang.glb |
| `units/signature/wahgi` | 3d | 1 | definitive_missing_declared_target | src/assets/units/signature/wahgi.glb |
| `units/signature/zhou` | 3d | 1 | definitive_missing_declared_target | src/assets/units/signature/zhou.glb |
| `independents/early/fortress-dressing` | 3d | 2 | definitive_missing_declared_target | src/assets/map/independents/early/fortress-dressing.glb |
| `independents/early/mercantile-dressing` | 3d | 2 | definitive_missing_declared_target | src/assets/map/independents/early/mercantile-dressing.glb |
| `independents/early/raiders-dressing` | 3d | 2 | definitive_missing_declared_target | src/assets/map/independents/early/raiders-dressing.glb |
| `independents/early/tribal-dressing` | 3d | 2 | definitive_missing_declared_target | src/assets/map/independents/early/tribal-dressing.glb |
| `independents/middle/fortress-dressing` | 3d | 2 | definitive_missing_declared_target | src/assets/map/independents/middle/fortress-dressing.glb |
| `independents/middle/mercantile-dressing` | 3d | 2 | definitive_missing_declared_target | src/assets/map/independents/middle/mercantile-dressing.glb |
| `independents/middle/raiders-dressing` | 3d | 2 | definitive_missing_declared_target | src/assets/map/independents/middle/raiders-dressing.glb |
| `independents/middle/tribal-dressing` | 3d | 2 | definitive_missing_declared_target | src/assets/map/independents/middle/tribal-dressing.glb |
| `independents/modern/fortress-dressing` | 3d | 2 | definitive_missing_declared_target | src/assets/map/independents/modern/fortress-dressing.glb |
| `independents/modern/mercantile-dressing` | 3d | 2 | definitive_missing_declared_target | src/assets/map/independents/modern/mercantile-dressing.glb |
| `independents/modern/raiders-dressing` | 3d | 2 | definitive_missing_declared_target | src/assets/map/independents/modern/raiders-dressing.glb |
| `independents/modern/tribal-dressing` | 3d | 2 | definitive_missing_declared_target | src/assets/map/independents/modern/tribal-dressing.glb |
| `independents/tribal-camp-cold` | 3d | 2 | definitive_missing_declared_target | src/assets/map/independents/tribal-camp-cold.glb |
| `independents/tribal-camp-desert` | 3d | 2 | definitive_missing_declared_target | src/assets/map/independents/tribal-camp-desert.glb |
| `independents/tribal-camp-forest` | 3d | 2 | definitive_missing_declared_target | src/assets/map/independents/tribal-camp-forest.glb |
| `independents/tribal-camp-steppe` | 3d | 2 | definitive_missing_declared_target | src/assets/map/independents/tribal-camp-steppe.glb |
| `independents/tribal-camp-tropical` | 3d | 2 | definitive_missing_declared_target | src/assets/map/independents/tribal-camp-tropical.glb |
| `map-improvements/bronze/camp` | 3d | 2 | recorded_built_delivery_validation | binding unresolved;  |
| `map-improvements/bronze/farm` | 3d | 2 | recorded_built_delivery_validation | binding unresolved;  |
| `map-improvements/bronze/fishing-boats` | 3d | 2 | recorded_built_delivery_validation | binding unresolved;  |
| `map-improvements/bronze/lumber-camp` | 3d | 2 | recorded_built_delivery_validation | binding unresolved;  |
| `map-improvements/bronze/mine` | 3d | 2 | recorded_built_delivery_validation | binding unresolved;  |
| `map-improvements/bronze/pasture` | 3d | 2 | recorded_built_delivery_validation | binding unresolved;  |
| `map-improvements/bronze/plantation` | 3d | 2 | recorded_built_delivery_validation | binding unresolved;  |
| `map-improvements/bronze/quarry` | 3d | 2 | recorded_built_delivery_validation | binding unresolved;  |
| `map-improvements/modern/farm` | 3d | 2 | recorded_built_delivery_validation | binding unresolved;  |
| `map-improvements/modern/fishing-boats` | 3d | 2 | recorded_built_delivery_validation | binding unresolved;  |
| `map-improvements/modern/mine` | 3d | 2 | recorded_built_delivery_validation | binding unresolved;  |
| `map-improvements/modern/oil-well` | 3d | 2 | required_scope_binding_verification | binding unresolved;  |
| `map-kits/europe/modern/houses` | 3d | 2 | recorded_uploaded_acceptance_verification | binding unresolved;  |
| `map-kits/europe/modern/landmark-1` | 3d | 2 | recorded_uploaded_acceptance_verification | binding unresolved;  |
| `map-kits/europe/modern/landmark-2` | 3d | 2 | recorded_uploaded_acceptance_verification | binding unresolved;  |
| `map-kits/europe/modern/roofscape` | 3d | 2 | recorded_uploaded_acceptance_verification | binding unresolved;  |
| `map-kits/europe/modern/street` | 3d | 2 | recorded_uploaded_acceptance_verification | binding unresolved;  |
| `map-kits/indic/gunpowder/houses` | 3d | 2 | recorded_uploaded_acceptance_verification | binding unresolved;  |
| `map-kits/indic/gunpowder/landmark-1` | 3d | 2 | recorded_uploaded_acceptance_verification | binding unresolved;  |
| `map-kits/indic/gunpowder/landmark-2` | 3d | 2 | recorded_uploaded_acceptance_verification | binding unresolved;  |
| `map-kits/indic/gunpowder/roofscape` | 3d | 2 | recorded_uploaded_acceptance_verification | binding unresolved;  |
| `map-kits/indic/gunpowder/street` | 3d | 2 | recorded_uploaded_acceptance_verification | binding unresolved;  |
| `map-kits/indic/modern/houses` | 3d | 2 | recorded_uploaded_acceptance_verification | binding unresolved;  |
| `map-kits/indic/modern/landmark-1` | 3d | 2 | recorded_uploaded_acceptance_verification | binding unresolved;  |
| `map-kits/indic/modern/landmark-2` | 3d | 2 | recorded_uploaded_acceptance_verification | binding unresolved;  |
| `map-kits/indic/modern/roofscape` | 3d | 2 | recorded_uploaded_acceptance_verification | binding unresolved;  |
| `map-kits/indic/modern/street` | 3d | 2 | recorded_uploaded_acceptance_verification | binding unresolved;  |
| `map-kits/levant/bronze/houses` | 3d | 2 | recorded_uploaded_acceptance_verification | binding unresolved;  |
| `map-kits/levant/bronze/landmark-1` | 3d | 2 | recorded_uploaded_acceptance_verification | binding unresolved;  |
| `map-kits/levant/bronze/landmark-2` | 3d | 2 | recorded_uploaded_acceptance_verification | binding unresolved;  |
| `map-kits/levant/bronze/roofscape` | 3d | 2 | recorded_uploaded_acceptance_verification | binding unresolved;  |
| `map-kits/levant/bronze/street` | 3d | 2 | recorded_uploaded_acceptance_verification | binding unresolved;  |
| `map-kits/steppe/modern/houses` | 3d | 2 | required_scope_binding_verification | binding unresolved;  |
| `map-kits/steppe/modern/landmark-1` | 3d | 2 | recorded_uploaded_acceptance_verification | binding unresolved;  |
| `map-kits/steppe/modern/landmark-2` | 3d | 2 | recorded_uploaded_acceptance_verification | binding unresolved;  |
| `map-kits/steppe/modern/roofscape` | 3d | 2 | required_scope_binding_verification | binding unresolved;  |
| `map-kits/steppe/modern/street` | 3d | 2 | required_scope_binding_verification | binding unresolved;  |
| `map-terrain/cliffs` | 3d | 2 | definitive_missing_declared_target | src/assets/map/terrain/cliffs.glb |
| `map-terrain/coasts` | 3d | 2 | definitive_missing_declared_target | src/assets/map/terrain/coasts.glb |
| `map-terrain/dunes` | 3d | 2 | definitive_missing_declared_target | src/assets/map/terrain/dunes.glb |
| `map-terrain/field-edges` | 3d | 2 | definitive_missing_declared_target | src/assets/map/terrain/field-edges.glb |
| `map-terrain/hills` | 3d | 2 | definitive_missing_declared_target | src/assets/map/terrain/hills.glb |
| `map-terrain/lakes` | 3d | 2 | definitive_missing_declared_target | src/assets/map/terrain/lakes.glb |
| `map-terrain/mountain-ridges` | 3d | 2 | definitive_missing_declared_target | src/assets/map/terrain/mountain-ridges.glb |
| `map-terrain/roads` | 3d | 2 | recorded_built_delivery_validation | src/assets/map/terrain/roads.glb |
| `map-terrain/shore-harbour` | 3d | 2 | definitive_missing_declared_target | src/assets/map/terrain/shore-harbour.glb |
| `map-terrain/town-ground-bronze` | 3d | 2 | definitive_missing_declared_target | src/assets/map/terrain/town-ground-bronze.glb |
| `map-terrain/town-ground-classical` | 3d | 2 | definitive_missing_declared_target | src/assets/map/terrain/town-ground-classical.glb |
| `map-terrain/town-ground-gunpowder` | 3d | 2 | definitive_missing_declared_target | src/assets/map/terrain/town-ground-gunpowder.glb |
| `map-terrain/town-ground-kingdoms` | 3d | 2 | definitive_missing_declared_target | src/assets/map/terrain/town-ground-kingdoms.glb |
| `map-terrain/town-ground-modern` | 3d | 2 | definitive_missing_declared_target | src/assets/map/terrain/town-ground-modern.glb |
| `map-terrain/wetlands` | 3d | 2 | definitive_missing_declared_target | src/assets/map/terrain/wetlands.glb |
| `map-towns/americas/bronze/town-big-a` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/bronze-town-big-a-americas.glb |
| `map-towns/americas/bronze/town-big-b` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/bronze-town-big-b-americas.glb |
| `map-towns/americas/bronze/town-medium-a` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/bronze-town-medium-a-americas.glb |
| `map-towns/americas/bronze/town-medium-b` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/bronze-town-medium-b-americas.glb |
| `map-towns/americas/bronze/town-small-a` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/bronze-town-small-a-americas.glb |
| `map-towns/americas/bronze/town-small-b` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/bronze-town-small-b-americas.glb |
| `map-towns/americas/classical/town-big-a` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/classical-town-big-a-americas.glb |
| `map-towns/americas/classical/town-big-b` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/classical-town-big-b-americas.glb |
| `map-towns/americas/classical/town-medium-a` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/classical-town-medium-a-americas.glb |
| `map-towns/americas/classical/town-medium-b` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/classical-town-medium-b-americas.glb |
| `map-towns/americas/classical/town-small-a` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/classical-town-small-a-americas.glb |
| `map-towns/americas/classical/town-small-b` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/classical-town-small-b-americas.glb |
| `map-towns/americas/gunpowder/town-big-a` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/gunpowder-town-big-a-americas.glb |
| `map-towns/americas/gunpowder/town-big-b` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/gunpowder-town-big-b-americas.glb |
| `map-towns/americas/gunpowder/town-medium-a` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/gunpowder-town-medium-a-americas.glb |
| `map-towns/americas/gunpowder/town-medium-b` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/gunpowder-town-medium-b-americas.glb |
| `map-towns/americas/gunpowder/town-small-a` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/gunpowder-town-small-a-americas.glb |
| `map-towns/americas/gunpowder/town-small-b` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/gunpowder-town-small-b-americas.glb |
| `map-towns/americas/kingdoms/town-big-a` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/kingdoms-town-big-a-americas.glb |
| `map-towns/americas/kingdoms/town-big-b` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/kingdoms-town-big-b-americas.glb |
| `map-towns/americas/kingdoms/town-medium-a` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/kingdoms-town-medium-a-americas.glb |
| `map-towns/americas/kingdoms/town-medium-b` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/kingdoms-town-medium-b-americas.glb |
| `map-towns/americas/kingdoms/town-small-a` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/kingdoms-town-small-a-americas.glb |
| `map-towns/americas/kingdoms/town-small-b` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/kingdoms-town-small-b-americas.glb |
| `map-towns/americas/modern/town-big-a` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/modern-town-big-a-americas.glb |
| `map-towns/americas/modern/town-big-b` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/modern-town-big-b-americas.glb |
| `map-towns/americas/modern/town-medium-a` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/modern-town-medium-a-americas.glb |
| `map-towns/americas/modern/town-medium-b` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/modern-town-medium-b-americas.glb |
| `map-towns/americas/modern/town-small-a` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/modern-town-small-a-americas.glb |
| `map-towns/americas/modern/town-small-b` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/modern-town-small-b-americas.glb |
| `map-towns/base/bronze/town-big-a` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/bronze-town-big-a.glb |
| `map-towns/base/bronze/town-big-b` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/bronze-town-big-b.glb |
| `map-towns/base/bronze/town-medium-a` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/bronze-town-medium-a.glb |
| `map-towns/base/bronze/town-medium-b` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/bronze-town-medium-b.glb |
| `map-towns/base/bronze/town-small-a` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/bronze-town-small-a.glb |
| `map-towns/base/bronze/town-small-b` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/bronze-town-small-b.glb |
| `map-towns/base/classical/town-big-a` | 3d | 2 | recorded_built_delivery_validation | src/assets/map/towns/classical-town-big-a.glb |
| `map-towns/base/classical/town-big-b` | 3d | 2 | recorded_built_delivery_validation | src/assets/map/towns/classical-town-big-b.glb |
| `map-towns/base/classical/town-medium-a` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/classical-town-medium-a.glb |
| `map-towns/base/classical/town-medium-b` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/classical-town-medium-b.glb |
| `map-towns/base/classical/town-small-a` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/classical-town-small-a.glb |
| `map-towns/base/classical/town-small-b` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/classical-town-small-b.glb |
| `map-towns/base/gunpowder/town-big-a` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/gunpowder-town-big-a.glb |
| `map-towns/base/gunpowder/town-big-b` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/gunpowder-town-big-b.glb |
| `map-towns/base/gunpowder/town-medium-a` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/gunpowder-town-medium-a.glb |
| `map-towns/base/gunpowder/town-medium-b` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/gunpowder-town-medium-b.glb |
| `map-towns/base/gunpowder/town-small-a` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/gunpowder-town-small-a.glb |
| `map-towns/base/gunpowder/town-small-b` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/gunpowder-town-small-b.glb |
| `map-towns/base/kingdoms/town-big-a` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/kingdoms-town-big-a.glb |
| `map-towns/base/kingdoms/town-big-b` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/kingdoms-town-big-b.glb |
| `map-towns/base/kingdoms/town-medium-a` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/kingdoms-town-medium-a.glb |
| `map-towns/base/kingdoms/town-medium-b` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/kingdoms-town-medium-b.glb |
| `map-towns/base/kingdoms/town-small-a` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/kingdoms-town-small-a.glb |
| `map-towns/base/kingdoms/town-small-b` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/kingdoms-town-small-b.glb |
| `map-towns/base/modern/town-big-a` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/modern-town-big-a.glb |
| `map-towns/base/modern/town-big-b` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/modern-town-big-b.glb |
| `map-towns/base/modern/town-medium-a` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/modern-town-medium-a.glb |
| `map-towns/base/modern/town-medium-b` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/modern-town-medium-b.glb |
| `map-towns/base/modern/town-small-a` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/modern-town-small-a.glb |
| `map-towns/base/modern/town-small-b` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/modern-town-small-b.glb |
| `map-towns/eastafrica/bronze/town-big-a` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/bronze-town-big-a-eastafrica.glb |
| `map-towns/eastafrica/bronze/town-big-b` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/bronze-town-big-b-eastafrica.glb |
| `map-towns/eastafrica/bronze/town-medium-a` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/bronze-town-medium-a-eastafrica.glb |
| `map-towns/eastafrica/bronze/town-medium-b` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/bronze-town-medium-b-eastafrica.glb |
| `map-towns/eastafrica/bronze/town-small-a` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/bronze-town-small-a-eastafrica.glb |
| `map-towns/eastafrica/bronze/town-small-b` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/bronze-town-small-b-eastafrica.glb |
| `map-towns/eastafrica/classical/town-big-a` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/classical-town-big-a-eastafrica.glb |
| `map-towns/eastafrica/classical/town-big-b` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/classical-town-big-b-eastafrica.glb |
| `map-towns/eastafrica/classical/town-medium-a` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/classical-town-medium-a-eastafrica.glb |
| `map-towns/eastafrica/classical/town-medium-b` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/classical-town-medium-b-eastafrica.glb |
| `map-towns/eastafrica/classical/town-small-a` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/classical-town-small-a-eastafrica.glb |
| `map-towns/eastafrica/classical/town-small-b` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/classical-town-small-b-eastafrica.glb |
| `map-towns/eastafrica/gunpowder/town-big-a` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/gunpowder-town-big-a-eastafrica.glb |
| `map-towns/eastafrica/gunpowder/town-big-b` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/gunpowder-town-big-b-eastafrica.glb |
| `map-towns/eastafrica/gunpowder/town-medium-a` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/gunpowder-town-medium-a-eastafrica.glb |
| `map-towns/eastafrica/gunpowder/town-medium-b` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/gunpowder-town-medium-b-eastafrica.glb |
| `map-towns/eastafrica/gunpowder/town-small-a` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/gunpowder-town-small-a-eastafrica.glb |
| `map-towns/eastafrica/gunpowder/town-small-b` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/gunpowder-town-small-b-eastafrica.glb |
| `map-towns/eastafrica/kingdoms/town-big-a` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/kingdoms-town-big-a-eastafrica.glb |
| `map-towns/eastafrica/kingdoms/town-big-b` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/kingdoms-town-big-b-eastafrica.glb |
| `map-towns/eastafrica/kingdoms/town-medium-a` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/kingdoms-town-medium-a-eastafrica.glb |
| `map-towns/eastafrica/kingdoms/town-medium-b` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/kingdoms-town-medium-b-eastafrica.glb |
| `map-towns/eastafrica/kingdoms/town-small-a` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/kingdoms-town-small-a-eastafrica.glb |
| `map-towns/eastafrica/kingdoms/town-small-b` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/kingdoms-town-small-b-eastafrica.glb |
| `map-towns/eastafrica/modern/town-big-a` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/modern-town-big-a-eastafrica.glb |
| `map-towns/eastafrica/modern/town-big-b` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/modern-town-big-b-eastafrica.glb |
| `map-towns/eastafrica/modern/town-medium-a` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/modern-town-medium-a-eastafrica.glb |
| `map-towns/eastafrica/modern/town-medium-b` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/modern-town-medium-b-eastafrica.glb |
| `map-towns/eastafrica/modern/town-small-a` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/modern-town-small-a-eastafrica.glb |
| `map-towns/eastafrica/modern/town-small-b` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/modern-town-small-b-eastafrica.glb |
| `map-towns/europe/bronze/town-big-a` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/bronze-town-big-a-europe.glb |
| `map-towns/europe/bronze/town-big-b` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/bronze-town-big-b-europe.glb |
| `map-towns/europe/bronze/town-medium-a` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/bronze-town-medium-a-europe.glb |
| `map-towns/europe/bronze/town-medium-b` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/bronze-town-medium-b-europe.glb |
| `map-towns/europe/bronze/town-small-a` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/bronze-town-small-a-europe.glb |
| `map-towns/europe/bronze/town-small-b` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/bronze-town-small-b-europe.glb |
| `map-towns/europe/classical/town-big-a` | 3d | 2 | definitive_missing_declared_target | src/assets/map/towns/classical-town-big-a-europe.glb |
| `map-towns/europe/classical/town-big-b` | 3d | 2 | definitive_missing_declared_target | src/assets/map/towns/classical-town-big-b-europe.glb |
| `map-towns/europe/classical/town-medium-a` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/classical-town-medium-a-europe.glb |
| `map-towns/europe/classical/town-medium-b` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/classical-town-medium-b-europe.glb |
| `map-towns/europe/classical/town-small-a` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/classical-town-small-a-europe.glb |
| `map-towns/europe/classical/town-small-b` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/classical-town-small-b-europe.glb |
| `map-towns/europe/gunpowder/town-big-a` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/gunpowder-town-big-a-europe.glb |
| `map-towns/europe/gunpowder/town-big-b` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/gunpowder-town-big-b-europe.glb |
| `map-towns/europe/gunpowder/town-medium-a` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/gunpowder-town-medium-a-europe.glb |
| `map-towns/europe/gunpowder/town-medium-b` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/gunpowder-town-medium-b-europe.glb |
| `map-towns/europe/gunpowder/town-small-a` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/gunpowder-town-small-a-europe.glb |
| `map-towns/europe/gunpowder/town-small-b` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/gunpowder-town-small-b-europe.glb |
| `map-towns/europe/kingdoms/town-big-a` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/kingdoms-town-big-a-europe.glb |
| `map-towns/europe/kingdoms/town-big-b` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/kingdoms-town-big-b-europe.glb |
| `map-towns/europe/kingdoms/town-medium-a` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/kingdoms-town-medium-a-europe.glb |
| `map-towns/europe/kingdoms/town-medium-b` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/kingdoms-town-medium-b-europe.glb |
| `map-towns/europe/kingdoms/town-small-a` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/kingdoms-town-small-a-europe.glb |
| `map-towns/europe/kingdoms/town-small-b` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/kingdoms-town-small-b-europe.glb |
| `map-towns/europe/modern/town-big-a` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/modern-town-big-a-europe.glb |
| `map-towns/europe/modern/town-big-b` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/modern-town-big-b-europe.glb |
| `map-towns/europe/modern/town-medium-a` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/modern-town-medium-a-europe.glb |
| `map-towns/europe/modern/town-medium-b` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/modern-town-medium-b-europe.glb |
| `map-towns/europe/modern/town-small-a` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/modern-town-small-a-europe.glb |
| `map-towns/europe/modern/town-small-b` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/modern-town-small-b-europe.glb |
| `map-towns/europenorth/classical/town-big-a` | 3d | 2 | definitive_missing_declared_target | src/assets/map/towns/classical-town-big-a-europenorth.glb |
| `map-towns/europenorth/classical/town-big-b` | 3d | 2 | definitive_missing_declared_target | src/assets/map/towns/classical-town-big-b-europenorth.glb |
| `map-towns/europenorth/classical/town-medium-a` | 3d | 2 | definitive_missing_declared_target | src/assets/map/towns/classical-town-medium-a-europenorth.glb |
| `map-towns/europenorth/classical/town-medium-b` | 3d | 2 | definitive_missing_declared_target | src/assets/map/towns/classical-town-medium-b-europenorth.glb |
| `map-towns/indic/bronze/town-big-a` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/bronze-town-big-a-indic.glb |
| `map-towns/indic/bronze/town-big-b` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/bronze-town-big-b-indic.glb |
| `map-towns/indic/bronze/town-medium-a` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/bronze-town-medium-a-indic.glb |
| `map-towns/indic/bronze/town-medium-b` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/bronze-town-medium-b-indic.glb |
| `map-towns/indic/bronze/town-small-a` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/bronze-town-small-a-indic.glb |
| `map-towns/indic/bronze/town-small-b` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/bronze-town-small-b-indic.glb |
| `map-towns/indic/classical/town-big-a` | 3d | 2 | definitive_missing_declared_target | src/assets/map/towns/classical-town-big-a-indic.glb |
| `map-towns/indic/classical/town-big-b` | 3d | 2 | definitive_missing_declared_target | src/assets/map/towns/classical-town-big-b-indic.glb |
| `map-towns/indic/classical/town-medium-a` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/classical-town-medium-a-indic.glb |
| `map-towns/indic/classical/town-medium-b` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/classical-town-medium-b-indic.glb |
| `map-towns/indic/classical/town-small-a` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/classical-town-small-a-indic.glb |
| `map-towns/indic/classical/town-small-b` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/classical-town-small-b-indic.glb |
| `map-towns/indic/gunpowder/town-big-a` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/gunpowder-town-big-a-indic.glb |
| `map-towns/indic/gunpowder/town-big-b` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/gunpowder-town-big-b-indic.glb |
| `map-towns/indic/gunpowder/town-medium-a` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/gunpowder-town-medium-a-indic.glb |
| `map-towns/indic/gunpowder/town-medium-b` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/gunpowder-town-medium-b-indic.glb |
| `map-towns/indic/gunpowder/town-small-a` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/gunpowder-town-small-a-indic.glb |
| `map-towns/indic/gunpowder/town-small-b` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/gunpowder-town-small-b-indic.glb |
| `map-towns/indic/kingdoms/town-big-a` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/kingdoms-town-big-a-indic.glb |
| `map-towns/indic/kingdoms/town-big-b` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/kingdoms-town-big-b-indic.glb |
| `map-towns/indic/kingdoms/town-medium-a` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/kingdoms-town-medium-a-indic.glb |
| `map-towns/indic/kingdoms/town-medium-b` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/kingdoms-town-medium-b-indic.glb |
| `map-towns/indic/kingdoms/town-small-a` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/kingdoms-town-small-a-indic.glb |
| `map-towns/indic/kingdoms/town-small-b` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/kingdoms-town-small-b-indic.glb |
| `map-towns/indic/modern/town-big-a` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/modern-town-big-a-indic.glb |
| `map-towns/indic/modern/town-big-b` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/modern-town-big-b-indic.glb |
| `map-towns/indic/modern/town-medium-a` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/modern-town-medium-a-indic.glb |
| `map-towns/indic/modern/town-medium-b` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/modern-town-medium-b-indic.glb |
| `map-towns/indic/modern/town-small-a` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/modern-town-small-a-indic.glb |
| `map-towns/indic/modern/town-small-b` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/modern-town-small-b-indic.glb |
| `map-towns/israelite/bronze/town-big-a` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/bronze-town-big-a-israelite.glb |
| `map-towns/israelite/bronze/town-big-b` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/bronze-town-big-b-israelite.glb |
| `map-towns/israelite/bronze/town-medium-a` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/bronze-town-medium-a-israelite.glb |
| `map-towns/israelite/bronze/town-medium-b` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/bronze-town-medium-b-israelite.glb |
| `map-towns/israelite/bronze/town-small-a` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/bronze-town-small-a-israelite.glb |
| `map-towns/israelite/bronze/town-small-b` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/bronze-town-small-b-israelite.glb |
| `map-towns/israelite/classical/town-big-a` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/classical-town-big-a-israelite.glb |
| `map-towns/israelite/classical/town-big-b` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/classical-town-big-b-israelite.glb |
| `map-towns/israelite/classical/town-medium-a` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/classical-town-medium-a-israelite.glb |
| `map-towns/israelite/classical/town-medium-b` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/classical-town-medium-b-israelite.glb |
| `map-towns/israelite/classical/town-small-a` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/classical-town-small-a-israelite.glb |
| `map-towns/israelite/classical/town-small-b` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/classical-town-small-b-israelite.glb |
| `map-towns/israelite/gunpowder/town-big-a` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/gunpowder-town-big-a-israelite.glb |
| `map-towns/israelite/gunpowder/town-big-b` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/gunpowder-town-big-b-israelite.glb |
| `map-towns/israelite/gunpowder/town-medium-a` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/gunpowder-town-medium-a-israelite.glb |
| `map-towns/israelite/gunpowder/town-medium-b` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/gunpowder-town-medium-b-israelite.glb |
| `map-towns/israelite/gunpowder/town-small-a` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/gunpowder-town-small-a-israelite.glb |
| `map-towns/israelite/gunpowder/town-small-b` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/gunpowder-town-small-b-israelite.glb |
| `map-towns/israelite/kingdoms/town-big-a` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/kingdoms-town-big-a-israelite.glb |
| `map-towns/israelite/kingdoms/town-big-b` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/kingdoms-town-big-b-israelite.glb |
| `map-towns/israelite/kingdoms/town-medium-a` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/kingdoms-town-medium-a-israelite.glb |
| `map-towns/israelite/kingdoms/town-medium-b` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/kingdoms-town-medium-b-israelite.glb |
| `map-towns/israelite/kingdoms/town-small-a` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/kingdoms-town-small-a-israelite.glb |
| `map-towns/israelite/kingdoms/town-small-b` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/kingdoms-town-small-b-israelite.glb |
| `map-towns/israelite/modern/town-big-a` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/modern-town-big-a-israelite.glb |
| `map-towns/israelite/modern/town-big-b` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/modern-town-big-b-israelite.glb |
| `map-towns/israelite/modern/town-medium-a` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/modern-town-medium-a-israelite.glb |
| `map-towns/israelite/modern/town-medium-b` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/modern-town-medium-b-israelite.glb |
| `map-towns/israelite/modern/town-small-a` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/modern-town-small-a-israelite.glb |
| `map-towns/israelite/modern/town-small-b` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/modern-town-small-b-israelite.glb |
| `map-towns/japan/bronze/town-big-a` | 3d | 2 | definitive_missing_declared_target | src/assets/map/towns/bronze-town-big-a-japan.glb |
| `map-towns/japan/bronze/town-big-b` | 3d | 2 | definitive_missing_declared_target | src/assets/map/towns/bronze-town-big-b-japan.glb |
| `map-towns/japan/bronze/town-medium-a` | 3d | 2 | definitive_missing_declared_target | src/assets/map/towns/bronze-town-medium-a-japan.glb |
| `map-towns/japan/bronze/town-medium-b` | 3d | 2 | definitive_missing_declared_target | src/assets/map/towns/bronze-town-medium-b-japan.glb |
| `map-towns/japan/bronze/town-small-a` | 3d | 2 | definitive_missing_declared_target | src/assets/map/towns/bronze-town-small-a-japan.glb |
| `map-towns/japan/bronze/town-small-b` | 3d | 2 | definitive_missing_declared_target | src/assets/map/towns/bronze-town-small-b-japan.glb |
| `map-towns/japan/classical/town-big-a` | 3d | 2 | definitive_missing_declared_target | src/assets/map/towns/classical-town-big-a-japan.glb |
| `map-towns/japan/classical/town-big-b` | 3d | 2 | definitive_missing_declared_target | src/assets/map/towns/classical-town-big-b-japan.glb |
| `map-towns/japan/classical/town-medium-a` | 3d | 2 | definitive_missing_declared_target | src/assets/map/towns/classical-town-medium-a-japan.glb |
| `map-towns/japan/classical/town-medium-b` | 3d | 2 | definitive_missing_declared_target | src/assets/map/towns/classical-town-medium-b-japan.glb |
| `map-towns/japan/classical/town-small-a` | 3d | 2 | definitive_missing_declared_target | src/assets/map/towns/classical-town-small-a-japan.glb |
| `map-towns/japan/classical/town-small-b` | 3d | 2 | definitive_missing_declared_target | src/assets/map/towns/classical-town-small-b-japan.glb |
| `map-towns/japan/gunpowder/town-big-a` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/gunpowder-town-big-a-japan.glb |
| `map-towns/japan/gunpowder/town-big-b` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/gunpowder-town-big-b-japan.glb |
| `map-towns/japan/gunpowder/town-medium-a` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/gunpowder-town-medium-a-japan.glb |
| `map-towns/japan/gunpowder/town-medium-b` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/gunpowder-town-medium-b-japan.glb |
| `map-towns/japan/gunpowder/town-small-a` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/gunpowder-town-small-a-japan.glb |
| `map-towns/japan/gunpowder/town-small-b` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/gunpowder-town-small-b-japan.glb |
| `map-towns/japan/kingdoms/town-big-a` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/kingdoms-town-big-a-japan.glb |
| `map-towns/japan/kingdoms/town-big-b` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/kingdoms-town-big-b-japan.glb |
| `map-towns/japan/kingdoms/town-medium-a` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/kingdoms-town-medium-a-japan.glb |
| `map-towns/japan/kingdoms/town-medium-b` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/kingdoms-town-medium-b-japan.glb |
| `map-towns/japan/kingdoms/town-small-a` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/kingdoms-town-small-a-japan.glb |
| `map-towns/japan/kingdoms/town-small-b` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/kingdoms-town-small-b-japan.glb |
| `map-towns/japan/modern/town-big-a` | 3d | 2 | definitive_missing_declared_target | src/assets/map/towns/modern-town-big-a-japan.glb |
| `map-towns/japan/modern/town-big-b` | 3d | 2 | definitive_missing_declared_target | src/assets/map/towns/modern-town-big-b-japan.glb |
| `map-towns/japan/modern/town-medium-a` | 3d | 2 | definitive_missing_declared_target | src/assets/map/towns/modern-town-medium-a-japan.glb |
| `map-towns/japan/modern/town-medium-b` | 3d | 2 | definitive_missing_declared_target | src/assets/map/towns/modern-town-medium-b-japan.glb |
| `map-towns/japan/modern/town-small-a` | 3d | 2 | definitive_missing_declared_target | src/assets/map/towns/modern-town-small-a-japan.glb |
| `map-towns/japan/modern/town-small-b` | 3d | 2 | definitive_missing_declared_target | src/assets/map/towns/modern-town-small-b-japan.glb |
| `map-towns/korea/bronze/town-big-a` | 3d | 2 | definitive_missing_declared_target | src/assets/map/towns/bronze-town-big-a-korea.glb |
| `map-towns/korea/bronze/town-big-b` | 3d | 2 | definitive_missing_declared_target | src/assets/map/towns/bronze-town-big-b-korea.glb |
| `map-towns/korea/bronze/town-medium-a` | 3d | 2 | definitive_missing_declared_target | src/assets/map/towns/bronze-town-medium-a-korea.glb |
| `map-towns/korea/bronze/town-medium-b` | 3d | 2 | definitive_missing_declared_target | src/assets/map/towns/bronze-town-medium-b-korea.glb |
| `map-towns/korea/bronze/town-small-a` | 3d | 2 | definitive_missing_declared_target | src/assets/map/towns/bronze-town-small-a-korea.glb |
| `map-towns/korea/bronze/town-small-b` | 3d | 2 | definitive_missing_declared_target | src/assets/map/towns/bronze-town-small-b-korea.glb |
| `map-towns/korea/classical/town-big-a` | 3d | 2 | definitive_missing_declared_target | src/assets/map/towns/classical-town-big-a-korea.glb |
| `map-towns/korea/classical/town-big-b` | 3d | 2 | definitive_missing_declared_target | src/assets/map/towns/classical-town-big-b-korea.glb |
| `map-towns/korea/classical/town-medium-a` | 3d | 2 | definitive_missing_declared_target | src/assets/map/towns/classical-town-medium-a-korea.glb |
| `map-towns/korea/classical/town-medium-b` | 3d | 2 | definitive_missing_declared_target | src/assets/map/towns/classical-town-medium-b-korea.glb |
| `map-towns/korea/classical/town-small-a` | 3d | 2 | definitive_missing_declared_target | src/assets/map/towns/classical-town-small-a-korea.glb |
| `map-towns/korea/classical/town-small-b` | 3d | 2 | definitive_missing_declared_target | src/assets/map/towns/classical-town-small-b-korea.glb |
| `map-towns/korea/gunpowder/town-big-a` | 3d | 2 | definitive_missing_declared_target | src/assets/map/towns/gunpowder-town-big-a-korea.glb |
| `map-towns/korea/gunpowder/town-big-b` | 3d | 2 | definitive_missing_declared_target | src/assets/map/towns/gunpowder-town-big-b-korea.glb |
| `map-towns/korea/gunpowder/town-medium-a` | 3d | 2 | definitive_missing_declared_target | src/assets/map/towns/gunpowder-town-medium-a-korea.glb |
| `map-towns/korea/gunpowder/town-medium-b` | 3d | 2 | definitive_missing_declared_target | src/assets/map/towns/gunpowder-town-medium-b-korea.glb |
| `map-towns/korea/gunpowder/town-small-a` | 3d | 2 | definitive_missing_declared_target | src/assets/map/towns/gunpowder-town-small-a-korea.glb |
| `map-towns/korea/gunpowder/town-small-b` | 3d | 2 | definitive_missing_declared_target | src/assets/map/towns/gunpowder-town-small-b-korea.glb |
| `map-towns/korea/kingdoms/town-big-a` | 3d | 2 | definitive_missing_declared_target | src/assets/map/towns/kingdoms-town-big-a-korea.glb |
| `map-towns/korea/kingdoms/town-big-b` | 3d | 2 | definitive_missing_declared_target | src/assets/map/towns/kingdoms-town-big-b-korea.glb |
| `map-towns/korea/kingdoms/town-medium-a` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/kingdoms-town-medium-a-korea.glb |
| `map-towns/korea/kingdoms/town-medium-b` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/kingdoms-town-medium-b-korea.glb |
| `map-towns/korea/kingdoms/town-small-a` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/kingdoms-town-small-a-korea.glb |
| `map-towns/korea/kingdoms/town-small-b` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/kingdoms-town-small-b-korea.glb |
| `map-towns/korea/modern/town-big-a` | 3d | 2 | definitive_missing_declared_target | src/assets/map/towns/modern-town-big-a-korea.glb |
| `map-towns/korea/modern/town-big-b` | 3d | 2 | definitive_missing_declared_target | src/assets/map/towns/modern-town-big-b-korea.glb |
| `map-towns/korea/modern/town-medium-a` | 3d | 2 | definitive_missing_declared_target | src/assets/map/towns/modern-town-medium-a-korea.glb |
| `map-towns/korea/modern/town-medium-b` | 3d | 2 | definitive_missing_declared_target | src/assets/map/towns/modern-town-medium-b-korea.glb |
| `map-towns/korea/modern/town-small-a` | 3d | 2 | definitive_missing_declared_target | src/assets/map/towns/modern-town-small-a-korea.glb |
| `map-towns/korea/modern/town-small-b` | 3d | 2 | definitive_missing_declared_target | src/assets/map/towns/modern-town-small-b-korea.glb |
| `map-towns/levant/bronze/town-big-a` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/bronze-town-big-a-levant.glb |
| `map-towns/levant/bronze/town-big-b` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/bronze-town-big-b-levant.glb |
| `map-towns/levant/bronze/town-medium-a` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/bronze-town-medium-a-levant.glb |
| `map-towns/levant/bronze/town-medium-b` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/bronze-town-medium-b-levant.glb |
| `map-towns/levant/bronze/town-small-a` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/bronze-town-small-a-levant.glb |
| `map-towns/levant/bronze/town-small-b` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/bronze-town-small-b-levant.glb |
| `map-towns/levant/classical/town-big-a` | 3d | 2 | definitive_missing_declared_target | src/assets/map/towns/classical-town-big-a-levant.glb |
| `map-towns/levant/classical/town-big-b` | 3d | 2 | definitive_missing_declared_target | src/assets/map/towns/classical-town-big-b-levant.glb |
| `map-towns/levant/classical/town-medium-a` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/classical-town-medium-a-levant.glb |
| `map-towns/levant/classical/town-medium-b` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/classical-town-medium-b-levant.glb |
| `map-towns/levant/classical/town-small-a` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/classical-town-small-a-levant.glb |
| `map-towns/levant/classical/town-small-b` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/classical-town-small-b-levant.glb |
| `map-towns/levant/gunpowder/town-big-a` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/gunpowder-town-big-a-levant.glb |
| `map-towns/levant/gunpowder/town-big-b` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/gunpowder-town-big-b-levant.glb |
| `map-towns/levant/gunpowder/town-medium-a` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/gunpowder-town-medium-a-levant.glb |
| `map-towns/levant/gunpowder/town-medium-b` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/gunpowder-town-medium-b-levant.glb |
| `map-towns/levant/gunpowder/town-small-a` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/gunpowder-town-small-a-levant.glb |
| `map-towns/levant/gunpowder/town-small-b` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/gunpowder-town-small-b-levant.glb |
| `map-towns/levant/kingdoms/town-big-a` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/kingdoms-town-big-a-levant.glb |
| `map-towns/levant/kingdoms/town-big-b` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/kingdoms-town-big-b-levant.glb |
| `map-towns/levant/kingdoms/town-medium-a` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/kingdoms-town-medium-a-levant.glb |
| `map-towns/levant/kingdoms/town-medium-b` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/kingdoms-town-medium-b-levant.glb |
| `map-towns/levant/kingdoms/town-small-a` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/kingdoms-town-small-a-levant.glb |
| `map-towns/levant/kingdoms/town-small-b` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/kingdoms-town-small-b-levant.glb |
| `map-towns/levant/modern/town-big-a` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/modern-town-big-a-levant.glb |
| `map-towns/levant/modern/town-big-b` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/modern-town-big-b-levant.glb |
| `map-towns/levant/modern/town-medium-a` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/modern-town-medium-a-levant.glb |
| `map-towns/levant/modern/town-medium-b` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/modern-town-medium-b-levant.glb |
| `map-towns/levant/modern/town-small-a` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/modern-town-small-a-levant.glb |
| `map-towns/levant/modern/town-small-b` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/modern-town-small-b-levant.glb |
| `map-towns/maghreb/bronze/town-big-a` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/bronze-town-big-a-maghreb.glb |
| `map-towns/maghreb/bronze/town-big-b` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/bronze-town-big-b-maghreb.glb |
| `map-towns/maghreb/bronze/town-medium-a` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/bronze-town-medium-a-maghreb.glb |
| `map-towns/maghreb/bronze/town-medium-b` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/bronze-town-medium-b-maghreb.glb |
| `map-towns/maghreb/bronze/town-small-a` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/bronze-town-small-a-maghreb.glb |
| `map-towns/maghreb/bronze/town-small-b` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/bronze-town-small-b-maghreb.glb |
| `map-towns/maghreb/classical/town-big-a` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/classical-town-big-a-maghreb.glb |
| `map-towns/maghreb/classical/town-big-b` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/classical-town-big-b-maghreb.glb |
| `map-towns/maghreb/classical/town-medium-a` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/classical-town-medium-a-maghreb.glb |
| `map-towns/maghreb/classical/town-medium-b` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/classical-town-medium-b-maghreb.glb |
| `map-towns/maghreb/classical/town-small-a` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/classical-town-small-a-maghreb.glb |
| `map-towns/maghreb/classical/town-small-b` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/classical-town-small-b-maghreb.glb |
| `map-towns/maghreb/gunpowder/town-big-a` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/gunpowder-town-big-a-maghreb.glb |
| `map-towns/maghreb/gunpowder/town-big-b` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/gunpowder-town-big-b-maghreb.glb |
| `map-towns/maghreb/gunpowder/town-medium-a` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/gunpowder-town-medium-a-maghreb.glb |
| `map-towns/maghreb/gunpowder/town-medium-b` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/gunpowder-town-medium-b-maghreb.glb |
| `map-towns/maghreb/gunpowder/town-small-a` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/gunpowder-town-small-a-maghreb.glb |
| `map-towns/maghreb/gunpowder/town-small-b` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/gunpowder-town-small-b-maghreb.glb |
| `map-towns/maghreb/kingdoms/town-big-a` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/kingdoms-town-big-a-maghreb.glb |
| `map-towns/maghreb/kingdoms/town-big-b` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/kingdoms-town-big-b-maghreb.glb |
| `map-towns/maghreb/kingdoms/town-medium-a` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/kingdoms-town-medium-a-maghreb.glb |
| `map-towns/maghreb/kingdoms/town-medium-b` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/kingdoms-town-medium-b-maghreb.glb |
| `map-towns/maghreb/kingdoms/town-small-a` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/kingdoms-town-small-a-maghreb.glb |
| `map-towns/maghreb/kingdoms/town-small-b` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/kingdoms-town-small-b-maghreb.glb |
| `map-towns/maghreb/modern/town-big-a` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/modern-town-big-a-maghreb.glb |
| `map-towns/maghreb/modern/town-big-b` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/modern-town-big-b-maghreb.glb |
| `map-towns/maghreb/modern/town-medium-a` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/modern-town-medium-a-maghreb.glb |
| `map-towns/maghreb/modern/town-medium-b` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/modern-town-medium-b-maghreb.glb |
| `map-towns/maghreb/modern/town-small-a` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/modern-town-small-a-maghreb.glb |
| `map-towns/maghreb/modern/town-small-b` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/modern-town-small-b-maghreb.glb |
| `map-towns/monsoon/bronze/town-big-a` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/bronze-town-big-a-monsoon.glb |
| `map-towns/monsoon/bronze/town-big-b` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/bronze-town-big-b-monsoon.glb |
| `map-towns/monsoon/bronze/town-medium-a` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/bronze-town-medium-a-monsoon.glb |
| `map-towns/monsoon/bronze/town-medium-b` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/bronze-town-medium-b-monsoon.glb |
| `map-towns/monsoon/bronze/town-small-a` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/bronze-town-small-a-monsoon.glb |
| `map-towns/monsoon/bronze/town-small-b` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/bronze-town-small-b-monsoon.glb |
| `map-towns/monsoon/classical/town-big-a` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/classical-town-big-a-monsoon.glb |
| `map-towns/monsoon/classical/town-big-b` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/classical-town-big-b-monsoon.glb |
| `map-towns/monsoon/classical/town-medium-a` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/classical-town-medium-a-monsoon.glb |
| `map-towns/monsoon/classical/town-medium-b` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/classical-town-medium-b-monsoon.glb |
| `map-towns/monsoon/classical/town-small-a` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/classical-town-small-a-monsoon.glb |
| `map-towns/monsoon/classical/town-small-b` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/classical-town-small-b-monsoon.glb |
| `map-towns/monsoon/gunpowder/town-big-a` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/gunpowder-town-big-a-monsoon.glb |
| `map-towns/monsoon/gunpowder/town-big-b` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/gunpowder-town-big-b-monsoon.glb |
| `map-towns/monsoon/gunpowder/town-medium-a` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/gunpowder-town-medium-a-monsoon.glb |
| `map-towns/monsoon/gunpowder/town-medium-b` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/gunpowder-town-medium-b-monsoon.glb |
| `map-towns/monsoon/gunpowder/town-small-a` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/gunpowder-town-small-a-monsoon.glb |
| `map-towns/monsoon/gunpowder/town-small-b` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/gunpowder-town-small-b-monsoon.glb |
| `map-towns/monsoon/kingdoms/town-big-a` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/kingdoms-town-big-a-monsoon.glb |
| `map-towns/monsoon/kingdoms/town-big-b` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/kingdoms-town-big-b-monsoon.glb |
| `map-towns/monsoon/kingdoms/town-medium-a` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/kingdoms-town-medium-a-monsoon.glb |
| `map-towns/monsoon/kingdoms/town-medium-b` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/kingdoms-town-medium-b-monsoon.glb |
| `map-towns/monsoon/kingdoms/town-small-a` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/kingdoms-town-small-a-monsoon.glb |
| `map-towns/monsoon/kingdoms/town-small-b` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/kingdoms-town-small-b-monsoon.glb |
| `map-towns/monsoon/modern/town-big-a` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/modern-town-big-a-monsoon.glb |
| `map-towns/monsoon/modern/town-big-b` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/modern-town-big-b-monsoon.glb |
| `map-towns/monsoon/modern/town-medium-a` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/modern-town-medium-a-monsoon.glb |
| `map-towns/monsoon/modern/town-medium-b` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/modern-town-medium-b-monsoon.glb |
| `map-towns/monsoon/modern/town-small-a` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/modern-town-small-a-monsoon.glb |
| `map-towns/monsoon/modern/town-small-b` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/modern-town-small-b-monsoon.glb |
| `map-towns/nile/bronze/town-big-a` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/bronze-town-big-a-nile.glb |
| `map-towns/nile/bronze/town-big-b` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/bronze-town-big-b-nile.glb |
| `map-towns/nile/bronze/town-medium-a` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/bronze-town-medium-a-nile.glb |
| `map-towns/nile/bronze/town-medium-b` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/bronze-town-medium-b-nile.glb |
| `map-towns/nile/bronze/town-small-a` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/bronze-town-small-a-nile.glb |
| `map-towns/nile/bronze/town-small-b` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/bronze-town-small-b-nile.glb |
| `map-towns/nile/classical/town-big-a` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/classical-town-big-a-nile.glb |
| `map-towns/nile/classical/town-big-b` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/classical-town-big-b-nile.glb |
| `map-towns/nile/classical/town-medium-a` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/classical-town-medium-a-nile.glb |
| `map-towns/nile/classical/town-medium-b` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/classical-town-medium-b-nile.glb |
| `map-towns/nile/classical/town-small-a` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/classical-town-small-a-nile.glb |
| `map-towns/nile/classical/town-small-b` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/classical-town-small-b-nile.glb |
| `map-towns/nile/gunpowder/town-big-a` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/gunpowder-town-big-a-nile.glb |
| `map-towns/nile/gunpowder/town-big-b` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/gunpowder-town-big-b-nile.glb |
| `map-towns/nile/gunpowder/town-medium-a` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/gunpowder-town-medium-a-nile.glb |
| `map-towns/nile/gunpowder/town-medium-b` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/gunpowder-town-medium-b-nile.glb |
| `map-towns/nile/gunpowder/town-small-a` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/gunpowder-town-small-a-nile.glb |
| `map-towns/nile/gunpowder/town-small-b` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/gunpowder-town-small-b-nile.glb |
| `map-towns/nile/kingdoms/town-big-a` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/kingdoms-town-big-a-nile.glb |
| `map-towns/nile/kingdoms/town-big-b` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/kingdoms-town-big-b-nile.glb |
| `map-towns/nile/kingdoms/town-medium-a` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/kingdoms-town-medium-a-nile.glb |
| `map-towns/nile/kingdoms/town-medium-b` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/kingdoms-town-medium-b-nile.glb |
| `map-towns/nile/kingdoms/town-small-a` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/kingdoms-town-small-a-nile.glb |
| `map-towns/nile/kingdoms/town-small-b` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/kingdoms-town-small-b-nile.glb |
| `map-towns/nile/modern/town-big-a` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/modern-town-big-a-nile.glb |
| `map-towns/nile/modern/town-big-b` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/modern-town-big-b-nile.glb |
| `map-towns/nile/modern/town-medium-a` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/modern-town-medium-a-nile.glb |
| `map-towns/nile/modern/town-medium-b` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/modern-town-medium-b-nile.glb |
| `map-towns/nile/modern/town-small-a` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/modern-town-small-a-nile.glb |
| `map-towns/nile/modern/town-small-b` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/modern-town-small-b-nile.glb |
| `map-towns/pacific/bronze/town-big-a` | 3d | 2 | definitive_missing_declared_target | src/assets/map/towns/bronze-town-big-a-pacific.glb |
| `map-towns/pacific/bronze/town-big-b` | 3d | 2 | definitive_missing_declared_target | src/assets/map/towns/bronze-town-big-b-pacific.glb |
| `map-towns/pacific/bronze/town-medium-a` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/bronze-town-medium-a-pacific.glb |
| `map-towns/pacific/bronze/town-medium-b` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/bronze-town-medium-b-pacific.glb |
| `map-towns/pacific/bronze/town-small-a` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/bronze-town-small-a-pacific.glb |
| `map-towns/pacific/bronze/town-small-b` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/bronze-town-small-b-pacific.glb |
| `map-towns/pacific/classical/town-big-a` | 3d | 2 | definitive_missing_declared_target | src/assets/map/towns/classical-town-big-a-pacific.glb |
| `map-towns/pacific/classical/town-big-b` | 3d | 2 | definitive_missing_declared_target | src/assets/map/towns/classical-town-big-b-pacific.glb |
| `map-towns/pacific/classical/town-medium-a` | 3d | 2 | definitive_missing_declared_target | src/assets/map/towns/classical-town-medium-a-pacific.glb |
| `map-towns/pacific/classical/town-medium-b` | 3d | 2 | definitive_missing_declared_target | src/assets/map/towns/classical-town-medium-b-pacific.glb |
| `map-towns/pacific/classical/town-small-a` | 3d | 2 | definitive_missing_declared_target | src/assets/map/towns/classical-town-small-a-pacific.glb |
| `map-towns/pacific/classical/town-small-b` | 3d | 2 | definitive_missing_declared_target | src/assets/map/towns/classical-town-small-b-pacific.glb |
| `map-towns/pacific/gunpowder/town-big-a` | 3d | 2 | definitive_missing_declared_target | src/assets/map/towns/gunpowder-town-big-a-pacific.glb |
| `map-towns/pacific/gunpowder/town-big-b` | 3d | 2 | definitive_missing_declared_target | src/assets/map/towns/gunpowder-town-big-b-pacific.glb |
| `map-towns/pacific/gunpowder/town-medium-a` | 3d | 2 | definitive_missing_declared_target | src/assets/map/towns/gunpowder-town-medium-a-pacific.glb |
| `map-towns/pacific/gunpowder/town-medium-b` | 3d | 2 | definitive_missing_declared_target | src/assets/map/towns/gunpowder-town-medium-b-pacific.glb |
| `map-towns/pacific/gunpowder/town-small-a` | 3d | 2 | definitive_missing_declared_target | src/assets/map/towns/gunpowder-town-small-a-pacific.glb |
| `map-towns/pacific/gunpowder/town-small-b` | 3d | 2 | definitive_missing_declared_target | src/assets/map/towns/gunpowder-town-small-b-pacific.glb |
| `map-towns/pacific/kingdoms/town-big-a` | 3d | 2 | definitive_missing_declared_target | src/assets/map/towns/kingdoms-town-big-a-pacific.glb |
| `map-towns/pacific/kingdoms/town-big-b` | 3d | 2 | definitive_missing_declared_target | src/assets/map/towns/kingdoms-town-big-b-pacific.glb |
| `map-towns/pacific/kingdoms/town-medium-a` | 3d | 2 | definitive_missing_declared_target | src/assets/map/towns/kingdoms-town-medium-a-pacific.glb |
| `map-towns/pacific/kingdoms/town-medium-b` | 3d | 2 | definitive_missing_declared_target | src/assets/map/towns/kingdoms-town-medium-b-pacific.glb |
| `map-towns/pacific/kingdoms/town-small-a` | 3d | 2 | definitive_missing_declared_target | src/assets/map/towns/kingdoms-town-small-a-pacific.glb |
| `map-towns/pacific/kingdoms/town-small-b` | 3d | 2 | definitive_missing_declared_target | src/assets/map/towns/kingdoms-town-small-b-pacific.glb |
| `map-towns/pacific/modern/town-big-a` | 3d | 2 | definitive_missing_declared_target | src/assets/map/towns/modern-town-big-a-pacific.glb |
| `map-towns/pacific/modern/town-big-b` | 3d | 2 | definitive_missing_declared_target | src/assets/map/towns/modern-town-big-b-pacific.glb |
| `map-towns/pacific/modern/town-medium-a` | 3d | 2 | definitive_missing_declared_target | src/assets/map/towns/modern-town-medium-a-pacific.glb |
| `map-towns/pacific/modern/town-medium-b` | 3d | 2 | definitive_missing_declared_target | src/assets/map/towns/modern-town-medium-b-pacific.glb |
| `map-towns/pacific/modern/town-small-a` | 3d | 2 | definitive_missing_declared_target | src/assets/map/towns/modern-town-small-a-pacific.glb |
| `map-towns/pacific/modern/town-small-b` | 3d | 2 | definitive_missing_declared_target | src/assets/map/towns/modern-town-small-b-pacific.glb |
| `map-towns/sinic/bronze/town-big-a` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/bronze-town-big-a-sinic.glb |
| `map-towns/sinic/bronze/town-big-b` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/bronze-town-big-b-sinic.glb |
| `map-towns/sinic/bronze/town-medium-a` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/bronze-town-medium-a-sinic.glb |
| `map-towns/sinic/bronze/town-medium-b` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/bronze-town-medium-b-sinic.glb |
| `map-towns/sinic/bronze/town-small-a` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/bronze-town-small-a-sinic.glb |
| `map-towns/sinic/bronze/town-small-b` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/bronze-town-small-b-sinic.glb |
| `map-towns/sinic/classical/town-big-a` | 3d | 2 | definitive_missing_declared_target | src/assets/map/towns/classical-town-big-a-sinic.glb |
| `map-towns/sinic/classical/town-big-b` | 3d | 2 | definitive_missing_declared_target | src/assets/map/towns/classical-town-big-b-sinic.glb |
| `map-towns/sinic/classical/town-medium-a` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/classical-town-medium-a-sinic.glb |
| `map-towns/sinic/classical/town-medium-b` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/classical-town-medium-b-sinic.glb |
| `map-towns/sinic/classical/town-small-a` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/classical-town-small-a-sinic.glb |
| `map-towns/sinic/classical/town-small-b` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/classical-town-small-b-sinic.glb |
| `map-towns/sinic/gunpowder/town-big-a` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/gunpowder-town-big-a-sinic.glb |
| `map-towns/sinic/gunpowder/town-big-b` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/gunpowder-town-big-b-sinic.glb |
| `map-towns/sinic/gunpowder/town-medium-a` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/gunpowder-town-medium-a-sinic.glb |
| `map-towns/sinic/gunpowder/town-medium-b` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/gunpowder-town-medium-b-sinic.glb |
| `map-towns/sinic/gunpowder/town-small-a` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/gunpowder-town-small-a-sinic.glb |
| `map-towns/sinic/gunpowder/town-small-b` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/gunpowder-town-small-b-sinic.glb |
| `map-towns/sinic/kingdoms/town-big-a` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/kingdoms-town-big-a-sinic.glb |
| `map-towns/sinic/kingdoms/town-big-b` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/kingdoms-town-big-b-sinic.glb |
| `map-towns/sinic/kingdoms/town-medium-a` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/kingdoms-town-medium-a-sinic.glb |
| `map-towns/sinic/kingdoms/town-medium-b` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/kingdoms-town-medium-b-sinic.glb |
| `map-towns/sinic/kingdoms/town-small-a` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/kingdoms-town-small-a-sinic.glb |
| `map-towns/sinic/kingdoms/town-small-b` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/kingdoms-town-small-b-sinic.glb |
| `map-towns/sinic/modern/town-big-a` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/modern-town-big-a-sinic.glb |
| `map-towns/sinic/modern/town-big-b` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/modern-town-big-b-sinic.glb |
| `map-towns/sinic/modern/town-medium-a` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/modern-town-medium-a-sinic.glb |
| `map-towns/sinic/modern/town-medium-b` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/modern-town-medium-b-sinic.glb |
| `map-towns/sinic/modern/town-small-a` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/modern-town-small-a-sinic.glb |
| `map-towns/sinic/modern/town-small-b` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/modern-town-small-b-sinic.glb |
| `map-towns/steppe/bronze/town-big-a` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/bronze-town-big-a-steppe.glb |
| `map-towns/steppe/bronze/town-big-b` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/bronze-town-big-b-steppe.glb |
| `map-towns/steppe/bronze/town-medium-a` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/bronze-town-medium-a-steppe.glb |
| `map-towns/steppe/bronze/town-medium-b` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/bronze-town-medium-b-steppe.glb |
| `map-towns/steppe/bronze/town-small-a` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/bronze-town-small-a-steppe.glb |
| `map-towns/steppe/bronze/town-small-b` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/bronze-town-small-b-steppe.glb |
| `map-towns/steppe/classical/town-big-a` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/classical-town-big-a-steppe.glb |
| `map-towns/steppe/classical/town-big-b` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/classical-town-big-b-steppe.glb |
| `map-towns/steppe/classical/town-medium-a` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/classical-town-medium-a-steppe.glb |
| `map-towns/steppe/classical/town-medium-b` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/classical-town-medium-b-steppe.glb |
| `map-towns/steppe/classical/town-small-a` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/classical-town-small-a-steppe.glb |
| `map-towns/steppe/classical/town-small-b` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/classical-town-small-b-steppe.glb |
| `map-towns/steppe/gunpowder/town-big-a` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/gunpowder-town-big-a-steppe.glb |
| `map-towns/steppe/gunpowder/town-big-b` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/gunpowder-town-big-b-steppe.glb |
| `map-towns/steppe/gunpowder/town-medium-a` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/gunpowder-town-medium-a-steppe.glb |
| `map-towns/steppe/gunpowder/town-medium-b` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/gunpowder-town-medium-b-steppe.glb |
| `map-towns/steppe/gunpowder/town-small-a` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/gunpowder-town-small-a-steppe.glb |
| `map-towns/steppe/gunpowder/town-small-b` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/gunpowder-town-small-b-steppe.glb |
| `map-towns/steppe/kingdoms/town-big-a` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/kingdoms-town-big-a-steppe.glb |
| `map-towns/steppe/kingdoms/town-big-b` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/kingdoms-town-big-b-steppe.glb |
| `map-towns/steppe/kingdoms/town-medium-a` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/kingdoms-town-medium-a-steppe.glb |
| `map-towns/steppe/kingdoms/town-medium-b` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/kingdoms-town-medium-b-steppe.glb |
| `map-towns/steppe/kingdoms/town-small-a` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/kingdoms-town-small-a-steppe.glb |
| `map-towns/steppe/kingdoms/town-small-b` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/kingdoms-town-small-b-steppe.glb |
| `map-towns/steppe/modern/town-big-a` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/modern-town-big-a-steppe.glb |
| `map-towns/steppe/modern/town-big-b` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/modern-town-big-b-steppe.glb |
| `map-towns/steppe/modern/town-medium-a` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/modern-town-medium-a-steppe.glb |
| `map-towns/steppe/modern/town-medium-b` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/modern-town-medium-b-steppe.glb |
| `map-towns/steppe/modern/town-small-a` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/modern-town-small-a-steppe.glb |
| `map-towns/steppe/modern/town-small-b` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/modern-town-small-b-steppe.glb |
| `map-towns/westafrica/bronze/town-big-a` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/bronze-town-big-a-westafrica.glb |
| `map-towns/westafrica/bronze/town-big-b` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/bronze-town-big-b-westafrica.glb |
| `map-towns/westafrica/bronze/town-medium-a` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/bronze-town-medium-a-westafrica.glb |
| `map-towns/westafrica/bronze/town-medium-b` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/bronze-town-medium-b-westafrica.glb |
| `map-towns/westafrica/bronze/town-small-a` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/bronze-town-small-a-westafrica.glb |
| `map-towns/westafrica/bronze/town-small-b` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/bronze-town-small-b-westafrica.glb |
| `map-towns/westafrica/classical/town-big-a` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/classical-town-big-a-westafrica.glb |
| `map-towns/westafrica/classical/town-big-b` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/classical-town-big-b-westafrica.glb |
| `map-towns/westafrica/classical/town-medium-a` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/classical-town-medium-a-westafrica.glb |
| `map-towns/westafrica/classical/town-medium-b` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/classical-town-medium-b-westafrica.glb |
| `map-towns/westafrica/classical/town-small-a` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/classical-town-small-a-westafrica.glb |
| `map-towns/westafrica/classical/town-small-b` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/classical-town-small-b-westafrica.glb |
| `map-towns/westafrica/gunpowder/town-big-a` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/gunpowder-town-big-a-westafrica.glb |
| `map-towns/westafrica/gunpowder/town-big-b` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/gunpowder-town-big-b-westafrica.glb |
| `map-towns/westafrica/gunpowder/town-medium-a` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/gunpowder-town-medium-a-westafrica.glb |
| `map-towns/westafrica/gunpowder/town-medium-b` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/gunpowder-town-medium-b-westafrica.glb |
| `map-towns/westafrica/gunpowder/town-small-a` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/gunpowder-town-small-a-westafrica.glb |
| `map-towns/westafrica/gunpowder/town-small-b` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/gunpowder-town-small-b-westafrica.glb |
| `map-towns/westafrica/kingdoms/town-big-a` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/kingdoms-town-big-a-westafrica.glb |
| `map-towns/westafrica/kingdoms/town-big-b` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/kingdoms-town-big-b-westafrica.glb |
| `map-towns/westafrica/kingdoms/town-medium-a` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/kingdoms-town-medium-a-westafrica.glb |
| `map-towns/westafrica/kingdoms/town-medium-b` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/kingdoms-town-medium-b-westafrica.glb |
| `map-towns/westafrica/kingdoms/town-small-a` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/kingdoms-town-small-a-westafrica.glb |
| `map-towns/westafrica/kingdoms/town-small-b` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/kingdoms-town-small-b-westafrica.glb |
| `map-towns/westafrica/modern/town-big-a` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/modern-town-big-a-westafrica.glb |
| `map-towns/westafrica/modern/town-big-b` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/modern-town-big-b-westafrica.glb |
| `map-towns/westafrica/modern/town-medium-a` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/modern-town-medium-a-westafrica.glb |
| `map-towns/westafrica/modern/town-medium-b` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/modern-town-medium-b-westafrica.glb |
| `map-towns/westafrica/modern/town-small-a` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/modern-town-small-a-westafrica.glb |
| `map-towns/westafrica/modern/town-small-b` | 3d | 2 | tracked_artifact_acceptance_verification | src/assets/map/towns/modern-town-small-b-westafrica.glb |
| `battle-city/classical/americas/houses-damage` | 3d | 3 | definitive_missing_declared_target | src/assets/battle/city/classical-americas-houses-damage.glb |
| `battle-city/classical/base/houses-damage` | 3d | 3 | definitive_missing_declared_target | src/assets/battle/city/classical-base-houses-damage.glb |
| `battle-city/classical/eastafrica/houses-damage` | 3d | 3 | definitive_missing_declared_target | src/assets/battle/city/classical-eastafrica-houses-damage.glb |
| `battle-city/classical/europe/houses-damage` | 3d | 3 | definitive_missing_declared_target | src/assets/battle/city/classical-europe-houses-damage.glb |
| `battle-city/classical/indic/houses-damage` | 3d | 3 | definitive_missing_declared_target | src/assets/battle/city/classical-indic-houses-damage.glb |
| `battle-city/classical/israelite/houses-damage` | 3d | 3 | definitive_missing_declared_target | src/assets/battle/city/classical-israelite-houses-damage.glb |
| `battle-city/classical/levant/houses-damage` | 3d | 3 | definitive_missing_declared_target | src/assets/battle/city/classical-levant-houses-damage.glb |
| `battle-city/classical/maghreb/houses-damage` | 3d | 3 | definitive_missing_declared_target | src/assets/battle/city/classical-maghreb-houses-damage.glb |
| `battle-city/classical/monsoon/houses-damage` | 3d | 3 | definitive_missing_declared_target | src/assets/battle/city/classical-monsoon-houses-damage.glb |
| `battle-city/classical/nile/houses-damage` | 3d | 3 | definitive_missing_declared_target | src/assets/battle/city/classical-nile-houses-damage.glb |
| `battle-city/classical/ruin-library` | 3d | 3 | definitive_missing_declared_target | src/assets/battle/city/ruins-classical.glb |
| `battle-city/classical/sinic/houses-damage` | 3d | 3 | definitive_missing_declared_target | src/assets/battle/city/classical-sinic-houses-damage.glb |
| `battle-city/classical/steppe/houses-damage` | 3d | 3 | definitive_missing_declared_target | src/assets/battle/city/classical-steppe-houses-damage.glb |
| `battle-city/classical/wall-kit` | 3d | 3 | definitive_missing_declared_target | src/assets/battle/city/walls-classical.glb |
| `battle-city/classical/westafrica/houses-damage` | 3d | 3 | definitive_missing_declared_target | src/assets/battle/city/classical-westafrica-houses-damage.glb |
| `battle-terrain/bridge-stone` | 3d | 3 | definitive_missing_declared_target | src/assets/battle/terrain/bridge-stone.glb |
| `fort/classical` | 3d | 3 | definitive_missing_declared_target | src/assets/battle/city/fort-classical.glb; src/assets/map/improvements/fort-classical.glb |
| `projectiles/classical` | 3d | 3 | definitive_missing_declared_target | src/assets/battle/projectiles/classical.glb |
| `props/classical` | 3d | 3 | definitive_missing_declared_target | src/assets/battle/props/props-classical.glb |
| `rts/classical/aid-post` | 3d | 3 | definitive_missing_declared_target | src/assets/battle/rts/rts-classical.glb |
| `rts/classical/barracks` | 3d | 3 | definitive_missing_declared_target | src/assets/battle/rts/rts-classical.glb |
| `rts/classical/construction-set` | 3d | 3 | definitive_missing_declared_target | src/assets/battle/rts/rts-classical.glb |
| `rts/classical/expedition-camp` | 3d | 3 | definitive_missing_declared_target | src/assets/battle/rts/rts-classical.glb |
| `rts/classical/farm-plot` | 3d | 3 | definitive_missing_declared_target | src/assets/battle/rts/rts-classical.glb |
| `rts/classical/food-depot` | 3d | 3 | definitive_missing_declared_target | src/assets/battle/rts/rts-classical.glb |
| `rts/classical/materials-yard` | 3d | 3 | definitive_missing_declared_target | src/assets/battle/rts/rts-classical.glb |
| `rts/classical/mine` | 3d | 3 | definitive_missing_declared_target | src/assets/battle/rts/rts-classical.glb |
| `rts/classical/range` | 3d | 3 | definitive_missing_declared_target | src/assets/battle/rts/rts-classical.glb |
| `rts/classical/siege-workshop` | 3d | 3 | definitive_missing_declared_target | src/assets/battle/rts/rts-classical.glb |
| `rts/classical/stable` | 3d | 3 | definitive_missing_declared_target | src/assets/battle/rts/rts-classical.glb |
| `rts/classical/tower` | 3d | 3 | definitive_missing_declared_target | src/assets/battle/rts/rts-classical.glb |
| `rts/classical/town-hall` | 3d | 3 | definitive_missing_declared_target | src/assets/battle/rts/rts-classical.glb |
| `rts/classical/trade-post` | 3d | 3 | definitive_missing_declared_target | src/assets/battle/rts/rts-classical.glb |
| `unit-rigs/camel` | 3d | 3 | required_scope_binding_verification | binding unresolved; camel |
| `unit-rigs/elephant` | 3d | 3 | required_scope_binding_verification | binding unresolved; elephant |
| `units/classical-cavalry` | 3d | 3 | definitive_missing_declared_target | src/assets/units/classical-cavalry.glb |
| `units/classical-general` | 3d | 3 | definitive_missing_declared_target | src/assets/units/classical-general.glb |
| `units/classical-infantry` | 3d | 3 | definitive_missing_declared_target | src/assets/units/classical-infantry.glb |
| `units/classical-mercenary` | 3d | 3 | definitive_missing_declared_target | src/assets/units/classical-mercenary.glb |
| `units/classical-raider` | 3d | 3 | definitive_missing_declared_target | src/assets/units/classical-raider.glb |
| `units/classical-ranged` | 3d | 3 | definitive_missing_declared_target | src/assets/units/classical-ranged.glb |
| `units/classical-siege` | 3d | 3 | definitive_missing_declared_target | src/assets/units/classical-siege.glb |
| `units/classical-support` | 3d | 3 | definitive_missing_declared_target | src/assets/units/classical-support.glb |
| `units/classical-worker` | 3d | 3 | definitive_missing_declared_target | src/assets/units/classical-worker.glb |
| `units/signature/aghvank` | 3d | 3 | definitive_missing_declared_target | src/assets/units/signature/aghvank.glb |
| `units/signature/arverni` | 3d | 3 | definitive_missing_declared_target | src/assets/units/signature/arverni.glb |
| `units/signature/avanti` | 3d | 3 | definitive_missing_declared_target | src/assets/units/signature/avanti.glb |
| `units/signature/bactria` | 3d | 3 | definitive_missing_declared_target | src/assets/units/signature/bactria.glb |
| `units/signature/belgae` | 3d | 3 | definitive_missing_declared_target | src/assets/units/signature/belgae.glb |
| `units/signature/bosporan-kingdom` | 3d | 3 | definitive_missing_declared_target | src/assets/units/signature/bosporan-kingdom.glb |
| `units/signature/brigantes` | 3d | 3 | definitive_missing_declared_target | src/assets/units/signature/brigantes.glb |
| `units/signature/buyeo` | 3d | 3 | definitive_missing_declared_target | src/assets/units/signature/buyeo.glb |
| `units/signature/cherusci` | 3d | 3 | definitive_missing_declared_target | src/assets/units/signature/cherusci.glb |
| `units/signature/chu` | 3d | 3 | definitive_missing_declared_target | src/assets/units/signature/chu.glb |
| `units/signature/cyrene` | 3d | 3 | definitive_missing_declared_target | src/assets/units/signature/cyrene.glb |
| `units/signature/dian` | 3d | 3 | definitive_missing_declared_target | src/assets/units/signature/dian.glb |
| `units/signature/durotriges` | 3d | 3 | definitive_missing_declared_target | src/assets/units/signature/durotriges.glb |
| `units/signature/hopewell` | 3d | 3 | definitive_missing_declared_target | src/assets/units/signature/hopewell.glb |
| `units/signature/kalinga` | 3d | 3 | definitive_missing_declared_target | src/assets/units/signature/kalinga.glb |
| `units/signature/kosala` | 3d | 3 | definitive_missing_declared_target | src/assets/units/signature/kosala.glb |
| `units/signature/kroraina` | 3d | 3 | definitive_missing_declared_target | src/assets/units/signature/kroraina.glb |
| `units/signature/lydia` | 3d | 3 | definitive_missing_declared_target | src/assets/units/signature/lydia.glb |
| `units/signature/magadha` | 3d | 3 | definitive_missing_declared_target | src/assets/units/signature/magadha.glb |
| `units/signature/mauretania` | 3d | 3 | definitive_missing_declared_target | src/assets/units/signature/mauretania.glb |
| `units/signature/media` | 3d | 3 | definitive_missing_declared_target | src/assets/units/signature/media.glb |
| `units/signature/nabataea` | 3d | 3 | definitive_missing_declared_target | src/assets/units/signature/nabataea.glb |
| `units/signature/nanyue` | 3d | 3 | definitive_missing_declared_target | src/assets/units/signature/nanyue.glb |
| `units/signature/nok` | 3d | 3 | definitive_missing_declared_target | src/assets/units/signature/nok.glb |
| `units/signature/numidia` | 3d | 3 | definitive_missing_declared_target | src/assets/units/signature/numidia.glb |
| `units/signature/parthava` | 3d | 3 | definitive_missing_declared_target | src/assets/units/signature/parthava.glb |
| `units/signature/pontus` | 3d | 3 | definitive_missing_declared_target | src/assets/units/signature/pontus.glb |
| `units/signature/qedar` | 3d | 3 | definitive_missing_declared_target | src/assets/units/signature/qedar.glb |
| `units/signature/qi` | 3d | 3 | definitive_missing_declared_target | src/assets/units/signature/qi.glb |
| `units/signature/rasenna` | 3d | 3 | definitive_missing_declared_target | src/assets/units/signature/rasenna.glb |
| `units/signature/saba` | 3d | 3 | definitive_missing_declared_target | src/assets/units/signature/saba.glb |
| `units/signature/satavahana` | 3d | 3 | definitive_missing_declared_target | src/assets/units/signature/satavahana.glb |
| `units/signature/teotihuacan` | 3d | 3 | definitive_missing_declared_target | src/assets/units/signature/teotihuacan.glb |
| `units/signature/wusun` | 3d | 3 | definitive_missing_declared_target | src/assets/units/signature/wusun.glb |
| `units/signature/xianbei` | 3d | 3 | definitive_missing_declared_target | src/assets/units/signature/xianbei.glb |
| `units/signature/yamatai` | 3d | 3 | definitive_missing_declared_target | src/assets/units/signature/yamatai.glb |
| `units/signature/yue` | 3d | 3 | definitive_missing_declared_target | src/assets/units/signature/yue.glb |
| `units/signature/zapotec` | 3d | 3 | definitive_missing_declared_target | src/assets/units/signature/zapotec.glb |
| `battle-city/kingdoms/americas/houses-damage` | 3d | 4 | definitive_missing_declared_target | src/assets/battle/city/kingdoms-americas-houses-damage.glb |
| `battle-city/kingdoms/base/houses-damage` | 3d | 4 | definitive_missing_declared_target | src/assets/battle/city/kingdoms-base-houses-damage.glb |
| `battle-city/kingdoms/eastafrica/houses-damage` | 3d | 4 | definitive_missing_declared_target | src/assets/battle/city/kingdoms-eastafrica-houses-damage.glb |
| `battle-city/kingdoms/europe/houses-damage` | 3d | 4 | definitive_missing_declared_target | src/assets/battle/city/kingdoms-europe-houses-damage.glb |
| `battle-city/kingdoms/indic/houses-damage` | 3d | 4 | definitive_missing_declared_target | src/assets/battle/city/kingdoms-indic-houses-damage.glb |
| `battle-city/kingdoms/israelite/houses-damage` | 3d | 4 | definitive_missing_declared_target | src/assets/battle/city/kingdoms-israelite-houses-damage.glb |
| `battle-city/kingdoms/levant/houses-damage` | 3d | 4 | definitive_missing_declared_target | src/assets/battle/city/kingdoms-levant-houses-damage.glb |
| `battle-city/kingdoms/maghreb/houses-damage` | 3d | 4 | definitive_missing_declared_target | src/assets/battle/city/kingdoms-maghreb-houses-damage.glb |
| `battle-city/kingdoms/monsoon/houses-damage` | 3d | 4 | definitive_missing_declared_target | src/assets/battle/city/kingdoms-monsoon-houses-damage.glb |
| `battle-city/kingdoms/nile/houses-damage` | 3d | 4 | definitive_missing_declared_target | src/assets/battle/city/kingdoms-nile-houses-damage.glb |
| `battle-city/kingdoms/ruin-library` | 3d | 4 | definitive_missing_declared_target | src/assets/battle/city/ruins-kingdoms.glb |
| `battle-city/kingdoms/sinic/houses-damage` | 3d | 4 | definitive_missing_declared_target | src/assets/battle/city/kingdoms-sinic-houses-damage.glb |
| `battle-city/kingdoms/steppe/houses-damage` | 3d | 4 | definitive_missing_declared_target | src/assets/battle/city/kingdoms-steppe-houses-damage.glb |
| `battle-city/kingdoms/wall-kit` | 3d | 4 | definitive_missing_declared_target | src/assets/battle/city/walls-kingdoms.glb |
| `battle-city/kingdoms/westafrica/houses-damage` | 3d | 4 | definitive_missing_declared_target | src/assets/battle/city/kingdoms-westafrica-houses-damage.glb |
| `fort/kingdoms` | 3d | 4 | definitive_missing_declared_target | src/assets/battle/city/fort-kingdoms.glb; src/assets/map/improvements/fort-kingdoms.glb |
| `projectiles/kingdoms` | 3d | 4 | definitive_missing_declared_target | src/assets/battle/projectiles/kingdoms.glb |
| `props/kingdoms` | 3d | 4 | definitive_missing_declared_target | src/assets/battle/props/props-kingdoms.glb |
| `rts/kingdoms/aid-post` | 3d | 4 | definitive_missing_declared_target | src/assets/battle/rts/rts-kingdoms.glb |
| `rts/kingdoms/barracks` | 3d | 4 | definitive_missing_declared_target | src/assets/battle/rts/rts-kingdoms.glb |
| `rts/kingdoms/construction-set` | 3d | 4 | definitive_missing_declared_target | src/assets/battle/rts/rts-kingdoms.glb |
| `rts/kingdoms/expedition-camp` | 3d | 4 | definitive_missing_declared_target | src/assets/battle/rts/rts-kingdoms.glb |
| `rts/kingdoms/farm-plot` | 3d | 4 | definitive_missing_declared_target | src/assets/battle/rts/rts-kingdoms.glb |
| `rts/kingdoms/food-depot` | 3d | 4 | definitive_missing_declared_target | src/assets/battle/rts/rts-kingdoms.glb |
| `rts/kingdoms/materials-yard` | 3d | 4 | definitive_missing_declared_target | src/assets/battle/rts/rts-kingdoms.glb |
| `rts/kingdoms/mine` | 3d | 4 | definitive_missing_declared_target | src/assets/battle/rts/rts-kingdoms.glb |
| `rts/kingdoms/range` | 3d | 4 | definitive_missing_declared_target | src/assets/battle/rts/rts-kingdoms.glb |
| `rts/kingdoms/siege-workshop` | 3d | 4 | definitive_missing_declared_target | src/assets/battle/rts/rts-kingdoms.glb |
| `rts/kingdoms/stable` | 3d | 4 | definitive_missing_declared_target | src/assets/battle/rts/rts-kingdoms.glb |
| `rts/kingdoms/tower` | 3d | 4 | definitive_missing_declared_target | src/assets/battle/rts/rts-kingdoms.glb |
| `rts/kingdoms/town-hall` | 3d | 4 | definitive_missing_declared_target | src/assets/battle/rts/rts-kingdoms.glb |
| `rts/kingdoms/trade-post` | 3d | 4 | definitive_missing_declared_target | src/assets/battle/rts/rts-kingdoms.glb |
| `units/kingdoms-cavalry` | 3d | 4 | definitive_missing_declared_target | src/assets/units/kingdoms-cavalry.glb |
| `units/kingdoms-general` | 3d | 4 | definitive_missing_declared_target | src/assets/units/kingdoms-general.glb |
| `units/kingdoms-infantry` | 3d | 4 | definitive_missing_declared_target | src/assets/units/kingdoms-infantry.glb |
| `units/kingdoms-mercenary` | 3d | 4 | definitive_missing_declared_target | src/assets/units/kingdoms-mercenary.glb |
| `units/kingdoms-raider` | 3d | 4 | definitive_missing_declared_target | src/assets/units/kingdoms-raider.glb |
| `units/kingdoms-ranged` | 3d | 4 | definitive_missing_declared_target | src/assets/units/kingdoms-ranged.glb |
| `units/kingdoms-siege` | 3d | 4 | definitive_missing_declared_target | src/assets/units/kingdoms-siege.glb |
| `units/kingdoms-support` | 3d | 4 | definitive_missing_declared_target | src/assets/units/kingdoms-support.glb |
| `units/kingdoms-worker` | 3d | 4 | definitive_missing_declared_target | src/assets/units/kingdoms-worker.glb |
| `units/signature/alodia` | 3d | 4 | definitive_missing_declared_target | src/assets/units/signature/alodia.glb |
| `units/signature/baekje` | 3d | 4 | definitive_missing_declared_target | src/assets/units/signature/baekje.glb |
| `units/signature/butuan` | 3d | 4 | definitive_missing_declared_target | src/assets/units/signature/butuan.glb |
| `units/signature/chaco` | 3d | 4 | definitive_missing_declared_target | src/assets/units/signature/chaco.glb |
| `units/signature/champa` | 3d | 4 | definitive_missing_declared_target | src/assets/units/signature/champa.glb |
| `units/signature/djenne-djeno` | 3d | 4 | definitive_missing_declared_target | src/assets/units/signature/djenne-djeno.glb |
| `units/signature/dvaravati` | 3d | 4 | definitive_missing_declared_target | src/assets/units/signature/dvaravati.glb |
| `units/signature/emishi` | 3d | 4 | definitive_missing_declared_target | src/assets/units/signature/emishi.glb |
| `units/signature/engaruka` | 3d | 4 | definitive_missing_declared_target | src/assets/units/signature/engaruka.glb |
| `units/signature/funan` | 3d | 4 | definitive_missing_declared_target | src/assets/units/signature/funan.glb |
| `units/signature/gokturk` | 3d | 4 | definitive_missing_declared_target | src/assets/units/signature/gokturk.glb |
| `units/signature/hohokam` | 3d | 4 | definitive_missing_declared_target | src/assets/units/signature/hohokam.glb |
| `units/signature/ife` | 3d | 4 | definitive_missing_declared_target | src/assets/units/signature/ife.glb |
| `units/signature/kamarupa` | 3d | 4 | definitive_missing_declared_target | src/assets/units/signature/kamarupa.glb |
| `units/signature/khazaria` | 3d | 4 | definitive_missing_declared_target | src/assets/units/signature/khazaria.glb |
| `units/signature/khotan` | 3d | 4 | definitive_missing_declared_target | src/assets/units/signature/khotan.glb |
| `units/signature/khwarazm` | 3d | 4 | definitive_missing_declared_target | src/assets/units/signature/khwarazm.glb |
| `units/signature/kitara` | 3d | 4 | definitive_missing_declared_target | src/assets/units/signature/kitara.glb |
| `units/signature/mapungubwe` | 3d | 4 | definitive_missing_declared_target | src/assets/units/signature/mapungubwe.glb |
| `units/signature/marajoara` | 3d | 4 | definitive_missing_declared_target | src/assets/units/signature/marajoara.glb |
| `units/signature/moche` | 3d | 4 | definitive_missing_declared_target | src/assets/units/signature/moche.glb |
| `units/signature/mutal` | 3d | 4 | definitive_missing_declared_target | src/assets/units/signature/mutal.glb |
| `units/signature/pandya` | 3d | 4 | definitive_missing_declared_target | src/assets/units/signature/pandya.glb |
| `units/signature/pyu` | 3d | 4 | definitive_missing_declared_target | src/assets/units/signature/pyu.glb |
| `units/signature/rajarata` | 3d | 4 | definitive_missing_declared_target | src/assets/units/signature/rajarata.glb |
| `units/signature/san` | 3d | 4 | definitive_missing_declared_target | src/assets/units/signature/san.glb |
| `units/signature/saudeleur` | 3d | 4 | definitive_missing_declared_target | src/assets/units/signature/saudeleur.glb |
| `units/signature/sogdia` | 3d | 4 | definitive_missing_declared_target | src/assets/units/signature/sogdia.glb |
| `units/signature/srivijaya` | 3d | 4 | definitive_missing_declared_target | src/assets/units/signature/srivijaya.glb |
| `units/signature/tarumanagara` | 3d | 4 | definitive_missing_declared_target | src/assets/units/signature/tarumanagara.glb |
| `units/signature/tiwanaku` | 3d | 4 | definitive_missing_declared_target | src/assets/units/signature/tiwanaku.glb |
| `units/signature/vanga` | 3d | 4 | definitive_missing_declared_target | src/assets/units/signature/vanga.glb |
| `units/signature/wagadu` | 3d | 4 | definitive_missing_declared_target | src/assets/units/signature/wagadu.glb |
| `units/signature/wari` | 3d | 4 | definitive_missing_declared_target | src/assets/units/signature/wari.glb |
| `units/signature/yarlung` | 3d | 4 | definitive_missing_declared_target | src/assets/units/signature/yarlung.glb |
| `units/signature/zhangzhung` | 3d | 4 | definitive_missing_declared_target | src/assets/units/signature/zhangzhung.glb |
| `battle-city/gunpowder/americas/houses-damage` | 3d | 5 | definitive_missing_declared_target | src/assets/battle/city/gunpowder-americas-houses-damage.glb |
| `battle-city/gunpowder/base/houses-damage` | 3d | 5 | definitive_missing_declared_target | src/assets/battle/city/gunpowder-base-houses-damage.glb |
| `battle-city/gunpowder/eastafrica/houses-damage` | 3d | 5 | definitive_missing_declared_target | src/assets/battle/city/gunpowder-eastafrica-houses-damage.glb |
| `battle-city/gunpowder/europe/houses-damage` | 3d | 5 | definitive_missing_declared_target | src/assets/battle/city/gunpowder-europe-houses-damage.glb |
| `battle-city/gunpowder/indic/houses-damage` | 3d | 5 | definitive_missing_declared_target | src/assets/battle/city/gunpowder-indic-houses-damage.glb |
| `battle-city/gunpowder/israelite/houses-damage` | 3d | 5 | definitive_missing_declared_target | src/assets/battle/city/gunpowder-israelite-houses-damage.glb |
| `battle-city/gunpowder/levant/houses-damage` | 3d | 5 | definitive_missing_declared_target | src/assets/battle/city/gunpowder-levant-houses-damage.glb |
| `battle-city/gunpowder/maghreb/houses-damage` | 3d | 5 | definitive_missing_declared_target | src/assets/battle/city/gunpowder-maghreb-houses-damage.glb |
| `battle-city/gunpowder/monsoon/houses-damage` | 3d | 5 | definitive_missing_declared_target | src/assets/battle/city/gunpowder-monsoon-houses-damage.glb |
| `battle-city/gunpowder/nile/houses-damage` | 3d | 5 | definitive_missing_declared_target | src/assets/battle/city/gunpowder-nile-houses-damage.glb |
| `battle-city/gunpowder/ruin-library` | 3d | 5 | definitive_missing_declared_target | src/assets/battle/city/ruins-gunpowder.glb |
| `battle-city/gunpowder/sinic/houses-damage` | 3d | 5 | definitive_missing_declared_target | src/assets/battle/city/gunpowder-sinic-houses-damage.glb |
| `battle-city/gunpowder/steppe/houses-damage` | 3d | 5 | definitive_missing_declared_target | src/assets/battle/city/gunpowder-steppe-houses-damage.glb |
| `battle-city/gunpowder/wall-kit` | 3d | 5 | definitive_missing_declared_target | src/assets/battle/city/walls-gunpowder.glb |
| `battle-city/gunpowder/westafrica/houses-damage` | 3d | 5 | definitive_missing_declared_target | src/assets/battle/city/gunpowder-westafrica-houses-damage.glb |
| `fort/gunpowder` | 3d | 5 | definitive_missing_declared_target | src/assets/battle/city/fort-gunpowder.glb; src/assets/map/improvements/fort-gunpowder.glb |
| `projectiles/gunpowder` | 3d | 5 | definitive_missing_declared_target | src/assets/battle/projectiles/gunpowder.glb |
| `props/gunpowder` | 3d | 5 | definitive_missing_declared_target | src/assets/battle/props/props-gunpowder.glb |
| `rts/gunpowder/aid-post` | 3d | 5 | definitive_missing_declared_target | src/assets/battle/rts/rts-gunpowder.glb |
| `rts/gunpowder/barracks` | 3d | 5 | definitive_missing_declared_target | src/assets/battle/rts/rts-gunpowder.glb |
| `rts/gunpowder/construction-set` | 3d | 5 | definitive_missing_declared_target | src/assets/battle/rts/rts-gunpowder.glb |
| `rts/gunpowder/expedition-camp` | 3d | 5 | definitive_missing_declared_target | src/assets/battle/rts/rts-gunpowder.glb |
| `rts/gunpowder/farm-plot` | 3d | 5 | definitive_missing_declared_target | src/assets/battle/rts/rts-gunpowder.glb |
| `rts/gunpowder/food-depot` | 3d | 5 | definitive_missing_declared_target | src/assets/battle/rts/rts-gunpowder.glb |
| `rts/gunpowder/materials-yard` | 3d | 5 | definitive_missing_declared_target | src/assets/battle/rts/rts-gunpowder.glb |
| `rts/gunpowder/mine` | 3d | 5 | definitive_missing_declared_target | src/assets/battle/rts/rts-gunpowder.glb |
| `rts/gunpowder/range` | 3d | 5 | definitive_missing_declared_target | src/assets/battle/rts/rts-gunpowder.glb |
| `rts/gunpowder/siege-workshop` | 3d | 5 | definitive_missing_declared_target | src/assets/battle/rts/rts-gunpowder.glb |
| `rts/gunpowder/stable` | 3d | 5 | definitive_missing_declared_target | src/assets/battle/rts/rts-gunpowder.glb |
| `rts/gunpowder/tower` | 3d | 5 | definitive_missing_declared_target | src/assets/battle/rts/rts-gunpowder.glb |
| `rts/gunpowder/town-hall` | 3d | 5 | definitive_missing_declared_target | src/assets/battle/rts/rts-gunpowder.glb |
| `rts/gunpowder/trade-post` | 3d | 5 | definitive_missing_declared_target | src/assets/battle/rts/rts-gunpowder.glb |
| `units/gunpowder-cavalry` | 3d | 5 | definitive_missing_declared_target | src/assets/units/gunpowder-cavalry.glb |
| `units/gunpowder-general` | 3d | 5 | definitive_missing_declared_target | src/assets/units/gunpowder-general.glb |
| `units/gunpowder-infantry` | 3d | 5 | definitive_missing_declared_target | src/assets/units/gunpowder-infantry.glb |
| `units/gunpowder-mercenary` | 3d | 5 | definitive_missing_declared_target | src/assets/units/gunpowder-mercenary.glb |
| `units/gunpowder-raider` | 3d | 5 | definitive_missing_declared_target | src/assets/units/gunpowder-raider.glb |
| `units/gunpowder-ranged` | 3d | 5 | definitive_missing_declared_target | src/assets/units/gunpowder-ranged.glb |
| `units/gunpowder-siege` | 3d | 5 | definitive_missing_declared_target | src/assets/units/gunpowder-siege.glb |
| `units/gunpowder-support` | 3d | 5 | definitive_missing_declared_target | src/assets/units/gunpowder-support.glb |
| `units/gunpowder-worker` | 3d | 5 | definitive_missing_declared_target | src/assets/units/gunpowder-worker.glb |
| `units/signature/ajuran` | 3d | 5 | definitive_missing_declared_target | src/assets/units/signature/ajuran.glb |
| `units/signature/avaria` | 3d | 5 | definitive_missing_declared_target | src/assets/units/signature/avaria.glb |
| `units/signature/bau` | 3d | 5 | definitive_missing_declared_target | src/assets/units/signature/bau.glb |
| `units/signature/bono` | 3d | 5 | definitive_missing_declared_target | src/assets/units/signature/bono.glb |
| `units/signature/calusa` | 3d | 5 | definitive_missing_declared_target | src/assets/units/signature/calusa.glb |
| `units/signature/celtiberia` | 3d | 5 | definitive_missing_declared_target | src/assets/units/signature/celtiberia.glb |
| `units/signature/diaguita` | 3d | 5 | definitive_missing_declared_target | src/assets/units/signature/diaguita.glb |
| `units/signature/fortriu` | 3d | 5 | definitive_missing_declared_target | src/assets/units/signature/fortriu.glb |
| `units/signature/gandhara` | 3d | 5 | definitive_missing_declared_target | src/assets/units/signature/gandhara.glb |
| `units/signature/geats` | 3d | 5 | definitive_missing_declared_target | src/assets/units/signature/geats.glb |
| `units/signature/gunditjmara` | 3d | 5 | definitive_missing_declared_target | src/assets/units/signature/gunditjmara.glb |
| `units/signature/haida` | 3d | 5 | definitive_missing_declared_target | src/assets/units/signature/haida.glb |
| `units/signature/jaragua` | 3d | 5 | definitive_missing_declared_target | src/assets/units/signature/jaragua.glb |
| `units/signature/kalinago` | 3d | 5 | definitive_missing_declared_target | src/assets/units/signature/kalinago.glb |
| `units/signature/kanem` | 3d | 5 | definitive_missing_declared_target | src/assets/units/signature/kanem.glb |
| `units/signature/khoekhoe` | 3d | 5 | definitive_missing_declared_target | src/assets/units/signature/khoekhoe.glb |
| `units/signature/kilwa` | 3d | 5 | definitive_missing_declared_target | src/assets/units/signature/kilwa.glb |
| `units/signature/kutai` | 3d | 5 | definitive_missing_declared_target | src/assets/units/signature/kutai.glb |
| `units/signature/latte-chiefs` | 3d | 5 | definitive_missing_declared_target | src/assets/units/signature/latte-chiefs.glb |
| `units/signature/luba` | 3d | 5 | definitive_missing_declared_target | src/assets/units/signature/luba.glb |
| `units/signature/lunda` | 3d | 5 | definitive_missing_declared_target | src/assets/units/signature/lunda.glb |
| `units/signature/lusitania` | 3d | 5 | definitive_missing_declared_target | src/assets/units/signature/lusitania.glb |
| `units/signature/medang` | 3d | 5 | definitive_missing_declared_target | src/assets/units/signature/medang.glb |
| `units/signature/merina` | 3d | 5 | definitive_missing_declared_target | src/assets/units/signature/merina.glb |
| `units/signature/muisca` | 3d | 5 | definitive_missing_declared_target | src/assets/units/signature/muisca.glb |
| `units/signature/mutapa` | 3d | 5 | definitive_missing_declared_target | src/assets/units/signature/mutapa.glb |
| `units/signature/ndongo` | 3d | 5 | definitive_missing_declared_target | src/assets/units/signature/ndongo.glb |
| `units/signature/odrysia` | 3d | 5 | definitive_missing_declared_target | src/assets/units/signature/odrysia.glb |
| `units/signature/sarmatians` | 3d | 5 | definitive_missing_declared_target | src/assets/units/signature/sarmatians.glb |
| `units/signature/tondo` | 3d | 5 | definitive_missing_declared_target | src/assets/units/signature/tondo.glb |
| `units/signature/tupinamba` | 3d | 5 | definitive_missing_declared_target | src/assets/units/signature/tupinamba.glb |
| `units/signature/ulaid` | 3d | 5 | definitive_missing_declared_target | src/assets/units/signature/ulaid.glb |
| `battle-city/modern/americas/houses-damage` | 3d | 6 | definitive_missing_declared_target | src/assets/battle/city/modern-americas-houses-damage.glb |
| `battle-city/modern/base/houses-damage` | 3d | 6 | definitive_missing_declared_target | src/assets/battle/city/modern-base-houses-damage.glb |
| `battle-city/modern/eastafrica/houses-damage` | 3d | 6 | definitive_missing_declared_target | src/assets/battle/city/modern-eastafrica-houses-damage.glb |
| `battle-city/modern/europe/houses-damage` | 3d | 6 | definitive_missing_declared_target | src/assets/battle/city/modern-europe-houses-damage.glb |
| `battle-city/modern/indic/houses-damage` | 3d | 6 | definitive_missing_declared_target | src/assets/battle/city/modern-indic-houses-damage.glb |
| `battle-city/modern/israelite/houses-damage` | 3d | 6 | definitive_missing_declared_target | src/assets/battle/city/modern-israelite-houses-damage.glb |
| `battle-city/modern/levant/houses-damage` | 3d | 6 | definitive_missing_declared_target | src/assets/battle/city/modern-levant-houses-damage.glb |
| `battle-city/modern/maghreb/houses-damage` | 3d | 6 | definitive_missing_declared_target | src/assets/battle/city/modern-maghreb-houses-damage.glb |
| `battle-city/modern/monsoon/houses-damage` | 3d | 6 | definitive_missing_declared_target | src/assets/battle/city/modern-monsoon-houses-damage.glb |
| `battle-city/modern/nile/houses-damage` | 3d | 6 | definitive_missing_declared_target | src/assets/battle/city/modern-nile-houses-damage.glb |
| `battle-city/modern/ruin-library` | 3d | 6 | definitive_missing_declared_target | src/assets/battle/city/ruins-modern.glb |
| `battle-city/modern/sinic/houses-damage` | 3d | 6 | definitive_missing_declared_target | src/assets/battle/city/modern-sinic-houses-damage.glb |
| `battle-city/modern/steppe/houses-damage` | 3d | 6 | definitive_missing_declared_target | src/assets/battle/city/modern-steppe-houses-damage.glb |
| `battle-city/modern/wall-kit` | 3d | 6 | definitive_missing_declared_target | src/assets/battle/city/walls-modern.glb |
| `battle-city/modern/westafrica/houses-damage` | 3d | 6 | definitive_missing_declared_target | src/assets/battle/city/modern-westafrica-houses-damage.glb |
| `battle-terrain/bridge-steel` | 3d | 6 | definitive_missing_declared_target | src/assets/battle/terrain/bridge-steel.glb |
| `fort/modern` | 3d | 6 | definitive_missing_declared_target | src/assets/battle/city/fort-modern.glb; src/assets/map/improvements/fort-modern.glb |
| `projectiles/modern` | 3d | 6 | definitive_missing_declared_target | src/assets/battle/projectiles/modern.glb |
| `props/modern` | 3d | 6 | definitive_missing_declared_target | src/assets/battle/props/props-modern.glb |
| `rts/modern/aid-post` | 3d | 6 | definitive_missing_declared_target | src/assets/battle/rts/rts-modern.glb |
| `rts/modern/airfield` | 3d | 6 | definitive_missing_declared_target | src/assets/battle/rts/rts-modern.glb |
| `rts/modern/barracks` | 3d | 6 | definitive_missing_declared_target | src/assets/battle/rts/rts-modern.glb |
| `rts/modern/construction-set` | 3d | 6 | definitive_missing_declared_target | src/assets/battle/rts/rts-modern.glb |
| `rts/modern/expedition-camp` | 3d | 6 | definitive_missing_declared_target | src/assets/battle/rts/rts-modern.glb |
| `rts/modern/farm-plot` | 3d | 6 | definitive_missing_declared_target | src/assets/battle/rts/rts-modern.glb |
| `rts/modern/food-depot` | 3d | 6 | definitive_missing_declared_target | src/assets/battle/rts/rts-modern.glb |
| `rts/modern/generator` | 3d | 6 | definitive_missing_declared_target | src/assets/battle/rts/rts-modern.glb |
| `rts/modern/materials-yard` | 3d | 6 | definitive_missing_declared_target | src/assets/battle/rts/rts-modern.glb |
| `rts/modern/mine` | 3d | 6 | definitive_missing_declared_target | src/assets/battle/rts/rts-modern.glb |
| `rts/modern/radar-aa` | 3d | 6 | definitive_missing_declared_target | src/assets/battle/rts/rts-modern.glb |
| `rts/modern/range` | 3d | 6 | definitive_missing_declared_target | src/assets/battle/rts/rts-modern.glb |
| `rts/modern/siege-workshop` | 3d | 6 | definitive_missing_declared_target | src/assets/battle/rts/rts-modern.glb |
| `rts/modern/stable` | 3d | 6 | definitive_missing_declared_target | src/assets/battle/rts/rts-modern.glb |
| `rts/modern/tower` | 3d | 6 | definitive_missing_declared_target | src/assets/battle/rts/rts-modern.glb |
| `rts/modern/town-hall` | 3d | 6 | definitive_missing_declared_target | src/assets/battle/rts/rts-modern.glb |
| `rts/modern/trade-post` | 3d | 6 | definitive_missing_declared_target | src/assets/battle/rts/rts-modern.glb |
| `units/modern-air` | 3d | 6 | definitive_missing_declared_target | src/assets/units/modern-air.glb |
| `units/modern-cavalry` | 3d | 6 | definitive_missing_declared_target | src/assets/units/modern-cavalry.glb |
| `units/modern-general` | 3d | 6 | definitive_missing_declared_target | src/assets/units/modern-general.glb |
| `units/modern-infantry` | 3d | 6 | definitive_missing_declared_target | src/assets/units/modern-infantry.glb |
| `units/modern-mercenary` | 3d | 6 | definitive_missing_declared_target | src/assets/units/modern-mercenary.glb |
| `units/modern-raider` | 3d | 6 | definitive_missing_declared_target | src/assets/units/modern-raider.glb |
| `units/modern-ranged` | 3d | 6 | definitive_missing_declared_target | src/assets/units/modern-ranged.glb |
| `units/modern-siege` | 3d | 6 | definitive_missing_declared_target | src/assets/units/modern-siege.glb |
| `units/modern-support` | 3d | 6 | definitive_missing_declared_target | src/assets/units/modern-support.glb |
| `units/modern-worker` | 3d | 6 | definitive_missing_declared_target | src/assets/units/modern-worker.glb |
| `units/signature/d-mt` | 3d | 6 | definitive_missing_declared_target | src/assets/units/signature/d-mt.glb |
| `units/signature/dacia` | 3d | 6 | definitive_missing_declared_target | src/assets/units/signature/dacia.glb |
| `units/signature/dorset` | 3d | 6 | definitive_missing_declared_target | src/assets/units/signature/dorset.glb |
| `units/signature/illyria` | 3d | 6 | definitive_missing_declared_target | src/assets/units/signature/illyria.glb |
| `units/signature/kindah` | 3d | 6 | definitive_missing_declared_target | src/assets/units/signature/kindah.glb |
| `units/signature/kingdom-of-israel` | 3d | 6 | definitive_missing_declared_target | src/assets/units/signature/kingdom-of-israel.glb |
| `units/signature/marcomannia` | 3d | 6 | definitive_missing_declared_target | src/assets/units/signature/marcomannia.glb |
| `units/signature/noricum` | 3d | 6 | definitive_missing_declared_target | src/assets/units/signature/noricum.glb |
| `units/signature/nuragi` | 3d | 6 | definitive_missing_declared_target | src/assets/units/signature/nuragi.glb |
| `units/signature/rygir` | 3d | 6 | definitive_missing_declared_target | src/assets/units/signature/rygir.glb |
| `battle-city/bronze/palace-damage` | 3d | 7 | definitive_missing_declared_target | src/assets/battle/city/palace-damage-bronze.glb |
| `battle-city/classical/palace-damage` | 3d | 7 | definitive_missing_declared_target | src/assets/battle/city/palace-damage-classical.glb |
| `battle-city/gunpowder/palace-damage` | 3d | 7 | definitive_missing_declared_target | src/assets/battle/city/palace-damage-gunpowder.glb |
| `battle-city/kingdoms/palace-damage` | 3d | 7 | definitive_missing_declared_target | src/assets/battle/city/palace-damage-kingdoms.glb |
| `battle-city/modern/palace-damage` | 3d | 7 | definitive_missing_declared_target | src/assets/battle/city/palace-damage-modern.glb |
| `battle-city/wonders/arsenal-ruin` | 3d | 7 | tracked_artifact_acceptance_verification | src/assets/map/wonders/arsenal.glb |
| `battle-city/wonders/atomic_research_center-ruin` | 3d | 7 | tracked_artifact_acceptance_verification | src/assets/map/wonders/atomic_research_center.glb |
| `battle-city/wonders/colosseum-ruin` | 3d | 7 | tracked_artifact_acceptance_verification | src/assets/map/wonders/colosseum.glb |
| `battle-city/wonders/forbidden_city-ruin` | 3d | 7 | tracked_artifact_acceptance_verification | src/assets/map/wonders/forbidden_city.glb |
| `battle-city/wonders/grand_bazaar-ruin` | 3d | 7 | tracked_artifact_acceptance_verification | src/assets/map/wonders/grand_bazaar.glb |
| `battle-city/wonders/great_cathedral-ruin` | 3d | 7 | tracked_artifact_acceptance_verification | src/assets/map/wonders/great_cathedral.glb |
| `battle-city/wonders/great_library-ruin` | 3d | 7 | tracked_artifact_acceptance_verification | src/assets/map/wonders/great_library.glb |
| `battle-city/wonders/great_pyramids-ruin` | 3d | 7 | tracked_artifact_acceptance_verification | src/assets/map/wonders/great_pyramids.glb |
| `battle-city/wonders/great_wall-ruin` | 3d | 7 | tracked_artifact_acceptance_verification | src/assets/map/wonders/great_wall.glb |
| `battle-city/wonders/hanging_gardens-ruin` | 3d | 7 | tracked_artifact_acceptance_verification | src/assets/map/wonders/hanging_gardens.glb |
| `battle-city/wonders/international_exchange-ruin` | 3d | 7 | tracked_artifact_acceptance_verification | src/assets/map/wonders/international_exchange.glb |
| `battle-city/wonders/lighthouse-ruin` | 3d | 7 | tracked_artifact_acceptance_verification | src/assets/map/wonders/lighthouse.glb |
| `battle-city/wonders/masada-ruin` | 3d | 7 | tracked_artifact_acceptance_verification | src/assets/map/wonders/masada.glb |
| `battle-city/wonders/palace_of_versailles-ruin` | 3d | 7 | tracked_artifact_acceptance_verification | src/assets/map/wonders/palace_of_versailles.glb |
| `battle-city/wonders/royal_observatory-ruin` | 3d | 7 | tracked_artifact_acceptance_verification | src/assets/map/wonders/royal_observatory.glb |
| `battle-city/wonders/solomons_temple-ruin` | 3d | 7 | tracked_artifact_acceptance_verification | src/assets/map/wonders/solomons_temple.glb |
| `battle-city/wonders/space_program-ruin` | 3d | 7 | tracked_artifact_acceptance_verification | src/assets/map/wonders/space_program.glb |
| `fx/arrow-volley-streak` | 2d | 7 | definitive_missing_declared_target | src/assets/fx/arrow-volley-streak/ |
| `fx/building-burning` | 2d | 7 | definitive_missing_declared_target | src/assets/fx/building-burning/ |
| `fx/cannon-smoke` | 2d | 7 | definitive_missing_declared_target | src/assets/fx/cannon-smoke/ |
| `fx/debris-stone` | 2d | 7 | definitive_missing_declared_target | src/assets/fx/debris-stone/ |
| `fx/debris-wood` | 2d | 7 | definitive_missing_declared_target | src/assets/fx/debris-wood/ |
| `fx/dust-cavalry` | 2d | 7 | definitive_missing_declared_target | src/assets/fx/dust-cavalry/ |
| `fx/explosion-large` | 2d | 7 | definitive_missing_declared_target | src/assets/fx/explosion-large/ |
| `fx/explosion-small` | 2d | 7 | definitive_missing_declared_target | src/assets/fx/explosion-small/ |
| `fx/ford-splash` | 2d | 7 | definitive_missing_declared_target | src/assets/fx/ford-splash/ |
| `fx/healing-glow` | 2d | 7 | definitive_missing_declared_target | src/assets/fx/healing-glow/ |
| `fx/map/ai-battle-smoke` | 2d | 7 | definitive_missing_declared_target | src/assets/fx/ai-battle-smoke/ |
| `fx/map/burning-town` | 2d | 7 | definitive_missing_declared_target | src/assets/fx/burning-town/ |
| `fx/muzzle-flash` | 2d | 7 | definitive_missing_declared_target | src/assets/fx/muzzle-flash/ |
| `fx/rally-flash` | 2d | 7 | definitive_missing_declared_target | src/assets/fx/rally-flash/ |
| `fx/water-splash` | 2d | 7 | definitive_missing_declared_target | src/assets/fx/water-splash/ |
| `nature/vegetation-cold` | 3d | 7 | definitive_missing_declared_target | src/assets/battle/nature/vegetation-cold.glb |
| `nature/vegetation-conifer` | 3d | 7 | definitive_missing_declared_target | src/assets/battle/nature/vegetation-conifer.glb |
| `nature/vegetation-steppe` | 3d | 7 | definitive_missing_declared_target | src/assets/battle/nature/vegetation-steppe.glb |
| `nature/vegetation-tropical` | 3d | 7 | definitive_missing_declared_target | src/assets/battle/nature/vegetation-tropical.glb |
| `rts-skins/bronze/americas/barracks` | 3d | 7 | required_scope_binding_verification | binding unresolved; barracks, barracks-damaged |
| `rts-skins/bronze/americas/tower` | 3d | 7 | required_scope_binding_verification | binding unresolved; tower, tower-damaged |
| `rts-skins/bronze/americas/town-hall` | 3d | 7 | required_scope_binding_verification | binding unresolved; town-hall, town-hall-damaged |
| `rts-skins/bronze/americas/trade-post` | 3d | 7 | required_scope_binding_verification | binding unresolved; trade-post, trade-post-damaged |
| `rts-skins/bronze/eastafrica/barracks` | 3d | 7 | required_scope_binding_verification | binding unresolved; barracks, barracks-damaged |
| `rts-skins/bronze/eastafrica/tower` | 3d | 7 | required_scope_binding_verification | binding unresolved; tower, tower-damaged |
| `rts-skins/bronze/eastafrica/town-hall` | 3d | 7 | required_scope_binding_verification | binding unresolved; town-hall, town-hall-damaged |
| `rts-skins/bronze/eastafrica/trade-post` | 3d | 7 | required_scope_binding_verification | binding unresolved; trade-post, trade-post-damaged |
| `rts-skins/bronze/europe/barracks` | 3d | 7 | required_scope_binding_verification | binding unresolved; barracks, barracks-damaged |
| `rts-skins/bronze/europe/tower` | 3d | 7 | required_scope_binding_verification | binding unresolved; tower, tower-damaged |
| `rts-skins/bronze/europe/town-hall` | 3d | 7 | required_scope_binding_verification | binding unresolved; town-hall, town-hall-damaged |
| `rts-skins/bronze/europe/trade-post` | 3d | 7 | required_scope_binding_verification | binding unresolved; trade-post, trade-post-damaged |
| `rts-skins/bronze/indic/barracks` | 3d | 7 | required_scope_binding_verification | binding unresolved; barracks, barracks-damaged |
| `rts-skins/bronze/indic/tower` | 3d | 7 | required_scope_binding_verification | binding unresolved; tower, tower-damaged |
| `rts-skins/bronze/indic/town-hall` | 3d | 7 | required_scope_binding_verification | binding unresolved; town-hall, town-hall-damaged |
| `rts-skins/bronze/indic/trade-post` | 3d | 7 | required_scope_binding_verification | binding unresolved; trade-post, trade-post-damaged |
| `rts-skins/bronze/israelite/barracks` | 3d | 7 | required_scope_binding_verification | binding unresolved; barracks, barracks-damaged |
| `rts-skins/bronze/israelite/tower` | 3d | 7 | required_scope_binding_verification | binding unresolved; tower, tower-damaged |
| `rts-skins/bronze/israelite/town-hall` | 3d | 7 | required_scope_binding_verification | binding unresolved; town-hall, town-hall-damaged |
| `rts-skins/bronze/israelite/trade-post` | 3d | 7 | required_scope_binding_verification | binding unresolved; trade-post, trade-post-damaged |
| `rts-skins/bronze/japan/barracks` | 3d | 7 | required_scope_binding_verification | binding unresolved; barracks, barracks-damaged |
| `rts-skins/bronze/japan/tower` | 3d | 7 | required_scope_binding_verification | binding unresolved; tower, tower-damaged |
| `rts-skins/bronze/japan/town-hall` | 3d | 7 | required_scope_binding_verification | binding unresolved; town-hall, town-hall-damaged |
| `rts-skins/bronze/japan/trade-post` | 3d | 7 | required_scope_binding_verification | binding unresolved; trade-post, trade-post-damaged |
| `rts-skins/bronze/korea/barracks` | 3d | 7 | required_scope_binding_verification | binding unresolved; barracks, barracks-damaged |
| `rts-skins/bronze/korea/tower` | 3d | 7 | required_scope_binding_verification | binding unresolved; tower, tower-damaged |
| `rts-skins/bronze/korea/town-hall` | 3d | 7 | required_scope_binding_verification | binding unresolved; town-hall, town-hall-damaged |
| `rts-skins/bronze/korea/trade-post` | 3d | 7 | required_scope_binding_verification | binding unresolved; trade-post, trade-post-damaged |
| `rts-skins/bronze/levant/barracks` | 3d | 7 | required_scope_binding_verification | binding unresolved; barracks, barracks-damaged |
| `rts-skins/bronze/levant/tower` | 3d | 7 | required_scope_binding_verification | binding unresolved; tower, tower-damaged |
| `rts-skins/bronze/levant/town-hall` | 3d | 7 | required_scope_binding_verification | binding unresolved; town-hall, town-hall-damaged |
| `rts-skins/bronze/levant/trade-post` | 3d | 7 | required_scope_binding_verification | binding unresolved; trade-post, trade-post-damaged |
| `rts-skins/bronze/maghreb/barracks` | 3d | 7 | required_scope_binding_verification | binding unresolved; barracks, barracks-damaged |
| `rts-skins/bronze/maghreb/tower` | 3d | 7 | required_scope_binding_verification | binding unresolved; tower, tower-damaged |
| `rts-skins/bronze/maghreb/town-hall` | 3d | 7 | required_scope_binding_verification | binding unresolved; town-hall, town-hall-damaged |
| `rts-skins/bronze/maghreb/trade-post` | 3d | 7 | required_scope_binding_verification | binding unresolved; trade-post, trade-post-damaged |
| `rts-skins/bronze/monsoon/barracks` | 3d | 7 | required_scope_binding_verification | binding unresolved; barracks, barracks-damaged |
| `rts-skins/bronze/monsoon/tower` | 3d | 7 | required_scope_binding_verification | binding unresolved; tower, tower-damaged |
| `rts-skins/bronze/monsoon/town-hall` | 3d | 7 | required_scope_binding_verification | binding unresolved; town-hall, town-hall-damaged |
| `rts-skins/bronze/monsoon/trade-post` | 3d | 7 | required_scope_binding_verification | binding unresolved; trade-post, trade-post-damaged |
| `rts-skins/bronze/nile/barracks` | 3d | 7 | required_scope_binding_verification | binding unresolved; barracks, barracks-damaged |
| `rts-skins/bronze/nile/tower` | 3d | 7 | required_scope_binding_verification | binding unresolved; tower, tower-damaged |
| `rts-skins/bronze/nile/town-hall` | 3d | 7 | required_scope_binding_verification | binding unresolved; town-hall, town-hall-damaged |
| `rts-skins/bronze/nile/trade-post` | 3d | 7 | required_scope_binding_verification | binding unresolved; trade-post, trade-post-damaged |
| `rts-skins/bronze/pacific/barracks` | 3d | 7 | required_scope_binding_verification | binding unresolved; barracks, barracks-damaged |
| `rts-skins/bronze/pacific/tower` | 3d | 7 | required_scope_binding_verification | binding unresolved; tower, tower-damaged |
| `rts-skins/bronze/pacific/town-hall` | 3d | 7 | required_scope_binding_verification | binding unresolved; town-hall, town-hall-damaged |
| `rts-skins/bronze/pacific/trade-post` | 3d | 7 | required_scope_binding_verification | binding unresolved; trade-post, trade-post-damaged |
| `rts-skins/bronze/sinic/barracks` | 3d | 7 | required_scope_binding_verification | binding unresolved; barracks, barracks-damaged |
| `rts-skins/bronze/sinic/tower` | 3d | 7 | required_scope_binding_verification | binding unresolved; tower, tower-damaged |
| `rts-skins/bronze/sinic/town-hall` | 3d | 7 | required_scope_binding_verification | binding unresolved; town-hall, town-hall-damaged |
| `rts-skins/bronze/sinic/trade-post` | 3d | 7 | required_scope_binding_verification | binding unresolved; trade-post, trade-post-damaged |
| `rts-skins/bronze/steppe/barracks` | 3d | 7 | required_scope_binding_verification | binding unresolved; barracks, barracks-damaged |
| `rts-skins/bronze/steppe/tower` | 3d | 7 | required_scope_binding_verification | binding unresolved; tower, tower-damaged |
| `rts-skins/bronze/steppe/town-hall` | 3d | 7 | required_scope_binding_verification | binding unresolved; town-hall, town-hall-damaged |
| `rts-skins/bronze/steppe/trade-post` | 3d | 7 | required_scope_binding_verification | binding unresolved; trade-post, trade-post-damaged |
| `rts-skins/bronze/westafrica/barracks` | 3d | 7 | required_scope_binding_verification | binding unresolved; barracks, barracks-damaged |
| `rts-skins/bronze/westafrica/tower` | 3d | 7 | required_scope_binding_verification | binding unresolved; tower, tower-damaged |
| `rts-skins/bronze/westafrica/town-hall` | 3d | 7 | required_scope_binding_verification | binding unresolved; town-hall, town-hall-damaged |
| `rts-skins/bronze/westafrica/trade-post` | 3d | 7 | required_scope_binding_verification | binding unresolved; trade-post, trade-post-damaged |
| `rts-skins/classical/americas/barracks` | 3d | 7 | required_scope_binding_verification | binding unresolved; barracks, barracks-damaged |
| `rts-skins/classical/americas/tower` | 3d | 7 | required_scope_binding_verification | binding unresolved; tower, tower-damaged |
| `rts-skins/classical/americas/town-hall` | 3d | 7 | required_scope_binding_verification | binding unresolved; town-hall, town-hall-damaged |
| `rts-skins/classical/americas/trade-post` | 3d | 7 | required_scope_binding_verification | binding unresolved; trade-post, trade-post-damaged |
| `rts-skins/classical/eastafrica/barracks` | 3d | 7 | required_scope_binding_verification | binding unresolved; barracks, barracks-damaged |
| `rts-skins/classical/eastafrica/tower` | 3d | 7 | required_scope_binding_verification | binding unresolved; tower, tower-damaged |
| `rts-skins/classical/eastafrica/town-hall` | 3d | 7 | required_scope_binding_verification | binding unresolved; town-hall, town-hall-damaged |
| `rts-skins/classical/eastafrica/trade-post` | 3d | 7 | required_scope_binding_verification | binding unresolved; trade-post, trade-post-damaged |
| `rts-skins/classical/europe/barracks` | 3d | 7 | required_scope_binding_verification | binding unresolved; barracks, barracks-damaged |
| `rts-skins/classical/europe/tower` | 3d | 7 | required_scope_binding_verification | binding unresolved; tower, tower-damaged |
| `rts-skins/classical/europe/town-hall` | 3d | 7 | required_scope_binding_verification | binding unresolved; town-hall, town-hall-damaged |
| `rts-skins/classical/europe/trade-post` | 3d | 7 | required_scope_binding_verification | binding unresolved; trade-post, trade-post-damaged |
| `rts-skins/classical/indic/barracks` | 3d | 7 | required_scope_binding_verification | binding unresolved; barracks, barracks-damaged |
| `rts-skins/classical/indic/tower` | 3d | 7 | required_scope_binding_verification | binding unresolved; tower, tower-damaged |
| `rts-skins/classical/indic/town-hall` | 3d | 7 | required_scope_binding_verification | binding unresolved; town-hall, town-hall-damaged |
| `rts-skins/classical/indic/trade-post` | 3d | 7 | required_scope_binding_verification | binding unresolved; trade-post, trade-post-damaged |
| `rts-skins/classical/israelite/barracks` | 3d | 7 | required_scope_binding_verification | binding unresolved; barracks, barracks-damaged |
| `rts-skins/classical/israelite/tower` | 3d | 7 | required_scope_binding_verification | binding unresolved; tower, tower-damaged |
| `rts-skins/classical/israelite/town-hall` | 3d | 7 | required_scope_binding_verification | binding unresolved; town-hall, town-hall-damaged |
| `rts-skins/classical/israelite/trade-post` | 3d | 7 | required_scope_binding_verification | binding unresolved; trade-post, trade-post-damaged |
| `rts-skins/classical/japan/barracks` | 3d | 7 | required_scope_binding_verification | binding unresolved; barracks, barracks-damaged |
| `rts-skins/classical/japan/tower` | 3d | 7 | required_scope_binding_verification | binding unresolved; tower, tower-damaged |
| `rts-skins/classical/japan/town-hall` | 3d | 7 | required_scope_binding_verification | binding unresolved; town-hall, town-hall-damaged |
| `rts-skins/classical/japan/trade-post` | 3d | 7 | required_scope_binding_verification | binding unresolved; trade-post, trade-post-damaged |
| `rts-skins/classical/korea/barracks` | 3d | 7 | required_scope_binding_verification | binding unresolved; barracks, barracks-damaged |
| `rts-skins/classical/korea/tower` | 3d | 7 | required_scope_binding_verification | binding unresolved; tower, tower-damaged |
| `rts-skins/classical/korea/town-hall` | 3d | 7 | required_scope_binding_verification | binding unresolved; town-hall, town-hall-damaged |
| `rts-skins/classical/korea/trade-post` | 3d | 7 | required_scope_binding_verification | binding unresolved; trade-post, trade-post-damaged |
| `rts-skins/classical/levant/barracks` | 3d | 7 | required_scope_binding_verification | binding unresolved; barracks, barracks-damaged |
| `rts-skins/classical/levant/tower` | 3d | 7 | required_scope_binding_verification | binding unresolved; tower, tower-damaged |
| `rts-skins/classical/levant/town-hall` | 3d | 7 | required_scope_binding_verification | binding unresolved; town-hall, town-hall-damaged |
| `rts-skins/classical/levant/trade-post` | 3d | 7 | required_scope_binding_verification | binding unresolved; trade-post, trade-post-damaged |
| `rts-skins/classical/maghreb/barracks` | 3d | 7 | required_scope_binding_verification | binding unresolved; barracks, barracks-damaged |
| `rts-skins/classical/maghreb/tower` | 3d | 7 | required_scope_binding_verification | binding unresolved; tower, tower-damaged |
| `rts-skins/classical/maghreb/town-hall` | 3d | 7 | required_scope_binding_verification | binding unresolved; town-hall, town-hall-damaged |
| `rts-skins/classical/maghreb/trade-post` | 3d | 7 | required_scope_binding_verification | binding unresolved; trade-post, trade-post-damaged |
| `rts-skins/classical/monsoon/barracks` | 3d | 7 | required_scope_binding_verification | binding unresolved; barracks, barracks-damaged |
| `rts-skins/classical/monsoon/tower` | 3d | 7 | required_scope_binding_verification | binding unresolved; tower, tower-damaged |
| `rts-skins/classical/monsoon/town-hall` | 3d | 7 | required_scope_binding_verification | binding unresolved; town-hall, town-hall-damaged |
| `rts-skins/classical/monsoon/trade-post` | 3d | 7 | required_scope_binding_verification | binding unresolved; trade-post, trade-post-damaged |
| `rts-skins/classical/nile/barracks` | 3d | 7 | required_scope_binding_verification | binding unresolved; barracks, barracks-damaged |
| `rts-skins/classical/nile/tower` | 3d | 7 | required_scope_binding_verification | binding unresolved; tower, tower-damaged |
| `rts-skins/classical/nile/town-hall` | 3d | 7 | required_scope_binding_verification | binding unresolved; town-hall, town-hall-damaged |
| `rts-skins/classical/nile/trade-post` | 3d | 7 | required_scope_binding_verification | binding unresolved; trade-post, trade-post-damaged |
| `rts-skins/classical/pacific/barracks` | 3d | 7 | required_scope_binding_verification | binding unresolved; barracks, barracks-damaged |
| `rts-skins/classical/pacific/tower` | 3d | 7 | required_scope_binding_verification | binding unresolved; tower, tower-damaged |
| `rts-skins/classical/pacific/town-hall` | 3d | 7 | required_scope_binding_verification | binding unresolved; town-hall, town-hall-damaged |
| `rts-skins/classical/pacific/trade-post` | 3d | 7 | required_scope_binding_verification | binding unresolved; trade-post, trade-post-damaged |
| `rts-skins/classical/sinic/barracks` | 3d | 7 | required_scope_binding_verification | binding unresolved; barracks, barracks-damaged |
| `rts-skins/classical/sinic/tower` | 3d | 7 | required_scope_binding_verification | binding unresolved; tower, tower-damaged |
| `rts-skins/classical/sinic/town-hall` | 3d | 7 | required_scope_binding_verification | binding unresolved; town-hall, town-hall-damaged |
| `rts-skins/classical/sinic/trade-post` | 3d | 7 | required_scope_binding_verification | binding unresolved; trade-post, trade-post-damaged |
| `rts-skins/classical/steppe/barracks` | 3d | 7 | required_scope_binding_verification | binding unresolved; barracks, barracks-damaged |
| `rts-skins/classical/steppe/tower` | 3d | 7 | required_scope_binding_verification | binding unresolved; tower, tower-damaged |
| `rts-skins/classical/steppe/town-hall` | 3d | 7 | required_scope_binding_verification | binding unresolved; town-hall, town-hall-damaged |
| `rts-skins/classical/steppe/trade-post` | 3d | 7 | required_scope_binding_verification | binding unresolved; trade-post, trade-post-damaged |
| `rts-skins/classical/westafrica/barracks` | 3d | 7 | required_scope_binding_verification | binding unresolved; barracks, barracks-damaged |
| `rts-skins/classical/westafrica/tower` | 3d | 7 | required_scope_binding_verification | binding unresolved; tower, tower-damaged |
| `rts-skins/classical/westafrica/town-hall` | 3d | 7 | required_scope_binding_verification | binding unresolved; town-hall, town-hall-damaged |
| `rts-skins/classical/westafrica/trade-post` | 3d | 7 | required_scope_binding_verification | binding unresolved; trade-post, trade-post-damaged |
| `rts-skins/gunpowder/americas/barracks` | 3d | 7 | required_scope_binding_verification | binding unresolved; barracks, barracks-damaged |
| `rts-skins/gunpowder/americas/tower` | 3d | 7 | required_scope_binding_verification | binding unresolved; tower, tower-damaged |
| `rts-skins/gunpowder/americas/town-hall` | 3d | 7 | required_scope_binding_verification | binding unresolved; town-hall, town-hall-damaged |
| `rts-skins/gunpowder/americas/trade-post` | 3d | 7 | required_scope_binding_verification | binding unresolved; trade-post, trade-post-damaged |
| `rts-skins/gunpowder/eastafrica/barracks` | 3d | 7 | required_scope_binding_verification | binding unresolved; barracks, barracks-damaged |
| `rts-skins/gunpowder/eastafrica/tower` | 3d | 7 | required_scope_binding_verification | binding unresolved; tower, tower-damaged |
| `rts-skins/gunpowder/eastafrica/town-hall` | 3d | 7 | required_scope_binding_verification | binding unresolved; town-hall, town-hall-damaged |
| `rts-skins/gunpowder/eastafrica/trade-post` | 3d | 7 | required_scope_binding_verification | binding unresolved; trade-post, trade-post-damaged |
| `rts-skins/gunpowder/europe/barracks` | 3d | 7 | required_scope_binding_verification | binding unresolved; barracks, barracks-damaged |
| `rts-skins/gunpowder/europe/tower` | 3d | 7 | required_scope_binding_verification | binding unresolved; tower, tower-damaged |
| `rts-skins/gunpowder/europe/town-hall` | 3d | 7 | required_scope_binding_verification | binding unresolved; town-hall, town-hall-damaged |
| `rts-skins/gunpowder/europe/trade-post` | 3d | 7 | required_scope_binding_verification | binding unresolved; trade-post, trade-post-damaged |
| `rts-skins/gunpowder/indic/barracks` | 3d | 7 | required_scope_binding_verification | binding unresolved; barracks, barracks-damaged |
| `rts-skins/gunpowder/indic/tower` | 3d | 7 | required_scope_binding_verification | binding unresolved; tower, tower-damaged |
| `rts-skins/gunpowder/indic/town-hall` | 3d | 7 | required_scope_binding_verification | binding unresolved; town-hall, town-hall-damaged |
| `rts-skins/gunpowder/indic/trade-post` | 3d | 7 | required_scope_binding_verification | binding unresolved; trade-post, trade-post-damaged |
| `rts-skins/gunpowder/israelite/barracks` | 3d | 7 | required_scope_binding_verification | binding unresolved; barracks, barracks-damaged |
| `rts-skins/gunpowder/israelite/tower` | 3d | 7 | required_scope_binding_verification | binding unresolved; tower, tower-damaged |
| `rts-skins/gunpowder/israelite/town-hall` | 3d | 7 | required_scope_binding_verification | binding unresolved; town-hall, town-hall-damaged |
| `rts-skins/gunpowder/israelite/trade-post` | 3d | 7 | required_scope_binding_verification | binding unresolved; trade-post, trade-post-damaged |
| `rts-skins/gunpowder/japan/barracks` | 3d | 7 | required_scope_binding_verification | binding unresolved; barracks, barracks-damaged |
| `rts-skins/gunpowder/japan/tower` | 3d | 7 | required_scope_binding_verification | binding unresolved; tower, tower-damaged |
| `rts-skins/gunpowder/japan/town-hall` | 3d | 7 | required_scope_binding_verification | binding unresolved; town-hall, town-hall-damaged |
| `rts-skins/gunpowder/japan/trade-post` | 3d | 7 | required_scope_binding_verification | binding unresolved; trade-post, trade-post-damaged |
| `rts-skins/gunpowder/korea/barracks` | 3d | 7 | required_scope_binding_verification | binding unresolved; barracks, barracks-damaged |
| `rts-skins/gunpowder/korea/tower` | 3d | 7 | required_scope_binding_verification | binding unresolved; tower, tower-damaged |
| `rts-skins/gunpowder/korea/town-hall` | 3d | 7 | required_scope_binding_verification | binding unresolved; town-hall, town-hall-damaged |
| `rts-skins/gunpowder/korea/trade-post` | 3d | 7 | required_scope_binding_verification | binding unresolved; trade-post, trade-post-damaged |
| `rts-skins/gunpowder/levant/barracks` | 3d | 7 | required_scope_binding_verification | binding unresolved; barracks, barracks-damaged |
| `rts-skins/gunpowder/levant/tower` | 3d | 7 | required_scope_binding_verification | binding unresolved; tower, tower-damaged |
| `rts-skins/gunpowder/levant/town-hall` | 3d | 7 | required_scope_binding_verification | binding unresolved; town-hall, town-hall-damaged |
| `rts-skins/gunpowder/levant/trade-post` | 3d | 7 | required_scope_binding_verification | binding unresolved; trade-post, trade-post-damaged |
| `rts-skins/gunpowder/maghreb/barracks` | 3d | 7 | required_scope_binding_verification | binding unresolved; barracks, barracks-damaged |
| `rts-skins/gunpowder/maghreb/tower` | 3d | 7 | required_scope_binding_verification | binding unresolved; tower, tower-damaged |
| `rts-skins/gunpowder/maghreb/town-hall` | 3d | 7 | required_scope_binding_verification | binding unresolved; town-hall, town-hall-damaged |
| `rts-skins/gunpowder/maghreb/trade-post` | 3d | 7 | required_scope_binding_verification | binding unresolved; trade-post, trade-post-damaged |
| `rts-skins/gunpowder/monsoon/barracks` | 3d | 7 | required_scope_binding_verification | binding unresolved; barracks, barracks-damaged |
| `rts-skins/gunpowder/monsoon/tower` | 3d | 7 | required_scope_binding_verification | binding unresolved; tower, tower-damaged |
| `rts-skins/gunpowder/monsoon/town-hall` | 3d | 7 | required_scope_binding_verification | binding unresolved; town-hall, town-hall-damaged |
| `rts-skins/gunpowder/monsoon/trade-post` | 3d | 7 | required_scope_binding_verification | binding unresolved; trade-post, trade-post-damaged |
| `rts-skins/gunpowder/nile/barracks` | 3d | 7 | required_scope_binding_verification | binding unresolved; barracks, barracks-damaged |
| `rts-skins/gunpowder/nile/tower` | 3d | 7 | required_scope_binding_verification | binding unresolved; tower, tower-damaged |
| `rts-skins/gunpowder/nile/town-hall` | 3d | 7 | required_scope_binding_verification | binding unresolved; town-hall, town-hall-damaged |
| `rts-skins/gunpowder/nile/trade-post` | 3d | 7 | required_scope_binding_verification | binding unresolved; trade-post, trade-post-damaged |
| `rts-skins/gunpowder/pacific/barracks` | 3d | 7 | required_scope_binding_verification | binding unresolved; barracks, barracks-damaged |
| `rts-skins/gunpowder/pacific/tower` | 3d | 7 | required_scope_binding_verification | binding unresolved; tower, tower-damaged |
| `rts-skins/gunpowder/pacific/town-hall` | 3d | 7 | required_scope_binding_verification | binding unresolved; town-hall, town-hall-damaged |
| `rts-skins/gunpowder/pacific/trade-post` | 3d | 7 | required_scope_binding_verification | binding unresolved; trade-post, trade-post-damaged |
| `rts-skins/gunpowder/sinic/barracks` | 3d | 7 | required_scope_binding_verification | binding unresolved; barracks, barracks-damaged |
| `rts-skins/gunpowder/sinic/tower` | 3d | 7 | required_scope_binding_verification | binding unresolved; tower, tower-damaged |
| `rts-skins/gunpowder/sinic/town-hall` | 3d | 7 | required_scope_binding_verification | binding unresolved; town-hall, town-hall-damaged |
| `rts-skins/gunpowder/sinic/trade-post` | 3d | 7 | required_scope_binding_verification | binding unresolved; trade-post, trade-post-damaged |
| `rts-skins/gunpowder/steppe/barracks` | 3d | 7 | required_scope_binding_verification | binding unresolved; barracks, barracks-damaged |
| `rts-skins/gunpowder/steppe/tower` | 3d | 7 | required_scope_binding_verification | binding unresolved; tower, tower-damaged |
| `rts-skins/gunpowder/steppe/town-hall` | 3d | 7 | required_scope_binding_verification | binding unresolved; town-hall, town-hall-damaged |
| `rts-skins/gunpowder/steppe/trade-post` | 3d | 7 | required_scope_binding_verification | binding unresolved; trade-post, trade-post-damaged |
| `rts-skins/gunpowder/westafrica/barracks` | 3d | 7 | required_scope_binding_verification | binding unresolved; barracks, barracks-damaged |
| `rts-skins/gunpowder/westafrica/tower` | 3d | 7 | required_scope_binding_verification | binding unresolved; tower, tower-damaged |
| `rts-skins/gunpowder/westafrica/town-hall` | 3d | 7 | required_scope_binding_verification | binding unresolved; town-hall, town-hall-damaged |
| `rts-skins/gunpowder/westafrica/trade-post` | 3d | 7 | required_scope_binding_verification | binding unresolved; trade-post, trade-post-damaged |
| `rts-skins/kingdoms/americas/barracks` | 3d | 7 | required_scope_binding_verification | binding unresolved; barracks, barracks-damaged |
| `rts-skins/kingdoms/americas/tower` | 3d | 7 | required_scope_binding_verification | binding unresolved; tower, tower-damaged |
| `rts-skins/kingdoms/americas/town-hall` | 3d | 7 | required_scope_binding_verification | binding unresolved; town-hall, town-hall-damaged |
| `rts-skins/kingdoms/americas/trade-post` | 3d | 7 | required_scope_binding_verification | binding unresolved; trade-post, trade-post-damaged |
| `rts-skins/kingdoms/eastafrica/barracks` | 3d | 7 | required_scope_binding_verification | binding unresolved; barracks, barracks-damaged |
| `rts-skins/kingdoms/eastafrica/tower` | 3d | 7 | required_scope_binding_verification | binding unresolved; tower, tower-damaged |
| `rts-skins/kingdoms/eastafrica/town-hall` | 3d | 7 | required_scope_binding_verification | binding unresolved; town-hall, town-hall-damaged |
| `rts-skins/kingdoms/eastafrica/trade-post` | 3d | 7 | required_scope_binding_verification | binding unresolved; trade-post, trade-post-damaged |
| `rts-skins/kingdoms/europe/barracks` | 3d | 7 | required_scope_binding_verification | binding unresolved; barracks, barracks-damaged |
| `rts-skins/kingdoms/europe/tower` | 3d | 7 | required_scope_binding_verification | binding unresolved; tower, tower-damaged |
| `rts-skins/kingdoms/europe/town-hall` | 3d | 7 | required_scope_binding_verification | binding unresolved; town-hall, town-hall-damaged |
| `rts-skins/kingdoms/europe/trade-post` | 3d | 7 | required_scope_binding_verification | binding unresolved; trade-post, trade-post-damaged |
| `rts-skins/kingdoms/indic/barracks` | 3d | 7 | required_scope_binding_verification | binding unresolved; barracks, barracks-damaged |
| `rts-skins/kingdoms/indic/tower` | 3d | 7 | required_scope_binding_verification | binding unresolved; tower, tower-damaged |
| `rts-skins/kingdoms/indic/town-hall` | 3d | 7 | required_scope_binding_verification | binding unresolved; town-hall, town-hall-damaged |
| `rts-skins/kingdoms/indic/trade-post` | 3d | 7 | required_scope_binding_verification | binding unresolved; trade-post, trade-post-damaged |
| `rts-skins/kingdoms/israelite/barracks` | 3d | 7 | required_scope_binding_verification | binding unresolved; barracks, barracks-damaged |
| `rts-skins/kingdoms/israelite/tower` | 3d | 7 | required_scope_binding_verification | binding unresolved; tower, tower-damaged |
| `rts-skins/kingdoms/israelite/town-hall` | 3d | 7 | required_scope_binding_verification | binding unresolved; town-hall, town-hall-damaged |
| `rts-skins/kingdoms/israelite/trade-post` | 3d | 7 | required_scope_binding_verification | binding unresolved; trade-post, trade-post-damaged |
| `rts-skins/kingdoms/japan/barracks` | 3d | 7 | required_scope_binding_verification | binding unresolved; barracks, barracks-damaged |
| `rts-skins/kingdoms/japan/tower` | 3d | 7 | required_scope_binding_verification | binding unresolved; tower, tower-damaged |
| `rts-skins/kingdoms/japan/town-hall` | 3d | 7 | required_scope_binding_verification | binding unresolved; town-hall, town-hall-damaged |
| `rts-skins/kingdoms/japan/trade-post` | 3d | 7 | required_scope_binding_verification | binding unresolved; trade-post, trade-post-damaged |
| `rts-skins/kingdoms/korea/barracks` | 3d | 7 | required_scope_binding_verification | binding unresolved; barracks, barracks-damaged |
| `rts-skins/kingdoms/korea/tower` | 3d | 7 | required_scope_binding_verification | binding unresolved; tower, tower-damaged |
| `rts-skins/kingdoms/korea/town-hall` | 3d | 7 | required_scope_binding_verification | binding unresolved; town-hall, town-hall-damaged |
| `rts-skins/kingdoms/korea/trade-post` | 3d | 7 | required_scope_binding_verification | binding unresolved; trade-post, trade-post-damaged |
| `rts-skins/kingdoms/levant/barracks` | 3d | 7 | required_scope_binding_verification | binding unresolved; barracks, barracks-damaged |
| `rts-skins/kingdoms/levant/tower` | 3d | 7 | required_scope_binding_verification | binding unresolved; tower, tower-damaged |
| `rts-skins/kingdoms/levant/town-hall` | 3d | 7 | required_scope_binding_verification | binding unresolved; town-hall, town-hall-damaged |
| `rts-skins/kingdoms/levant/trade-post` | 3d | 7 | required_scope_binding_verification | binding unresolved; trade-post, trade-post-damaged |
| `rts-skins/kingdoms/maghreb/barracks` | 3d | 7 | required_scope_binding_verification | binding unresolved; barracks, barracks-damaged |
| `rts-skins/kingdoms/maghreb/tower` | 3d | 7 | required_scope_binding_verification | binding unresolved; tower, tower-damaged |
| `rts-skins/kingdoms/maghreb/town-hall` | 3d | 7 | required_scope_binding_verification | binding unresolved; town-hall, town-hall-damaged |
| `rts-skins/kingdoms/maghreb/trade-post` | 3d | 7 | required_scope_binding_verification | binding unresolved; trade-post, trade-post-damaged |
| `rts-skins/kingdoms/monsoon/barracks` | 3d | 7 | required_scope_binding_verification | binding unresolved; barracks, barracks-damaged |
| `rts-skins/kingdoms/monsoon/tower` | 3d | 7 | required_scope_binding_verification | binding unresolved; tower, tower-damaged |
| `rts-skins/kingdoms/monsoon/town-hall` | 3d | 7 | required_scope_binding_verification | binding unresolved; town-hall, town-hall-damaged |
| `rts-skins/kingdoms/monsoon/trade-post` | 3d | 7 | required_scope_binding_verification | binding unresolved; trade-post, trade-post-damaged |
| `rts-skins/kingdoms/nile/barracks` | 3d | 7 | required_scope_binding_verification | binding unresolved; barracks, barracks-damaged |
| `rts-skins/kingdoms/nile/tower` | 3d | 7 | required_scope_binding_verification | binding unresolved; tower, tower-damaged |
| `rts-skins/kingdoms/nile/town-hall` | 3d | 7 | required_scope_binding_verification | binding unresolved; town-hall, town-hall-damaged |
| `rts-skins/kingdoms/nile/trade-post` | 3d | 7 | required_scope_binding_verification | binding unresolved; trade-post, trade-post-damaged |
| `rts-skins/kingdoms/pacific/barracks` | 3d | 7 | required_scope_binding_verification | binding unresolved; barracks, barracks-damaged |
| `rts-skins/kingdoms/pacific/tower` | 3d | 7 | required_scope_binding_verification | binding unresolved; tower, tower-damaged |
| `rts-skins/kingdoms/pacific/town-hall` | 3d | 7 | required_scope_binding_verification | binding unresolved; town-hall, town-hall-damaged |
| `rts-skins/kingdoms/pacific/trade-post` | 3d | 7 | required_scope_binding_verification | binding unresolved; trade-post, trade-post-damaged |
| `rts-skins/kingdoms/sinic/barracks` | 3d | 7 | required_scope_binding_verification | binding unresolved; barracks, barracks-damaged |
| `rts-skins/kingdoms/sinic/tower` | 3d | 7 | required_scope_binding_verification | binding unresolved; tower, tower-damaged |
| `rts-skins/kingdoms/sinic/town-hall` | 3d | 7 | required_scope_binding_verification | binding unresolved; town-hall, town-hall-damaged |
| `rts-skins/kingdoms/sinic/trade-post` | 3d | 7 | required_scope_binding_verification | binding unresolved; trade-post, trade-post-damaged |
| `rts-skins/kingdoms/steppe/barracks` | 3d | 7 | required_scope_binding_verification | binding unresolved; barracks, barracks-damaged |
| `rts-skins/kingdoms/steppe/tower` | 3d | 7 | required_scope_binding_verification | binding unresolved; tower, tower-damaged |
| `rts-skins/kingdoms/steppe/town-hall` | 3d | 7 | required_scope_binding_verification | binding unresolved; town-hall, town-hall-damaged |
| `rts-skins/kingdoms/steppe/trade-post` | 3d | 7 | required_scope_binding_verification | binding unresolved; trade-post, trade-post-damaged |
| `rts-skins/kingdoms/westafrica/barracks` | 3d | 7 | required_scope_binding_verification | binding unresolved; barracks, barracks-damaged |
| `rts-skins/kingdoms/westafrica/tower` | 3d | 7 | required_scope_binding_verification | binding unresolved; tower, tower-damaged |
| `rts-skins/kingdoms/westafrica/town-hall` | 3d | 7 | required_scope_binding_verification | binding unresolved; town-hall, town-hall-damaged |
| `rts-skins/kingdoms/westafrica/trade-post` | 3d | 7 | required_scope_binding_verification | binding unresolved; trade-post, trade-post-damaged |
| `rts-skins/modern/americas/barracks` | 3d | 7 | required_scope_binding_verification | binding unresolved; barracks, barracks-damaged |
| `rts-skins/modern/americas/tower` | 3d | 7 | required_scope_binding_verification | binding unresolved; tower, tower-damaged |
| `rts-skins/modern/americas/town-hall` | 3d | 7 | required_scope_binding_verification | binding unresolved; town-hall, town-hall-damaged |
| `rts-skins/modern/americas/trade-post` | 3d | 7 | required_scope_binding_verification | binding unresolved; trade-post, trade-post-damaged |
| `rts-skins/modern/eastafrica/barracks` | 3d | 7 | required_scope_binding_verification | binding unresolved; barracks, barracks-damaged |
| `rts-skins/modern/eastafrica/tower` | 3d | 7 | required_scope_binding_verification | binding unresolved; tower, tower-damaged |
| `rts-skins/modern/eastafrica/town-hall` | 3d | 7 | required_scope_binding_verification | binding unresolved; town-hall, town-hall-damaged |
| `rts-skins/modern/eastafrica/trade-post` | 3d | 7 | required_scope_binding_verification | binding unresolved; trade-post, trade-post-damaged |
| `rts-skins/modern/europe/barracks` | 3d | 7 | required_scope_binding_verification | binding unresolved; barracks, barracks-damaged |
| `rts-skins/modern/europe/tower` | 3d | 7 | required_scope_binding_verification | binding unresolved; tower, tower-damaged |
| `rts-skins/modern/europe/town-hall` | 3d | 7 | required_scope_binding_verification | binding unresolved; town-hall, town-hall-damaged |
| `rts-skins/modern/europe/trade-post` | 3d | 7 | required_scope_binding_verification | binding unresolved; trade-post, trade-post-damaged |
| `rts-skins/modern/indic/barracks` | 3d | 7 | required_scope_binding_verification | binding unresolved; barracks, barracks-damaged |
| `rts-skins/modern/indic/tower` | 3d | 7 | required_scope_binding_verification | binding unresolved; tower, tower-damaged |
| `rts-skins/modern/indic/town-hall` | 3d | 7 | required_scope_binding_verification | binding unresolved; town-hall, town-hall-damaged |
| `rts-skins/modern/indic/trade-post` | 3d | 7 | required_scope_binding_verification | binding unresolved; trade-post, trade-post-damaged |
| `rts-skins/modern/israelite/barracks` | 3d | 7 | required_scope_binding_verification | binding unresolved; barracks, barracks-damaged |
| `rts-skins/modern/israelite/tower` | 3d | 7 | required_scope_binding_verification | binding unresolved; tower, tower-damaged |
| `rts-skins/modern/israelite/town-hall` | 3d | 7 | required_scope_binding_verification | binding unresolved; town-hall, town-hall-damaged |
| `rts-skins/modern/israelite/trade-post` | 3d | 7 | required_scope_binding_verification | binding unresolved; trade-post, trade-post-damaged |
| `rts-skins/modern/japan/barracks` | 3d | 7 | required_scope_binding_verification | binding unresolved; barracks, barracks-damaged |
| `rts-skins/modern/japan/tower` | 3d | 7 | required_scope_binding_verification | binding unresolved; tower, tower-damaged |
| `rts-skins/modern/japan/town-hall` | 3d | 7 | required_scope_binding_verification | binding unresolved; town-hall, town-hall-damaged |
| `rts-skins/modern/japan/trade-post` | 3d | 7 | required_scope_binding_verification | binding unresolved; trade-post, trade-post-damaged |
| `rts-skins/modern/korea/barracks` | 3d | 7 | required_scope_binding_verification | binding unresolved; barracks, barracks-damaged |
| `rts-skins/modern/korea/tower` | 3d | 7 | required_scope_binding_verification | binding unresolved; tower, tower-damaged |
| `rts-skins/modern/korea/town-hall` | 3d | 7 | required_scope_binding_verification | binding unresolved; town-hall, town-hall-damaged |
| `rts-skins/modern/korea/trade-post` | 3d | 7 | required_scope_binding_verification | binding unresolved; trade-post, trade-post-damaged |
| `rts-skins/modern/levant/barracks` | 3d | 7 | required_scope_binding_verification | binding unresolved; barracks, barracks-damaged |
| `rts-skins/modern/levant/tower` | 3d | 7 | required_scope_binding_verification | binding unresolved; tower, tower-damaged |
| `rts-skins/modern/levant/town-hall` | 3d | 7 | required_scope_binding_verification | binding unresolved; town-hall, town-hall-damaged |
| `rts-skins/modern/levant/trade-post` | 3d | 7 | required_scope_binding_verification | binding unresolved; trade-post, trade-post-damaged |
| `rts-skins/modern/maghreb/barracks` | 3d | 7 | required_scope_binding_verification | binding unresolved; barracks, barracks-damaged |
| `rts-skins/modern/maghreb/tower` | 3d | 7 | required_scope_binding_verification | binding unresolved; tower, tower-damaged |
| `rts-skins/modern/maghreb/town-hall` | 3d | 7 | required_scope_binding_verification | binding unresolved; town-hall, town-hall-damaged |
| `rts-skins/modern/maghreb/trade-post` | 3d | 7 | required_scope_binding_verification | binding unresolved; trade-post, trade-post-damaged |
| `rts-skins/modern/monsoon/barracks` | 3d | 7 | required_scope_binding_verification | binding unresolved; barracks, barracks-damaged |
| `rts-skins/modern/monsoon/tower` | 3d | 7 | required_scope_binding_verification | binding unresolved; tower, tower-damaged |
| `rts-skins/modern/monsoon/town-hall` | 3d | 7 | required_scope_binding_verification | binding unresolved; town-hall, town-hall-damaged |
| `rts-skins/modern/monsoon/trade-post` | 3d | 7 | required_scope_binding_verification | binding unresolved; trade-post, trade-post-damaged |
| `rts-skins/modern/nile/barracks` | 3d | 7 | required_scope_binding_verification | binding unresolved; barracks, barracks-damaged |
| `rts-skins/modern/nile/tower` | 3d | 7 | required_scope_binding_verification | binding unresolved; tower, tower-damaged |
| `rts-skins/modern/nile/town-hall` | 3d | 7 | required_scope_binding_verification | binding unresolved; town-hall, town-hall-damaged |
| `rts-skins/modern/nile/trade-post` | 3d | 7 | required_scope_binding_verification | binding unresolved; trade-post, trade-post-damaged |
| `rts-skins/modern/pacific/barracks` | 3d | 7 | required_scope_binding_verification | binding unresolved; barracks, barracks-damaged |
| `rts-skins/modern/pacific/tower` | 3d | 7 | required_scope_binding_verification | binding unresolved; tower, tower-damaged |
| `rts-skins/modern/pacific/town-hall` | 3d | 7 | required_scope_binding_verification | binding unresolved; town-hall, town-hall-damaged |
| `rts-skins/modern/pacific/trade-post` | 3d | 7 | required_scope_binding_verification | binding unresolved; trade-post, trade-post-damaged |
| `rts-skins/modern/sinic/barracks` | 3d | 7 | required_scope_binding_verification | binding unresolved; barracks, barracks-damaged |
| `rts-skins/modern/sinic/tower` | 3d | 7 | required_scope_binding_verification | binding unresolved; tower, tower-damaged |
| `rts-skins/modern/sinic/town-hall` | 3d | 7 | required_scope_binding_verification | binding unresolved; town-hall, town-hall-damaged |
| `rts-skins/modern/sinic/trade-post` | 3d | 7 | required_scope_binding_verification | binding unresolved; trade-post, trade-post-damaged |
| `rts-skins/modern/steppe/barracks` | 3d | 7 | required_scope_binding_verification | binding unresolved; barracks, barracks-damaged |
| `rts-skins/modern/steppe/tower` | 3d | 7 | required_scope_binding_verification | binding unresolved; tower, tower-damaged |
| `rts-skins/modern/steppe/town-hall` | 3d | 7 | required_scope_binding_verification | binding unresolved; town-hall, town-hall-damaged |
| `rts-skins/modern/steppe/trade-post` | 3d | 7 | required_scope_binding_verification | binding unresolved; trade-post, trade-post-damaged |
| `rts-skins/modern/westafrica/barracks` | 3d | 7 | required_scope_binding_verification | binding unresolved; barracks, barracks-damaged |
| `rts-skins/modern/westafrica/tower` | 3d | 7 | required_scope_binding_verification | binding unresolved; tower, tower-damaged |
| `rts-skins/modern/westafrica/town-hall` | 3d | 7 | required_scope_binding_verification | binding unresolved; town-hall, town-hall-damaged |
| `rts-skins/modern/westafrica/trade-post` | 3d | 7 | required_scope_binding_verification | binding unresolved; trade-post, trade-post-damaged |
| `ships/carrier-modern` | 3d | 7 | definitive_missing_declared_target | src/assets/ships/carrier-modern.glb |
| `ships/raider-classical` | 3d | 7 | definitive_missing_declared_target | src/assets/ships/raider-classical.glb |
| `ships/raider-gunpowder` | 3d | 7 | definitive_missing_declared_target | src/assets/ships/raider-gunpowder.glb |
| `ships/raider-kingdoms` | 3d | 7 | definitive_missing_declared_target | src/assets/ships/raider-kingdoms.glb |
| `ships/raider-modern` | 3d | 7 | definitive_missing_declared_target | src/assets/ships/raider-modern.glb |
| `ships/transport-classical` | 3d | 7 | definitive_missing_declared_target | src/assets/ships/transport-classical.glb |
| `ships/transport-gunpowder` | 3d | 7 | definitive_missing_declared_target | src/assets/ships/transport-gunpowder.glb |
| `ships/transport-kingdoms` | 3d | 7 | definitive_missing_declared_target | src/assets/ships/transport-kingdoms.glb |
| `ships/transport-modern` | 3d | 7 | definitive_missing_declared_target | src/assets/ships/transport-modern.glb |
| `ships/warship-bronze` | 3d | 7 | recorded_built_delivery_validation | src/assets/ships/warship-bronze.glb |
| `ships/warship-classical` | 3d | 7 | recorded_built_delivery_validation | src/assets/ships/warship-classical.glb |
| `ships/warship-gunpowder` | 3d | 7 | definitive_missing_declared_target | src/assets/ships/warship-gunpowder.glb |
| `ships/warship-kingdoms` | 3d | 7 | recorded_built_delivery_validation | src/assets/ships/warship-kingdoms.glb |
| `ships/warship-modern` | 3d | 7 | definitive_missing_declared_target | src/assets/ships/warship-modern.glb |
| `fog/last-seen-lut` | 2d | 8 | definitive_missing_declared_target | public/map/fog/last-seen-lut/ |
| `fog/style-frame` | 2d | 8 | definitive_missing_declared_target | public/fog/style-frame.webp |
| `fog/unexplored-edge` | 2d | 8 | definitive_missing_declared_target | public/map/fog/unexplored-edge/ |
| `fog/unexplored-mask` | 2d | 8 | definitive_missing_declared_target | public/map/fog/unexplored-mask/ |
| `fx/projectiles-bronze` | 2d | 8 | definitive_missing_declared_target | src/assets/fx/projectiles-bronze/ |
| `fx/projectiles-classical` | 2d | 8 | definitive_missing_declared_target | src/assets/fx/projectiles-classical/ |
| `fx/projectiles-gunpowder` | 2d | 8 | definitive_missing_declared_target | src/assets/fx/projectiles-gunpowder/ |
| `fx/projectiles-kingdoms` | 2d | 8 | definitive_missing_declared_target | src/assets/fx/projectiles-kingdoms/ |
| `fx/projectiles-modern` | 2d | 8 | definitive_missing_declared_target | src/assets/fx/projectiles-modern/ |
| `icons/battle/build-aid-post` | 2d | 8 | definitive_missing_declared_target | src/assets/icons/battle/build-aid-post.svg |
| `icons/battle/build-barracks` | 2d | 8 | definitive_missing_declared_target | src/assets/icons/battle/build-barracks.svg |
| `icons/battle/build-expedition-camp` | 2d | 8 | definitive_missing_declared_target | src/assets/icons/battle/build-expedition-camp.svg |
| `icons/battle/build-farm-plot` | 2d | 8 | definitive_missing_declared_target | src/assets/icons/battle/build-farm-plot.svg |
| `icons/battle/build-food-depot` | 2d | 8 | definitive_missing_declared_target | src/assets/icons/battle/build-food-depot.svg |
| `icons/battle/build-gate` | 2d | 8 | definitive_missing_declared_target | src/assets/icons/battle/build-gate.svg |
| `icons/battle/build-house` | 2d | 8 | definitive_missing_declared_target | src/assets/icons/battle/build-house.svg |
| `icons/battle/build-materials-yard` | 2d | 8 | definitive_missing_declared_target | src/assets/icons/battle/build-materials-yard.svg |
| `icons/battle/build-mine` | 2d | 8 | definitive_missing_declared_target | src/assets/icons/battle/build-mine.svg |
| `icons/battle/build-range` | 2d | 8 | definitive_missing_declared_target | src/assets/icons/battle/build-range.svg |
| `icons/battle/build-siege-workshop` | 2d | 8 | definitive_missing_declared_target | src/assets/icons/battle/build-siege-workshop.svg |
| `icons/battle/build-stable` | 2d | 8 | definitive_missing_declared_target | src/assets/icons/battle/build-stable.svg |
| `icons/battle/build-tower` | 2d | 8 | definitive_missing_declared_target | src/assets/icons/battle/build-tower.svg |
| `icons/battle/build-town-hall` | 2d | 8 | definitive_missing_declared_target | src/assets/icons/battle/build-town-hall.svg |
| `icons/battle/build-trade-post` | 2d | 8 | definitive_missing_declared_target | src/assets/icons/battle/build-trade-post.svg |
| `icons/battle/build-wall` | 2d | 8 | definitive_missing_declared_target | src/assets/icons/battle/build-wall.svg |
| `icons/battle/captives` | 2d | 8 | definitive_missing_declared_target | src/assets/icons/battle/captives.svg |
| `icons/battle/cmd-attack-move` | 2d | 8 | definitive_missing_declared_target | src/assets/icons/battle/cmd-attack-move.svg |
| `icons/battle/cmd-build` | 2d | 8 | definitive_missing_declared_target | src/assets/icons/battle/cmd-build.svg |
| `icons/battle/cmd-formation-column` | 2d | 8 | definitive_missing_declared_target | src/assets/icons/battle/cmd-formation-column.svg |
| `icons/battle/cmd-formation-line` | 2d | 8 | definitive_missing_declared_target | src/assets/icons/battle/cmd-formation-line.svg |
| `icons/battle/cmd-formation-wedge` | 2d | 8 | definitive_missing_declared_target | src/assets/icons/battle/cmd-formation-wedge.svg |
| `icons/battle/cmd-gather` | 2d | 8 | definitive_missing_declared_target | src/assets/icons/battle/cmd-gather.svg |
| `icons/battle/cmd-hold` | 2d | 8 | definitive_missing_declared_target | src/assets/icons/battle/cmd-hold.svg |
| `icons/battle/cmd-patrol` | 2d | 8 | definitive_missing_declared_target | src/assets/icons/battle/cmd-patrol.svg |
| `icons/battle/cmd-rally` | 2d | 8 | definitive_missing_declared_target | src/assets/icons/battle/cmd-rally.svg |
| `icons/battle/cmd-repair` | 2d | 8 | definitive_missing_declared_target | src/assets/icons/battle/cmd-repair.svg |
| `icons/battle/cmd-retreat` | 2d | 8 | definitive_missing_declared_target | src/assets/icons/battle/cmd-retreat.svg |
| `icons/battle/cmd-return-goods` | 2d | 8 | definitive_missing_declared_target | src/assets/icons/battle/cmd-return-goods.svg |
| `icons/battle/cmd-stop` | 2d | 8 | definitive_missing_declared_target | src/assets/icons/battle/cmd-stop.svg |
| `icons/battle/intel` | 2d | 8 | definitive_missing_declared_target | src/assets/icons/battle/intel.svg |
| `icons/battle/kind-field` | 2d | 8 | definitive_missing_declared_target | src/assets/icons/battle/kind-field.svg |
| `icons/battle/kind-landing` | 2d | 8 | definitive_missing_declared_target | src/assets/icons/battle/kind-landing.svg |
| `icons/battle/kind-raid` | 2d | 8 | definitive_missing_declared_target | src/assets/icons/battle/kind-raid.svg |
| `icons/battle/kind-sack` | 2d | 8 | definitive_missing_declared_target | src/assets/icons/battle/kind-sack.svg |
| `icons/battle/kind-sally` | 2d | 8 | definitive_missing_declared_target | src/assets/icons/battle/kind-sally.svg |
| `icons/battle/kind-sea` | 2d | 8 | definitive_missing_declared_target | src/assets/icons/battle/kind-sea.svg |
| `icons/battle/kind-siege` | 2d | 8 | definitive_missing_declared_target | src/assets/icons/battle/kind-siege.svg |
| `icons/battle/mode-auto` | 2d | 8 | definitive_missing_declared_target | src/assets/icons/battle/mode-auto.svg |
| `icons/battle/mode-command` | 2d | 8 | definitive_missing_declared_target | src/assets/icons/battle/mode-command.svg |
| `icons/battle/outcome-city-taken` | 2d | 8 | definitive_missing_declared_target | src/assets/icons/battle/outcome-city-taken.svg |
| `icons/battle/outcome-defeat` | 2d | 8 | definitive_missing_declared_target | src/assets/icons/battle/outcome-defeat.svg |
| `icons/battle/outcome-victory` | 2d | 8 | definitive_missing_declared_target | src/assets/icons/battle/outcome-victory.svg |
| `icons/battle/outcome-withdrawal` | 2d | 8 | definitive_missing_declared_target | src/assets/icons/battle/outcome-withdrawal.svg |
| `icons/battle/population` | 2d | 8 | definitive_missing_declared_target | src/assets/icons/battle/population.svg |
| `icons/battle/ransom` | 2d | 8 | definitive_missing_declared_target | src/assets/icons/battle/ransom.svg |
| `icons/battle/recruit-auxiliary` | 2d | 8 | definitive_missing_declared_target | src/assets/icons/battle/recruit-auxiliary.svg |
| `icons/battle/recruit-regular` | 2d | 8 | definitive_missing_declared_target | src/assets/icons/battle/recruit-regular.svg |
| `icons/battle/reinforcements` | 2d | 8 | definitive_missing_declared_target | src/assets/icons/battle/reinforcements.svg |
| `icons/battle/release` | 2d | 8 | definitive_missing_declared_target | src/assets/icons/battle/release.svg |
| `icons/battle/resource-food` | 2d | 8 | definitive_missing_declared_target | src/assets/icons/battle/resource-food.svg |
| `icons/battle/resource-gold` | 2d | 8 | definitive_missing_declared_target | src/assets/icons/battle/resource-gold.svg |
| `icons/battle/resource-materials` | 2d | 8 | definitive_missing_declared_target | src/assets/icons/battle/resource-materials.svg |
| `icons/battle/war-score` | 2d | 8 | definitive_missing_declared_target | src/assets/icons/battle/war-score.svg |
| `icons/independents/fortress` | 2d | 8 | definitive_missing_declared_target | src/assets/icons/independents/fortress.svg |
| `icons/independents/grudge` | 2d | 8 | definitive_missing_declared_target | src/assets/icons/independents/grudge.svg |
| `icons/independents/hire-mercenaries` | 2d | 8 | definitive_missing_declared_target | src/assets/icons/independents/hire-mercenaries.svg |
| `icons/independents/mercantile` | 2d | 8 | definitive_missing_declared_target | src/assets/icons/independents/mercantile.svg |
| `icons/independents/mercenary-contract` | 2d | 8 | definitive_missing_declared_target | src/assets/icons/independents/mercenary-contract.svg |
| `icons/independents/raid-torch` | 2d | 8 | definitive_missing_declared_target | src/assets/icons/independents/raid-torch.svg |
| `icons/independents/raiders` | 2d | 8 | definitive_missing_declared_target | src/assets/icons/independents/raiders.svg |
| `icons/independents/raze` | 2d | 8 | definitive_missing_declared_target | src/assets/icons/independents/raze.svg |
| `icons/independents/submit` | 2d | 8 | definitive_missing_declared_target | src/assets/icons/independents/submit.svg |
| `icons/independents/trade-pact` | 2d | 8 | definitive_missing_declared_target | src/assets/icons/independents/trade-pact.svg |
| `icons/independents/tribal` | 2d | 8 | definitive_missing_declared_target | src/assets/icons/independents/tribal.svg |
| `icons/independents/tribute` | 2d | 8 | definitive_missing_declared_target | src/assets/icons/independents/tribute.svg |
| `icons/markers/last-seen` | 2d | 8 | definitive_missing_declared_target | src/assets/icons/markers/last-seen.svg |
| `icons/markers/sea-battle` | 2d | 8 | definitive_missing_declared_target | src/assets/icons/markers/sea-battle.svg |
| `icons/markers/siege` | 2d | 8 | definitive_missing_declared_target | src/assets/icons/markers/siege.svg |
| `icons/markers/unknown-people` | 2d | 8 | definitive_missing_declared_target | src/assets/icons/markers/unknown-people.svg |
| `icons/regions/africa` | 2d | 8 | definitive_missing_declared_target | src/assets/icons/regions/africa.svg |
| `icons/regions/americas` | 2d | 8 | definitive_missing_declared_target | src/assets/icons/regions/americas.svg |
| `icons/regions/asia` | 2d | 8 | definitive_missing_declared_target | src/assets/icons/regions/asia.svg |
| `icons/regions/europe` | 2d | 8 | definitive_missing_declared_target | src/assets/icons/regions/europe.svg |
| `icons/regions/neareast` | 2d | 8 | definitive_missing_declared_target | src/assets/icons/regions/neareast.svg |
| `icons/regions/oceania` | 2d | 8 | definitive_missing_declared_target | src/assets/icons/regions/oceania.svg |
| `icons/themes/americas` | 2d | 8 | definitive_missing_declared_target | src/assets/icons/themes/americas.svg |
| `icons/themes/eastafrica` | 2d | 8 | definitive_missing_declared_target | src/assets/icons/themes/eastafrica.svg |
| `icons/themes/europe` | 2d | 8 | definitive_missing_declared_target | src/assets/icons/themes/europe.svg |
| `icons/themes/indic` | 2d | 8 | definitive_missing_declared_target | src/assets/icons/themes/indic.svg |
| `icons/themes/israelite` | 2d | 8 | definitive_missing_declared_target | src/assets/icons/themes/israelite.svg |
| `icons/themes/japan` | 2d | 8 | definitive_missing_declared_target | src/assets/icons/themes/japan.svg |
| `icons/themes/korea` | 2d | 8 | definitive_missing_declared_target | src/assets/icons/themes/korea.svg |
| `icons/themes/levant` | 2d | 8 | definitive_missing_declared_target | src/assets/icons/themes/levant.svg |
| `icons/themes/maghreb` | 2d | 8 | definitive_missing_declared_target | src/assets/icons/themes/maghreb.svg |
| `icons/themes/monsoon` | 2d | 8 | definitive_missing_declared_target | src/assets/icons/themes/monsoon.svg |
| `icons/themes/nile` | 2d | 8 | definitive_missing_declared_target | src/assets/icons/themes/nile.svg |
| `icons/themes/pacific` | 2d | 8 | definitive_missing_declared_target | src/assets/icons/themes/pacific.svg |
| `icons/themes/sinic` | 2d | 8 | definitive_missing_declared_target | src/assets/icons/themes/sinic.svg |
| `icons/themes/steppe` | 2d | 8 | definitive_missing_declared_target | src/assets/icons/themes/steppe.svg |
| `icons/themes/westafrica` | 2d | 8 | definitive_missing_declared_target | src/assets/icons/themes/westafrica.svg |
| `icons/units/worker` | 2d | 8 | definitive_missing_declared_target | src/assets/icons/units/worker.svg |
| `map-markers/ai-battle-clash` | 2d | 8 | definitive_missing_declared_target | src/assets/map/sprites/ai-battle-clash/ |
| `map-markers/ai-battle-smoke` | 2d | 8 | definitive_missing_declared_target | src/assets/map/sprites/ai-battle-smoke/ |
| `map-markers/army-base` | 2d | 8 | definitive_missing_declared_target | src/assets/map/sprites/army-base/ |
| `map-markers/badge-plate` | 2d | 8 | definitive_missing_declared_target | src/assets/map/sprites/badge-plate/ |
| `map-markers/battle-result` | 2d | 8 | definitive_missing_declared_target | src/assets/map/sprites/battle-result/ |
| `map-markers/route-dots` | 2d | 8 | definitive_missing_declared_target | src/assets/map/sprites/route-dots/ |
| `map-markers/standard-bronze` | 2d | 8 | definitive_missing_declared_target | src/assets/map/sprites/standard-bronze/ |
| `map-markers/standard-classical` | 2d | 8 | definitive_missing_declared_target | src/assets/map/sprites/standard-classical/ |
| `map-markers/standard-gunpowder` | 2d | 8 | definitive_missing_declared_target | src/assets/map/sprites/standard-gunpowder/ |
| `map-markers/standard-kingdoms` | 2d | 8 | definitive_missing_declared_target | src/assets/map/sprites/standard-kingdoms/ |
| `map-markers/standard-modern` | 2d | 8 | definitive_missing_declared_target | src/assets/map/sprites/standard-modern/ |
| `map-terrain/ground-tundra` | 2d | 8 | definitive_missing_declared_target | public/terrain/ground-tundra/ |
| `peoples/emblems/aghvank` | 2d | 8 | definitive_missing_declared_target | src/assets/peoples/emblems/aghvank.svg |
| `peoples/emblems/ahhiyawa` | 2d | 8 | definitive_missing_declared_target | src/assets/peoples/emblems/ahhiyawa.svg |
| `peoples/emblems/ajuran` | 2d | 8 | definitive_missing_declared_target | src/assets/peoples/emblems/ajuran.svg |
| `peoples/emblems/akkad` | 2d | 8 | definitive_missing_declared_target | src/assets/peoples/emblems/akkad.svg |
| `peoples/emblems/alodia` | 2d | 8 | definitive_missing_declared_target | src/assets/peoples/emblems/alodia.svg |
| `peoples/emblems/andronovo` | 2d | 8 | definitive_missing_declared_target | src/assets/peoples/emblems/andronovo.svg |
| `peoples/emblems/arverni` | 2d | 8 | definitive_missing_declared_target | src/assets/peoples/emblems/arverni.svg |
| `peoples/emblems/avanti` | 2d | 8 | definitive_missing_declared_target | src/assets/peoples/emblems/avanti.svg |
| `peoples/emblems/avaria` | 2d | 8 | definitive_missing_declared_target | src/assets/peoples/emblems/avaria.svg |
| `peoples/emblems/bactria` | 2d | 8 | definitive_missing_declared_target | src/assets/peoples/emblems/bactria.svg |
| `peoples/emblems/baekje` | 2d | 8 | definitive_missing_declared_target | src/assets/peoples/emblems/baekje.svg |
| `peoples/emblems/bau` | 2d | 8 | definitive_missing_declared_target | src/assets/peoples/emblems/bau.svg |
| `peoples/emblems/belgae` | 2d | 8 | definitive_missing_declared_target | src/assets/peoples/emblems/belgae.svg |
| `peoples/emblems/bono` | 2d | 8 | definitive_missing_declared_target | src/assets/peoples/emblems/bono.svg |
| `peoples/emblems/bosporan` | 2d | 8 | definitive_missing_declared_target | src/assets/peoples/emblems/bosporan.svg |
| `peoples/emblems/botai` | 2d | 8 | definitive_missing_declared_target | src/assets/peoples/emblems/botai.svg |
| `peoples/emblems/brigantes` | 2d | 8 | definitive_missing_declared_target | src/assets/peoples/emblems/brigantes.svg |
| `peoples/emblems/butuan` | 2d | 8 | definitive_missing_declared_target | src/assets/peoples/emblems/butuan.svg |
| `peoples/emblems/buyeo` | 2d | 8 | definitive_missing_declared_target | src/assets/peoples/emblems/buyeo.svg |
| `peoples/emblems/calusa` | 2d | 8 | definitive_missing_declared_target | src/assets/peoples/emblems/calusa.svg |
| `peoples/emblems/caral` | 2d | 8 | definitive_missing_declared_target | src/assets/peoples/emblems/caral.svg |
| `peoples/emblems/celtiberia` | 2d | 8 | definitive_missing_declared_target | src/assets/peoples/emblems/celtiberia.svg |
| `peoples/emblems/chaco` | 2d | 8 | definitive_missing_declared_target | src/assets/peoples/emblems/chaco.svg |
| `peoples/emblems/champa` | 2d | 8 | definitive_missing_declared_target | src/assets/peoples/emblems/champa.svg |
| `peoples/emblems/cherusci` | 2d | 8 | definitive_missing_declared_target | src/assets/peoples/emblems/cherusci.svg |
| `peoples/emblems/chu` | 2d | 8 | definitive_missing_declared_target | src/assets/peoples/emblems/chu.svg |
| `peoples/emblems/colchis` | 2d | 8 | definitive_missing_declared_target | src/assets/peoples/emblems/colchis.svg |
| `peoples/emblems/cucuteni` | 2d | 8 | definitive_missing_declared_target | src/assets/peoples/emblems/cucuteni.svg |
| `peoples/emblems/cyrene` | 2d | 8 | definitive_missing_declared_target | src/assets/peoples/emblems/cyrene.svg |
| `peoples/emblems/dacia` | 2d | 8 | definitive_missing_declared_target | src/assets/peoples/emblems/dacia.svg |
| `peoples/emblems/diaguita` | 2d | 8 | definitive_missing_declared_target | src/assets/peoples/emblems/diaguita.svg |
| `peoples/emblems/dian` | 2d | 8 | definitive_missing_declared_target | src/assets/peoples/emblems/dian.svg |
| `peoples/emblems/dilmun` | 2d | 8 | definitive_missing_declared_target | src/assets/peoples/emblems/dilmun.svg |
| `peoples/emblems/djenne-djeno` | 2d | 8 | definitive_missing_declared_target | src/assets/peoples/emblems/djenne-djeno.svg |
| `peoples/emblems/dmt` | 2d | 8 | definitive_missing_declared_target | src/assets/peoples/emblems/dmt.svg |
| `peoples/emblems/dorset` | 2d | 8 | definitive_missing_declared_target | src/assets/peoples/emblems/dorset.svg |
| `peoples/emblems/durotriges` | 2d | 8 | definitive_missing_declared_target | src/assets/peoples/emblems/durotriges.svg |
| `peoples/emblems/dvaravati` | 2d | 8 | definitive_missing_declared_target | src/assets/peoples/emblems/dvaravati.svg |
| `peoples/emblems/elam` | 2d | 8 | definitive_missing_declared_target | src/assets/peoples/emblems/elam.svg |
| `peoples/emblems/emishi` | 2d | 8 | definitive_missing_declared_target | src/assets/peoples/emblems/emishi.svg |
| `peoples/emblems/engaruka` | 2d | 8 | definitive_missing_declared_target | src/assets/peoples/emblems/engaruka.svg |
| `peoples/emblems/fortriu` | 2d | 8 | definitive_missing_declared_target | src/assets/peoples/emblems/fortriu.svg |
| `peoples/emblems/funan` | 2d | 8 | definitive_missing_declared_target | src/assets/peoples/emblems/funan.svg |
| `peoples/emblems/gandhara` | 2d | 8 | definitive_missing_declared_target | src/assets/peoples/emblems/gandhara.svg |
| `peoples/emblems/garamantes` | 2d | 8 | definitive_missing_declared_target | src/assets/peoples/emblems/garamantes.svg |
| `peoples/emblems/geats` | 2d | 8 | definitive_missing_declared_target | src/assets/peoples/emblems/geats.svg |
| `peoples/emblems/gojoseon` | 2d | 8 | definitive_missing_declared_target | src/assets/peoples/emblems/gojoseon.svg |
| `peoples/emblems/gokturk` | 2d | 8 | definitive_missing_declared_target | src/assets/peoples/emblems/gokturk.svg |
| `peoples/emblems/gunditjmara` | 2d | 8 | definitive_missing_declared_target | src/assets/peoples/emblems/gunditjmara.svg |
| `peoples/emblems/haida` | 2d | 8 | definitive_missing_declared_target | src/assets/peoples/emblems/haida.svg |
| `peoples/emblems/hohokam` | 2d | 8 | definitive_missing_declared_target | src/assets/peoples/emblems/hohokam.svg |
| `peoples/emblems/hopewell` | 2d | 8 | definitive_missing_declared_target | src/assets/peoples/emblems/hopewell.svg |
| `peoples/emblems/ife` | 2d | 8 | definitive_missing_declared_target | src/assets/peoples/emblems/ife.svg |
| `peoples/emblems/illyria` | 2d | 8 | definitive_missing_declared_target | src/assets/peoples/emblems/illyria.svg |
| `peoples/emblems/israel` | 2d | 8 | definitive_missing_declared_target | src/assets/peoples/emblems/israel.svg |
| `peoples/emblems/jaragua` | 2d | 8 | definitive_missing_declared_target | src/assets/peoples/emblems/jaragua.svg |
| `peoples/emblems/kalinago` | 2d | 8 | definitive_missing_declared_target | src/assets/peoples/emblems/kalinago.svg |
| `peoples/emblems/kalinga` | 2d | 8 | definitive_missing_declared_target | src/assets/peoples/emblems/kalinga.svg |
| `peoples/emblems/kamarupa` | 2d | 8 | definitive_missing_declared_target | src/assets/peoples/emblems/kamarupa.svg |
| `peoples/emblems/kanem` | 2d | 8 | definitive_missing_declared_target | src/assets/peoples/emblems/kanem.svg |
| `peoples/emblems/kanesh` | 2d | 8 | definitive_missing_declared_target | src/assets/peoples/emblems/kanesh.svg |
| `peoples/emblems/keftiu` | 2d | 8 | definitive_missing_declared_target | src/assets/peoples/emblems/keftiu.svg |
| `peoples/emblems/kemet` | 2d | 8 | definitive_missing_declared_target | src/assets/peoples/emblems/kemet.svg |
| `peoples/emblems/kerma` | 2d | 8 | definitive_missing_declared_target | src/assets/peoples/emblems/kerma.svg |
| `peoples/emblems/khazaria` | 2d | 8 | definitive_missing_declared_target | src/assets/peoples/emblems/khazaria.svg |
| `peoples/emblems/khoekhoe` | 2d | 8 | definitive_missing_declared_target | src/assets/peoples/emblems/khoekhoe.svg |
| `peoples/emblems/khotan` | 2d | 8 | definitive_missing_declared_target | src/assets/peoples/emblems/khotan.svg |
| `peoples/emblems/khwarazm` | 2d | 8 | definitive_missing_declared_target | src/assets/peoples/emblems/khwarazm.svg |
| `peoples/emblems/kilwa` | 2d | 8 | definitive_missing_declared_target | src/assets/peoples/emblems/kilwa.svg |
| `peoples/emblems/kindah` | 2d | 8 | definitive_missing_declared_target | src/assets/peoples/emblems/kindah.svg |
| `peoples/emblems/kitara` | 2d | 8 | definitive_missing_declared_target | src/assets/peoples/emblems/kitara.svg |
| `peoples/emblems/kosala` | 2d | 8 | definitive_missing_declared_target | src/assets/peoples/emblems/kosala.svg |
| `peoples/emblems/kroraina` | 2d | 8 | definitive_missing_declared_target | src/assets/peoples/emblems/kroraina.svg |
| `peoples/emblems/kuru` | 2d | 8 | definitive_missing_declared_target | src/assets/peoples/emblems/kuru.svg |
| `peoples/emblems/kutai` | 2d | 8 | definitive_missing_declared_target | src/assets/peoples/emblems/kutai.svg |
| `peoples/emblems/lapita` | 2d | 8 | definitive_missing_declared_target | src/assets/peoples/emblems/lapita.svg |
| `peoples/emblems/latte` | 2d | 8 | definitive_missing_declared_target | src/assets/peoples/emblems/latte.svg |
| `peoples/emblems/libu` | 2d | 8 | definitive_missing_declared_target | src/assets/peoples/emblems/libu.svg |
| `peoples/emblems/luba` | 2d | 8 | definitive_missing_declared_target | src/assets/peoples/emblems/luba.svg |
| `peoples/emblems/lunda` | 2d | 8 | definitive_missing_declared_target | src/assets/peoples/emblems/lunda.svg |
| `peoples/emblems/lusitania` | 2d | 8 | definitive_missing_declared_target | src/assets/peoples/emblems/lusitania.svg |
| `peoples/emblems/lydia` | 2d | 8 | definitive_missing_declared_target | src/assets/peoples/emblems/lydia.svg |
| `peoples/emblems/magadha` | 2d | 8 | definitive_missing_declared_target | src/assets/peoples/emblems/magadha.svg |
| `peoples/emblems/magan` | 2d | 8 | definitive_missing_declared_target | src/assets/peoples/emblems/magan.svg |
| `peoples/emblems/mapungubwe` | 2d | 8 | definitive_missing_declared_target | src/assets/peoples/emblems/mapungubwe.svg |
| `peoples/emblems/marajoara` | 2d | 8 | definitive_missing_declared_target | src/assets/peoples/emblems/marajoara.svg |
| `peoples/emblems/marcomannia` | 2d | 8 | definitive_missing_declared_target | src/assets/peoples/emblems/marcomannia.svg |
| `peoples/emblems/mari` | 2d | 8 | definitive_missing_declared_target | src/assets/peoples/emblems/mari.svg |
| `peoples/emblems/mauretania` | 2d | 8 | definitive_missing_declared_target | src/assets/peoples/emblems/mauretania.svg |
| `peoples/emblems/medang` | 2d | 8 | definitive_missing_declared_target | src/assets/peoples/emblems/medang.svg |
| `peoples/emblems/media` | 2d | 8 | definitive_missing_declared_target | src/assets/peoples/emblems/media.svg |
| `peoples/emblems/meluhha` | 2d | 8 | definitive_missing_declared_target | src/assets/peoples/emblems/meluhha.svg |
| `peoples/emblems/merina` | 2d | 8 | definitive_missing_declared_target | src/assets/peoples/emblems/merina.svg |
| `peoples/emblems/moche` | 2d | 8 | definitive_missing_declared_target | src/assets/peoples/emblems/moche.svg |
| `peoples/emblems/muisca` | 2d | 8 | definitive_missing_declared_target | src/assets/peoples/emblems/muisca.svg |
| `peoples/emblems/mutal` | 2d | 8 | definitive_missing_declared_target | src/assets/peoples/emblems/mutal.svg |
| `peoples/emblems/mutapa` | 2d | 8 | definitive_missing_declared_target | src/assets/peoples/emblems/mutapa.svg |
| `peoples/emblems/nabataea` | 2d | 8 | definitive_missing_declared_target | src/assets/peoples/emblems/nabataea.svg |
| `peoples/emblems/nanyue` | 2d | 8 | definitive_missing_declared_target | src/assets/peoples/emblems/nanyue.svg |
| `peoples/emblems/ndongo` | 2d | 8 | definitive_missing_declared_target | src/assets/peoples/emblems/ndongo.svg |
| `peoples/emblems/nok` | 2d | 8 | definitive_missing_declared_target | src/assets/peoples/emblems/nok.svg |
| `peoples/emblems/noricum` | 2d | 8 | definitive_missing_declared_target | src/assets/peoples/emblems/noricum.svg |
| `peoples/emblems/numidia` | 2d | 8 | definitive_missing_declared_target | src/assets/peoples/emblems/numidia.svg |
| `peoples/emblems/nuragi` | 2d | 8 | definitive_missing_declared_target | src/assets/peoples/emblems/nuragi.svg |
| `peoples/emblems/odrysia` | 2d | 8 | definitive_missing_declared_target | src/assets/peoples/emblems/odrysia.svg |
| `peoples/emblems/oxus` | 2d | 8 | definitive_missing_declared_target | src/assets/peoples/emblems/oxus.svg |
| `peoples/emblems/pandya` | 2d | 8 | definitive_missing_declared_target | src/assets/peoples/emblems/pandya.svg |
| `peoples/emblems/parthava` | 2d | 8 | definitive_missing_declared_target | src/assets/peoples/emblems/parthava.svg |
| `peoples/emblems/phrygia` | 2d | 8 | definitive_missing_declared_target | src/assets/peoples/emblems/phrygia.svg |
| `peoples/emblems/pontus` | 2d | 8 | definitive_missing_declared_target | src/assets/peoples/emblems/pontus.svg |
| `peoples/emblems/punt` | 2d | 8 | definitive_missing_declared_target | src/assets/peoples/emblems/punt.svg |
| `peoples/emblems/pyu` | 2d | 8 | definitive_missing_declared_target | src/assets/peoples/emblems/pyu.svg |
| `peoples/emblems/qedar` | 2d | 8 | definitive_missing_declared_target | src/assets/peoples/emblems/qedar.svg |
| `peoples/emblems/qi` | 2d | 8 | definitive_missing_declared_target | src/assets/peoples/emblems/qi.svg |
| `peoples/emblems/rajarata` | 2d | 8 | definitive_missing_declared_target | src/assets/peoples/emblems/rajarata.svg |
| `peoples/emblems/rasenna` | 2d | 8 | definitive_missing_declared_target | src/assets/peoples/emblems/rasenna.svg |
| `peoples/emblems/rygir` | 2d | 8 | definitive_missing_declared_target | src/assets/peoples/emblems/rygir.svg |
| `peoples/emblems/saba` | 2d | 8 | definitive_missing_declared_target | src/assets/peoples/emblems/saba.svg |
| `peoples/emblems/san` | 2d | 8 | definitive_missing_declared_target | src/assets/peoples/emblems/san.svg |
| `peoples/emblems/sarmatians` | 2d | 8 | definitive_missing_declared_target | src/assets/peoples/emblems/sarmatians.svg |
| `peoples/emblems/satavahana` | 2d | 8 | definitive_missing_declared_target | src/assets/peoples/emblems/satavahana.svg |
| `peoples/emblems/saudeleur` | 2d | 8 | definitive_missing_declared_target | src/assets/peoples/emblems/saudeleur.svg |
| `peoples/emblems/saurashtra` | 2d | 8 | definitive_missing_declared_target | src/assets/peoples/emblems/saurashtra.svg |
| `peoples/emblems/shang` | 2d | 8 | definitive_missing_declared_target | src/assets/peoples/emblems/shang.svg |
| `peoples/emblems/shu` | 2d | 8 | definitive_missing_declared_target | src/assets/peoples/emblems/shu.svg |
| `peoples/emblems/sogdia` | 2d | 8 | definitive_missing_declared_target | src/assets/peoples/emblems/sogdia.svg |
| `peoples/emblems/srivijaya` | 2d | 8 | definitive_missing_declared_target | src/assets/peoples/emblems/srivijaya.svg |
| `peoples/emblems/tartessos` | 2d | 8 | definitive_missing_declared_target | src/assets/peoples/emblems/tartessos.svg |
| `peoples/emblems/tarumanagara` | 2d | 8 | definitive_missing_declared_target | src/assets/peoples/emblems/tarumanagara.svg |
| `peoples/emblems/teotihuacan` | 2d | 8 | definitive_missing_declared_target | src/assets/peoples/emblems/teotihuacan.svg |
| `peoples/emblems/tichitt` | 2d | 8 | definitive_missing_declared_target | src/assets/peoples/emblems/tichitt.svg |
| `peoples/emblems/tiwanaku` | 2d | 8 | definitive_missing_declared_target | src/assets/peoples/emblems/tiwanaku.svg |
| `peoples/emblems/tondo` | 2d | 8 | definitive_missing_declared_target | src/assets/peoples/emblems/tondo.svg |
| `peoples/emblems/tupinamba` | 2d | 8 | definitive_missing_declared_target | src/assets/peoples/emblems/tupinamba.svg |
| `peoples/emblems/ugarit` | 2d | 8 | definitive_missing_declared_target | src/assets/peoples/emblems/ugarit.svg |
| `peoples/emblems/ulaid` | 2d | 8 | definitive_missing_declared_target | src/assets/peoples/emblems/ulaid.svg |
| `peoples/emblems/unknown` | 2d | 8 | definitive_missing_declared_target | src/assets/peoples/emblems/unknown.svg |
| `peoples/emblems/urartu` | 2d | 8 | definitive_missing_declared_target | src/assets/peoples/emblems/urartu.svg |
| `peoples/emblems/van-lang` | 2d | 8 | definitive_missing_declared_target | src/assets/peoples/emblems/van-lang.svg |
| `peoples/emblems/vanga` | 2d | 8 | definitive_missing_declared_target | src/assets/peoples/emblems/vanga.svg |
| `peoples/emblems/wagadu` | 2d | 8 | definitive_missing_declared_target | src/assets/peoples/emblems/wagadu.svg |
| `peoples/emblems/wahgi` | 2d | 8 | definitive_missing_declared_target | src/assets/peoples/emblems/wahgi.svg |
| `peoples/emblems/wari` | 2d | 8 | definitive_missing_declared_target | src/assets/peoples/emblems/wari.svg |
| `peoples/emblems/wusun` | 2d | 8 | definitive_missing_declared_target | src/assets/peoples/emblems/wusun.svg |
| `peoples/emblems/xianbei` | 2d | 8 | definitive_missing_declared_target | src/assets/peoples/emblems/xianbei.svg |
| `peoples/emblems/yamatai` | 2d | 8 | definitive_missing_declared_target | src/assets/peoples/emblems/yamatai.svg |
| `peoples/emblems/yarlung` | 2d | 8 | definitive_missing_declared_target | src/assets/peoples/emblems/yarlung.svg |
| `peoples/emblems/yue` | 2d | 8 | definitive_missing_declared_target | src/assets/peoples/emblems/yue.svg |
| `peoples/emblems/zapotec` | 2d | 8 | definitive_missing_declared_target | src/assets/peoples/emblems/zapotec.svg |
| `peoples/emblems/zhangzhung` | 2d | 8 | definitive_missing_declared_target | src/assets/peoples/emblems/zhangzhung.svg |
| `peoples/emblems/zhou` | 2d | 8 | definitive_missing_declared_target | src/assets/peoples/emblems/zhou.svg |
| `peoples/frames/banner` | 2d | 8 | definitive_missing_declared_target | public/peoples/frames/banner.webp |
| `peoples/frames/pennant` | 2d | 8 | definitive_missing_declared_target | src/assets/map/sprites/peoples/frames/pennant/ |
| `peoples/frames/shield` | 2d | 8 | required_scope_binding_verification | binding unresolved;  |
| `props/exit-marker` | 2d | 8 | definitive_missing_declared_target | src/assets/map/sprites/props/exit-marker/ |
| `textures/town-ground-bronze` | 2d | 8 | definitive_missing_declared_target | public/terrain/town-ground-bronze/ |
| `textures/town-ground-classical` | 2d | 8 | definitive_missing_declared_target | public/terrain/town-ground-classical/ |
| `textures/town-ground-gunpowder` | 2d | 8 | definitive_missing_declared_target | public/terrain/town-ground-gunpowder/ |
| `textures/town-ground-kingdoms` | 2d | 8 | definitive_missing_declared_target | public/terrain/town-ground-kingdoms/ |
| `textures/town-ground-modern` | 2d | 8 | definitive_missing_declared_target | public/terrain/town-ground-modern/ |
| `ui/battle/header-bronze` | 2d | 8 | definitive_missing_declared_target | public/ui/battle/header-bronze.webp |
| `ui/battle/header-classical` | 2d | 8 | definitive_missing_declared_target | public/ui/battle/header-classical.webp |
| `ui/battle/header-gunpowder` | 2d | 8 | definitive_missing_declared_target | public/ui/battle/header-gunpowder.webp |
| `ui/battle/header-kingdoms` | 2d | 8 | definitive_missing_declared_target | public/ui/battle/header-kingdoms.webp |
| `ui/battle/header-modern` | 2d | 8 | definitive_missing_declared_target | public/ui/battle/header-modern.webp |
| `ui/battle/result-defeat` | 2d | 8 | definitive_missing_declared_target | public/ui/battle/result-defeat.webp |
| `ui/battle/result-victory` | 2d | 8 | definitive_missing_declared_target | public/ui/battle/result-victory.webp |
| `ui/start/background-phone` | 2d | 8 | definitive_missing_declared_target | public/ui/start/background-phone.webp |
| `ui/start/background-wide` | 2d | 8 | definitive_missing_declared_target | public/ui/start/background-wide.webp |
| `ui/start/worldsize-large` | 2d | 8 | definitive_missing_declared_target | public/ui/start/worldsize-large.webp |
| `ui/start/worldsize-small` | 2d | 8 | definitive_missing_declared_target | public/ui/start/worldsize-small.webp |
| `ui/start/worldsize-standard` | 2d | 8 | definitive_missing_declared_target | public/ui/start/worldsize-standard.webp |

## Scope or matrix holds

| Id | Reason |
|---|---|
| `rts/bronze/house` | optional role, absent from current plan role table |
| `rts/classical/house` | optional role, absent from current plan role table |
| `rts/kingdoms/house` | optional role, absent from current plan role table |
| `rts/gunpowder/house` | optional role, absent from current plan role table |
| `rts/modern/house` | optional role, absent from current plan role table |
| `props/burnt-field-overlay` | legacy decal requirement outside current explicit model plan |
| `map-improvement-families/farm-maize` | family explicitly named; eligible ages and separate geometry/reuse matrix unresolved |
| `map-improvement-families/farm-paddy` | family explicitly named; eligible ages and separate geometry/reuse matrix unresolved |
| `map-improvement-families/farm-wheat` | family explicitly named; eligible ages and separate geometry/reuse matrix unresolved |
| `map-improvement-families/fishing-boats-dhow` | family explicitly named; eligible ages and separate geometry/reuse matrix unresolved |
| `map-improvement-families/fishing-boats-junk` | family explicitly named; eligible ages and separate geometry/reuse matrix unresolved |
| `map-improvement-families/fishing-boats-outrigger` | family explicitly named; eligible ages and separate geometry/reuse matrix unresolved |
