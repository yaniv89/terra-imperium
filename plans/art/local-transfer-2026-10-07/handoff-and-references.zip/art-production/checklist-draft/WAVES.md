# Wave assignments — draft

The latest attached assignment controls wave numbering. ART-MODELS-PLAN §12 source wave 2 (Bronze signatures) is folded into assigned wave 1; source wave 3 map becomes assigned wave 2; Classical/Kingdoms/Gunpowder/Modern source waves 4/5/6/7 become assigned 3/4/5/6. All 150 signatures retain their actual JavaScript ages. Source waves 0/0b are code prerequisites, not model production counts.

A 2D design sheet is the first stage of every NEW model in its assigned wave, followed immediately by modelling without an approval pause. This does not move all UI/emblem tasks to the front, and does not insert a retroactive concept-sheet stop before the parent validates the old 25.

## Wave 0: Validate the existing 25 records; no new model generation

- plans/art/buildings/naval_base — preserve `built_awaiting_validation_upload`; current parent validation result wins.
- plans/art/buildings/carrier_dock — preserve `built_awaiting_validation_upload`; current parent validation result wins.
- plans/art/buildings/road_post — preserve `built_awaiting_validation_upload`; current parent validation result wins.
- plans/art/buildings/highway — preserve `built_awaiting_validation_upload`; current parent validation result wins.
- plans/art/buildings/rail_depot — preserve `built_awaiting_validation_upload`; current parent validation result wins.
- plans/art/buildings/copper_mine — preserve `built_awaiting_validation_upload`; current parent validation result wins.
- plans/art/buildings/iron_foundry — preserve `built_awaiting_validation_upload`; current parent validation result wins.
- plans/art/improvements/ancient/farm — preserve `built_awaiting_validation_upload`; current parent validation result wins.
- plans/art/improvements/modern/farm — preserve `built_awaiting_validation_upload`; current parent validation result wins.
- plans/art/improvements/ancient/mine — preserve `built_awaiting_validation_upload`; current parent validation result wins.
- plans/art/improvements/modern/mine — preserve `built_awaiting_validation_upload`; current parent validation result wins.
- plans/art/improvements/ancient/fishing_boats — preserve `built_awaiting_validation_upload`; current parent validation result wins.
- plans/art/improvements/modern/fishing_boats — preserve `built_awaiting_validation_upload`; current parent validation result wins.
- plans/art/improvements/ancient/road — preserve `built_awaiting_validation_upload`; current parent validation result wins.
- plans/art/improvements/modern/road — preserve `built_awaiting_validation_upload`; current parent validation result wins.
- plans/art/improvements/ancient/pasture — preserve `built_awaiting_validation_upload`; current parent validation result wins.
- plans/art/improvements/ancient/camp — preserve `built_awaiting_validation_upload`; current parent validation result wins.
- plans/art/improvements/ancient/quarry — preserve `built_awaiting_validation_upload`; current parent validation result wins.
- plans/art/improvements/ancient/lumber_camp — preserve `built_awaiting_validation_upload`; current parent validation result wins.
- plans/art/improvements/ancient/plantation — preserve `built_awaiting_validation_upload`; current parent validation result wins.
- plans/art/towns/classical/town-big — preserve `built_awaiting_validation_upload`; current parent validation result wins.
- plans/art/buildings/cathedral — preserve `built_awaiting_validation_upload`; current parent validation result wins.
- plans/art/ships/warship-bronze — preserve `built_awaiting_validation_upload`; current parent validation result wins.
- plans/art/ships/warship-classical — preserve `built_awaiting_validation_upload`; current parent validation result wins.
- plans/art/ships/warship-kingdoms — preserve `built_awaiting_validation_upload`; current parent validation result wins.

## Wave 1: Bronze battle, shared rigs, Bronze signatures and core art

Production/retained rows: 108.

| Track | Rows |
|---|---|
| age-props | 1 |
| base-units | 6 |
| battle-buildings | 15 |
| battle-terrain | 3 |
| commanders-irregulars | 3 |
| effect-sheets | 7 |
| ground-materials | 8 |
| herds | 2 |
| house-damage | 13 |
| mount-rigs | 4 |
| projectiles | 1 |
| resource-nodes | 4 |
| ruin-libraries | 1 |
| shared-map-battle-forts | 1 |
| shared-unit-body | 1 |
| signature-units | 34 |
| vegetation | 3 |
| wall-kits | 1 |

All ids are listed in ALL-ITEMS.md and the canonical_checklist JSON.

## Wave 2: Map models, named town gaps, terrain, improvements and independents

Production/retained rows: 277.

| Track | Rows |
|---|---|
| improvement-theme-variants | 30 |
| independent-dressings | 12 |
| map-improvements | 41 |
| map-terrain-kits | 10 |
| named-town-gaps | 65 |
| retained-legacy | 103 |
| retained-map-theme | 6 |
| town-ground-meshes | 5 |
| tribal-camps | 5 |

All ids are listed in ALL-ITEMS.md and the canonical_checklist JSON.

## Wave 3: Classical battle and signatures

Production/retained rows: 83.

| Track | Rows |
|---|---|
| age-props | 1 |
| base-units | 6 |
| battle-buildings | 15 |
| battle-terrain | 1 |
| commanders-irregulars | 3 |
| house-damage | 13 |
| mount-rigs | 2 |
| projectiles | 1 |
| ruin-libraries | 1 |
| shared-map-battle-forts | 1 |
| signature-units | 38 |
| wall-kits | 1 |

All ids are listed in ALL-ITEMS.md and the canonical_checklist JSON.

## Wave 4: Kingdoms battle and signatures

Production/retained rows: 78.

| Track | Rows |
|---|---|
| age-props | 1 |
| base-units | 6 |
| battle-buildings | 15 |
| commanders-irregulars | 3 |
| house-damage | 13 |
| projectiles | 1 |
| ruin-libraries | 1 |
| shared-map-battle-forts | 1 |
| signature-units | 36 |
| wall-kits | 1 |

All ids are listed in ALL-ITEMS.md and the canonical_checklist JSON.

## Wave 5: Gunpowder battle and signatures

Production/retained rows: 74.

| Track | Rows |
|---|---|
| age-props | 1 |
| base-units | 6 |
| battle-buildings | 15 |
| commanders-irregulars | 3 |
| house-damage | 13 |
| projectiles | 1 |
| ruin-libraries | 1 |
| shared-map-battle-forts | 1 |
| signature-units | 32 |
| wall-kits | 1 |

All ids are listed in ALL-ITEMS.md and the canonical_checklist JSON.

## Wave 6: Modern battle and signatures

Production/retained rows: 57.

| Track | Rows |
|---|---|
| age-props | 1 |
| base-units | 7 |
| battle-buildings | 18 |
| battle-terrain | 1 |
| commanders-irregulars | 3 |
| house-damage | 13 |
| projectiles | 1 |
| ruin-libraries | 1 |
| shared-map-battle-forts | 1 |
| signature-units | 10 |
| wall-kits | 1 |

All ids are listed in ALL-ITEMS.md and the canonical_checklist JSON.

## Wave 7: Culture building skins, remaining destruction/vegetation/effects and ships

Production/retained rows: 355.

| Track | Rows |
|---|---|
| building-culture-skins | 300 |
| effect-sheets | 15 |
| palace-damage | 5 |
| ships | 14 |
| vegetation | 4 |
| wonder-ruins | 17 |

All ids are listed in ALL-ITEMS.md and the canonical_checklist JSON.

## Wave 8: Independent M01–M29 2D outputs and preserved old 2D scope

Production/retained rows: 426.

| Track | Rows |
|---|---|
| M01-M29-2d | 285 |
| legacy-overlay | 1 |
| retained-legacy | 140 |

All ids are listed in ALL-ITEMS.md and the canonical_checklist JSON.

