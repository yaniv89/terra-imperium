# Supplemental parent handoff

Use this supplemental draft for active scheduling; keep the previous draft as the immutable queue/history reconciliation. No repo, game code or plan files were changed. Evidence is integration tracked filenames at `76d72140fce57835f76532ec6e642675509ba03f`; no asset blobs were read or downloaded.

## Town checks resolved

| Required town outputs | Tracked | Missing |
|---|---:|---:|
| Original 444 coverage checks | 370 | 74 |
| Separately named 40 outputs | 30 | 10 |
| All 484 | 400 | 84 |

Of the 84 absent town targets, two (base Classical big a/b) have recorded built deliveries. They belong in validation/integration first. The other 82 are missing targets without recorded delivery evidence. Filename presence does not prove current-spec acceptance.

## Scheduling counts

| Evidence bucket | Canonical requirements |
|---|---:|
| Missing declared targets; no recorded uploaded/built evidence | 820 |
| Tracked artifacts, current acceptance unknown | 417 |
| Recorded uploaded deliveries, current acceptance unknown | 22 |
| Required scope with unresolved output/source binding | 312 |
| Existing built deliveries overlapping current requirements | 17 |
| Optional scope / unresolved variant matrix, outside required checklist | 12 |

The 820 missing-target requirements consist of 506 model/root requirements and 314 independent 2D jobs. They bind to 443 distinct 3D target paths and 314 2D target paths/prefixes (757 distinct bindings); several role roots share each RTS age bundle. Missing means absent from the declared integration target, not proof that no usable source or upload exists elsewhere. Existing-artifact acceptance verification totals 439 (417 tracked plus 22 recorded uploaded). The 312 binding checks include all 300 legitimate culture-role variants, six mount sources, one shared body, three town-kit components, Modern oil and one 2D job.

The required index has 1588 rows because it now includes the 444 resolved town checks alongside models, roots, 2D jobs and verification requirements. **It is not a remaining-model total.** The original 25 built records remain in a separate validation annex: 17 overlap current requirements and eight are history-only. Do not add the annex to the required count.

## Scope corrections

Removed 249 history-only rows from active scheduling while preserving their queue records. Removed 29 unsupported extra age-specific base improvements and all 30 invented age-expanded variant jobs. Five optional house roles and one legacy overlay are held separately, together with six named improvement-family decisions. No dropped Israelite unit jobs or duplicate M3D queue records are reintroduced.

Retained twelve base improvement requirements: ancient/Modern farm, mine and fishing pairs; shared pasture, camp, quarry, lumber camp and plantation; Modern-only oil. Five forts remain one shared map/battle job per explicitly required age. Roads remain nested pieces in the roads kit. `tileYields`/tech gates determine eligibility but do not prove separate art per age. Six farm/fishing variant families require an age/reuse matrix; wheat may reuse the base farm. Runtime forts unlock in Classical, while the art plan explicitly requests Bronze through Modern; preserve those five art variants and note the difference.

All 300 culture role/theme/age variants remain known required scope. File bindings are unresolved, not their inclusion. The seventeen wonder-ruin roots now bind to the seventeen tracked wonder GLBs; their root existence and acceptance need inspection by the parent.

## Files and additive integration

- `supplemental-active-queue.json`: required checklist, work buckets, exact waves, scope/matrix holds, exclusions, append candidates and original25 validation annex.
- `supplemental-town-presence.json` / `SUPPLEMENTAL-TOWNS.md`: every one of the 484 required filename checks.
- `SUPPLEMENTAL-ACTIVE-ITEMS.md`: every required canonical id with wave and evidence bucket.
- `supplemental-integration-filenames.json`: bounded tracked filename evidence and revision/hash.
- `supplemental-improvement-gates.json`: real unlock ages and the art-matrix limitation.
- `supplemental-counts.json` / `supplemental-verification.json`: counts and reconciliation checks.

Append candidates: **274** known missing entries not already queued, plus **307** binding-verification entries not already queued (including all300 culture variants). Preserve the verification entries as required scope; determine bindings before geometry. Re-read the live queue, append only noncolliding paths, and leave every original status/checkpoint/history item untouched. Already queued missing requirements are scheduled through canonical annotations, not appended again. Do not append the optional/matrix holds as age-specific production jobs.

All new geometry requires its 2D sheet first; continue automatically without approval stops. Verification work starts with existing artifacts. Original25 validation has no retroactive sheet stop. This handoff makes no geometry, production, upload or current-acceptance completion claim.
