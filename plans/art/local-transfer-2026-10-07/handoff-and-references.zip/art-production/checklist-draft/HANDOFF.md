# Parent handoff: additive checklist draft

The requested reconciliation is ready. No repo files, shared pipelines or remote branches were changed. Fort/oil geometry work was stopped. This directory contains proposed JSON and Markdown only.

Verified source accounting: **884 existing queue records preserved**, **534 M rows parsed = 293 independent 2D + 241 model rows remapped**, **150 signatures from JavaScript**, **11 dropped Israelite unit records linked to one newly appended Modern Merkava job**, and **25 old built records retained for wave0 validation**.

The proposal enumerates **1458 canonical production/history rows**, including **603 proposed additions**, plus **444 presence-only tier checks**. This is an exact count of this explicit proposal, NOT a claim that every proposed job is missing or that the plan's headline 564 is a reliable expanded total. Provisional scope/path assumptions are marked per row and explained in AMBIGUITIES.md. Three hundred culture-skin roots alone are explicit scope outside that headline.

## Files

- `proposed-additive-queue.json`: immutable base queue snapshot, append_items, canonical_checklist, non_destructive_annotations, coverage_verification_items, input hashes/revisions and counts.
- `ALL-ITEMS.md`: every canonical item and every presence-only tier explicitly listed with wave/type/state.
- `WAVES.md`: latest assigned wave order and the exact twenty-five validation records.
- `source-M01-M29-rows-and-remaps.json`: every M row, source line, type and current destination/supersession.
- `signature-roster-checklist.json`: every one of the 150 runtime people/model/age/role/rig/name entries.
- `production-spec-catalog.json`: bounded exact S1–S13 spec excerpts for formats/paths and acceptance.
- `counts-and-verification.json`: assertions and hand-checked tallies.
- `AMBIGUITIES.md`, `METHOD.md`: assumptions, parser policy and merge caveats.

## Apply additively

Re-read integration and art queues first because parent validation is active. Preserve all existing item objects, delivery statuses, completed checkpoint history and old counter scopes. Append only paths not already present. Attach canonical annotations separately; use their dispositions to suppress obsolete unit-kit/M3D duplicates from active scheduling without deleting historical rows. Keep related boat/ship/texture references distinct from assertions of identical final files.

Use canonical ids for scheduling, target_paths plus required_objects for delivery, and the parent's current status for acceptance. The proposed A batch labels group additions into twenty; the parent assigns final checkpoint ids against its current queue. Presence-only coverage rows are not appendable build tasks until a lightweight filename/manifest check establishes a gap.

Every pending new model requires its 2D design sheet before geometry and has `approval_stop:false`. Generate the sheet, then continue modelling automatically. Do not delay the parent's old25 validation for retroactive sheets. No claim of production/model completion is made here.

Final additive/coverage/status/Markdown checks all pass. The shared neutral-body task is explicit; shared code and VAT dependencies are listed separately in the JSON.
