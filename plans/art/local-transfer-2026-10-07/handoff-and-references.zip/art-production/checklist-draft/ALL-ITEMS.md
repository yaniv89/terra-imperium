# Exact reconciled item checklist — draft

Every production row below has a unique canonical id. Multi-root bundles are separate role jobs sharing a file, not an assertion that every row is a distinct GLB. Original queue records remain verbatim in proposed-additive-queue.json. Presence-only D10 tier rows follow separately; they are not added as new build jobs.

| Item | Type | Wave | Track | State | Sheet before new geometry | Original queue links |
|---|---|---|---|---|---|---|
| battle-city/bronze/americas/houses-damage | 3d | 1 | house-damage | pending | required, no approval stop | plans/art/battle-city/bronze/americas/houses-damage |
| battle-city/bronze/base/houses-damage | 3d | 1 | house-damage | pending | required, no approval stop | plans/art/battle-city/bronze/base/houses-damage |
| battle-city/bronze/eastafrica/houses-damage | 3d | 1 | house-damage | pending | required, no approval stop | plans/art/battle-city/bronze/eastafrica/houses-damage |
| battle-city/bronze/europe/houses-damage | 3d | 1 | house-damage | pending | required, no approval stop | plans/art/battle-city/bronze/europe/houses-damage |
| battle-city/bronze/indic/houses-damage | 3d | 1 | house-damage | pending | required, no approval stop | plans/art/battle-city/bronze/indic/houses-damage |
| battle-city/bronze/israelite/houses-damage | 3d | 1 | house-damage | pending | required, no approval stop | plans/art/battle-city/bronze/israelite/houses-damage |
| battle-city/bronze/levant/houses-damage | 3d | 1 | house-damage | pending | required, no approval stop | plans/art/battle-city/bronze/levant/houses-damage |
| battle-city/bronze/maghreb/houses-damage | 3d | 1 | house-damage | pending | required, no approval stop | plans/art/battle-city/bronze/maghreb/houses-damage |
| battle-city/bronze/monsoon/houses-damage | 3d | 1 | house-damage | pending | required, no approval stop | plans/art/battle-city/bronze/monsoon/houses-damage |
| battle-city/bronze/nile/houses-damage | 3d | 1 | house-damage | pending | required, no approval stop | plans/art/battle-city/bronze/nile/houses-damage |
| battle-city/bronze/ruin-library | 3d | 1 | ruin-libraries | pending | required, no approval stop | plans/art/battle-city/bronze/ruin-library |
| battle-city/bronze/sinic/houses-damage | 3d | 1 | house-damage | pending | required, no approval stop | plans/art/battle-city/bronze/sinic/houses-damage |
| battle-city/bronze/steppe/houses-damage | 3d | 1 | house-damage | pending | required, no approval stop | plans/art/battle-city/bronze/steppe/houses-damage |
| battle-city/bronze/wall-kit | 3d | 1 | wall-kits | pending | required, no approval stop | plans/art/battle-city/bronze/wall-kit |
| battle-city/bronze/westafrica/houses-damage | 3d | 1 | house-damage | pending | required, no approval stop | plans/art/battle-city/bronze/westafrica/houses-damage |
| battle-terrain/bridge-wood | 3d | 1 | battle-terrain | pending | required, no approval stop | plans/art/battle-terrain/bridge-wood |
| battle-terrain/ford | 3d | 1 | battle-terrain | pending | required, no approval stop | plans/art/battle-terrain/ford |
| battle-terrain/river-kit | 3d | 1 | battle-terrain | pending | required, no approval stop | plans/art/battle-terrain/river-kit |
| fort/bronze | 3d | 1 | shared-map-battle-forts | pending | required, no approval stop | plans/art/battle-city/bronze/fort; plans/art/improvements/bronze/fort-bronze |
| fx/dust-impact | 2d | 1 | effect-sheets | pending | legacy/2D | proposed addition |
| fx/dust-march | 2d | 1 | effect-sheets | pending | legacy/2D | proposed addition |
| fx/fire-large | 2d | 1 | effect-sheets | pending | legacy/2D | proposed addition |
| fx/fire-small | 2d | 1 | effect-sheets | pending | legacy/2D | proposed addition |
| fx/impact-sparks | 2d | 1 | effect-sheets | pending | legacy/2D | proposed addition |
| fx/smoke-heavy | 2d | 1 | effect-sheets | pending | legacy/2D | proposed addition |
| fx/smoke-light | 2d | 1 | effect-sheets | pending | legacy/2D | proposed addition |
| ground-materials/desert-sand | 2d | 1 | ground-materials | pending | legacy/2D | plans/art/map-terrain/ground-desert-sand |
| ground-materials/dry-soil | 2d | 1 | ground-materials | pending | legacy/2D | proposed addition |
| ground-materials/grass | 2d | 1 | ground-materials | pending | legacy/2D | plans/art/map-terrain/ground-grass |
| ground-materials/paving | 2d | 1 | ground-materials | pending | legacy/2D | plans/art/map-terrain/ground-paving |
| ground-materials/rock | 2d | 1 | ground-materials | pending | legacy/2D | plans/art/map-terrain/ground-rock |
| ground-materials/snow | 2d | 1 | ground-materials | pending | legacy/2D | plans/art/map-terrain/ground-snow-ice |
| ground-materials/steppe-grass | 2d | 1 | ground-materials | pending | legacy/2D | plans/art/map-terrain/ground-dry-steppe |
| ground-materials/wet-soil | 2d | 1 | ground-materials | pending | legacy/2D | plans/art/map-terrain/ground-wet-soil |
| nature/fish-shoal | 3d | 1 | resource-nodes | pending | required, no approval stop | plans/art/nature/fish-shoal |
| nature/gold-vein | 3d | 1 | resource-nodes | pending | required, no approval stop | plans/art/nature/gold-vein |
| nature/herd-cattle | 3d | 1 | herds | pending | required, no approval stop | plans/art/nature/herd-cattle |
| nature/herd-sheep-goat | 3d | 1 | herds | pending | required, no approval stop | plans/art/nature/herd-sheep-goat |
| nature/ore-outcrop | 3d | 1 | resource-nodes | pending | required, no approval stop | plans/art/nature/ore-outcrop |
| nature/stone-outcrop | 3d | 1 | resource-nodes | pending | required, no approval stop | plans/art/nature/stone-outcrop |
| nature/vegetation-desert | 3d | 1 | vegetation | pending | required, no approval stop | proposed addition |
| nature/vegetation-mediterranean | 3d | 1 | vegetation | pending | required, no approval stop | plans/art/nature/vegetation-mediterranean |
| nature/vegetation-temperate | 3d | 1 | vegetation | pending | required, no approval stop | plans/art/nature/vegetation-temperate |
| projectiles/bronze | 3d | 1 | projectiles | pending | required, no approval stop | proposed addition |
| props/bronze | 3d | 1 | age-props | pending | required, no approval stop | plans/art/props/loot-sack |
| rts/bronze/aid-post | 3d | 1 | battle-buildings | pending | required, no approval stop | plans/art/rts/bronze/aid-post |
| rts/bronze/barracks | 3d | 1 | battle-buildings | pending | required, no approval stop | plans/art/rts/bronze/barracks |
| rts/bronze/construction-set | 3d | 1 | battle-buildings | pending | required, no approval stop | plans/art/rts/bronze/construction-set |
| rts/bronze/expedition-camp | 3d | 1 | battle-buildings | pending | required, no approval stop | plans/art/rts/bronze/expedition-camp |
| rts/bronze/farm-plot | 3d | 1 | battle-buildings | pending | required, no approval stop | plans/art/rts/bronze/farm-plot |
| rts/bronze/food-depot | 3d | 1 | battle-buildings | pending | required, no approval stop | plans/art/rts/bronze/food-depot |
| rts/bronze/house | 3d | 1 | battle-buildings | pending | required, no approval stop | proposed addition |
| rts/bronze/materials-yard | 3d | 1 | battle-buildings | pending | required, no approval stop | plans/art/rts/bronze/materials-yard |
| rts/bronze/mine | 3d | 1 | battle-buildings | pending | required, no approval stop | plans/art/rts/bronze/mine |
| rts/bronze/range | 3d | 1 | battle-buildings | pending | required, no approval stop | plans/art/rts/bronze/range |
| rts/bronze/siege-workshop | 3d | 1 | battle-buildings | pending | required, no approval stop | plans/art/rts/bronze/siege-workshop |
| rts/bronze/stable | 3d | 1 | battle-buildings | pending | required, no approval stop | plans/art/rts/bronze/stable |
| rts/bronze/tower | 3d | 1 | battle-buildings | pending | required, no approval stop | plans/art/rts/bronze/tower |
| rts/bronze/town-hall | 3d | 1 | battle-buildings | pending | required, no approval stop | plans/art/rts/bronze/town-hall |
| rts/bronze/trade-post | 3d | 1 | battle-buildings | pending | required, no approval stop | plans/art/rts/bronze/trade-post |
| unit-rigs/chariot-heavy | 3d | 1 | mount-rigs | pending | required, no approval stop | proposed addition |
| unit-rigs/chariot-light | 3d | 1 | mount-rigs | pending | required, no approval stop | proposed addition |
| unit-rigs/horse | 3d | 1 | mount-rigs | pending | required, no approval stop | proposed addition |
| unit-rigs/ox | 3d | 1 | mount-rigs | pending | required, no approval stop | proposed addition |
| units/bronze-cavalry | 3d | 1 | base-units | pending | required, no approval stop | plans/art/units/bronze-cavalry |
| units/bronze-general | 3d | 1 | commanders-irregulars | pending | required, no approval stop | plans/art/units/bronze-general |
| units/bronze-infantry | 3d | 1 | base-units | pending | required, no approval stop | plans/art/units/bronze-infantry |
| units/bronze-mercenary | 3d | 1 | commanders-irregulars | pending | required, no approval stop | plans/art/units/bronze-mercenary |
| units/bronze-raider | 3d | 1 | commanders-irregulars | pending | required, no approval stop | plans/art/units/bronze-raider |
| units/bronze-ranged | 3d | 1 | base-units | pending | required, no approval stop | plans/art/units/bronze-ranged |
| units/bronze-siege | 3d | 1 | base-units | pending | required, no approval stop | plans/art/units/bronze-siege |
| units/bronze-support | 3d | 1 | base-units | pending | required, no approval stop | plans/art/units/bronze-support |
| units/bronze-worker | 3d | 1 | base-units | pending | required, no approval stop | plans/art/units/bronze-worker; plans/art/units/settler-bronze |
| units/signature/ahhiyawa | 3d | 1 | signature-units | pending | required, no approval stop | proposed addition |
| units/signature/akkad | 3d | 1 | signature-units | pending | required, no approval stop | proposed addition |
| units/signature/andronovo | 3d | 1 | signature-units | pending | required, no approval stop | proposed addition |
| units/signature/botai | 3d | 1 | signature-units | pending | required, no approval stop | proposed addition |
| units/signature/caral | 3d | 1 | signature-units | pending | required, no approval stop | proposed addition |
| units/signature/colchis | 3d | 1 | signature-units | pending | required, no approval stop | proposed addition |
| units/signature/cucuteni | 3d | 1 | signature-units | pending | required, no approval stop | proposed addition |
| units/signature/dilmun | 3d | 1 | signature-units | pending | required, no approval stop | proposed addition |
| units/signature/elam | 3d | 1 | signature-units | pending | required, no approval stop | proposed addition |
| units/signature/garamantes | 3d | 1 | signature-units | pending | required, no approval stop | proposed addition |
| units/signature/gojoseon | 3d | 1 | signature-units | pending | required, no approval stop | proposed addition |
| units/signature/kanesh | 3d | 1 | signature-units | pending | required, no approval stop | proposed addition |
| units/signature/keftiu | 3d | 1 | signature-units | pending | required, no approval stop | proposed addition |
| units/signature/kemet | 3d | 1 | signature-units | pending | required, no approval stop | proposed addition |
| units/signature/kerma | 3d | 1 | signature-units | pending | required, no approval stop | proposed addition |
| units/signature/kuru | 3d | 1 | signature-units | pending | required, no approval stop | proposed addition |
| units/signature/lapita | 3d | 1 | signature-units | pending | required, no approval stop | proposed addition |
| units/signature/libu | 3d | 1 | signature-units | pending | required, no approval stop | proposed addition |
| units/signature/magan | 3d | 1 | signature-units | pending | required, no approval stop | proposed addition |
| units/signature/mari | 3d | 1 | signature-units | pending | required, no approval stop | proposed addition |
| units/signature/meluhha | 3d | 1 | signature-units | pending | required, no approval stop | proposed addition |
| units/signature/oxus | 3d | 1 | signature-units | pending | required, no approval stop | proposed addition |
| units/signature/phrygia | 3d | 1 | signature-units | pending | required, no approval stop | proposed addition |
| units/signature/punt | 3d | 1 | signature-units | pending | required, no approval stop | proposed addition |
| units/signature/saurashtra | 3d | 1 | signature-units | pending | required, no approval stop | proposed addition |
| units/signature/shang | 3d | 1 | signature-units | pending | required, no approval stop | proposed addition |
| units/signature/shu | 3d | 1 | signature-units | pending | required, no approval stop | proposed addition |
| units/signature/tartessos | 3d | 1 | signature-units | pending | required, no approval stop | proposed addition |
| units/signature/tichitt | 3d | 1 | signature-units | pending | required, no approval stop | proposed addition |
| units/signature/ugarit | 3d | 1 | signature-units | pending | required, no approval stop | proposed addition |
| units/signature/urartu | 3d | 1 | signature-units | pending | required, no approval stop | proposed addition |
| units/signature/van-lang | 3d | 1 | signature-units | pending | required, no approval stop | proposed addition |
| units/signature/wahgi | 3d | 1 | signature-units | pending | required, no approval stop | proposed addition |
| units/signature/zhou | 3d | 1 | signature-units | pending | required, no approval stop | proposed addition |
| independents/early/fortress-dressing | 3d | 2 | independent-dressings | pending | required, no approval stop | plans/art/independents/early/fortress-dressing |
| independents/early/mercantile-dressing | 3d | 2 | independent-dressings | pending | required, no approval stop | plans/art/independents/early/mercantile-dressing |
| independents/early/raiders-dressing | 3d | 2 | independent-dressings | pending | required, no approval stop | plans/art/independents/early/raiders-dressing |
| independents/early/tribal-dressing | 3d | 2 | independent-dressings | pending | required, no approval stop | plans/art/independents/early/tribal-dressing |
| independents/middle/fortress-dressing | 3d | 2 | independent-dressings | pending | required, no approval stop | plans/art/independents/middle/fortress-dressing |
| independents/middle/mercantile-dressing | 3d | 2 | independent-dressings | pending | required, no approval stop | plans/art/independents/middle/mercantile-dressing |
| independents/middle/raiders-dressing | 3d | 2 | independent-dressings | pending | required, no approval stop | plans/art/independents/middle/raiders-dressing |
| independents/middle/tribal-dressing | 3d | 2 | independent-dressings | pending | required, no approval stop | plans/art/independents/middle/tribal-dressing |
| independents/modern/fortress-dressing | 3d | 2 | independent-dressings | pending | required, no approval stop | plans/art/independents/modern/fortress-dressing |
| independents/modern/mercantile-dressing | 3d | 2 | independent-dressings | pending | required, no approval stop | plans/art/independents/modern/mercantile-dressing |
| independents/modern/raiders-dressing | 3d | 2 | independent-dressings | pending | required, no approval stop | plans/art/independents/modern/raiders-dressing |
| independents/modern/tribal-dressing | 3d | 2 | independent-dressings | pending | required, no approval stop | plans/art/independents/modern/tribal-dressing |
| independents/tribal-camp-cold | 3d | 2 | tribal-camps | pending | required, no approval stop | plans/art/independents/tribal-camp-cold |
| independents/tribal-camp-desert | 3d | 2 | tribal-camps | pending | required, no approval stop | plans/art/independents/tribal-camp-desert |
| independents/tribal-camp-forest | 3d | 2 | tribal-camps | pending | required, no approval stop | plans/art/independents/tribal-camp-forest |
| independents/tribal-camp-steppe | 3d | 2 | tribal-camps | pending | required, no approval stop | plans/art/independents/tribal-camp-steppe |
| independents/tribal-camp-tropical | 3d | 2 | tribal-camps | pending | required, no approval stop | plans/art/independents/tribal-camp-tropical |
| legacy/buildings/bank | 3d | 2 | retained-legacy | historically_uploaded_quality_accepted | legacy/2D | plans/art/buildings/bank |
| legacy/buildings/barracks | 3d | 2 | retained-legacy | historically_uploaded_quality_accepted | legacy/2D | plans/art/buildings/barracks |
| legacy/buildings/barracks-israelite | 3d | 2 | retained-legacy | historically_uploaded_quality_accepted | legacy/2D | plans/art/buildings/barracks-israelite |
| legacy/buildings/bazaar | 3d | 2 | retained-legacy | historically_uploaded_quality_accepted | legacy/2D | plans/art/buildings/bazaar |
| legacy/buildings/carrier_dock | 3d | 2 | retained-legacy | built_awaiting_validation_upload | legacy/2D | plans/art/buildings/carrier_dock |
| legacy/buildings/cathedral | 3d | 2 | retained-legacy | built_awaiting_validation_upload | legacy/2D | plans/art/buildings/cathedral |
| legacy/buildings/civic_center | 3d | 2 | retained-legacy | historically_uploaded_quality_accepted | legacy/2D | plans/art/buildings/civic_center |
| legacy/buildings/copper_mine | 3d | 2 | retained-legacy | built_awaiting_validation_upload | legacy/2D | plans/art/buildings/copper_mine |
| legacy/buildings/copper_mine-israelite | 3d | 2 | retained-legacy | historically_uploaded_quality_accepted | legacy/2D | plans/art/buildings/copper_mine-israelite |
| legacy/buildings/crop_rotation_farm | 3d | 2 | retained-legacy | historically_uploaded_quality_accepted | legacy/2D | plans/art/buildings/crop_rotation_farm |
| legacy/buildings/drill_yard | 3d | 2 | retained-legacy | historically_uploaded_quality_accepted | legacy/2D | plans/art/buildings/drill_yard |
| legacy/buildings/factory | 3d | 2 | retained-legacy | historically_uploaded_quality_accepted | legacy/2D | plans/art/buildings/factory |
| legacy/buildings/farm_estate | 3d | 2 | retained-legacy | historically_uploaded_quality_accepted | legacy/2D | plans/art/buildings/farm_estate |
| legacy/buildings/granary | 3d | 2 | retained-legacy | historically_uploaded_quality_accepted | legacy/2D | plans/art/buildings/granary |
| legacy/buildings/granary-israelite | 3d | 2 | retained-legacy | historically_uploaded_quality_accepted | legacy/2D | plans/art/buildings/granary-israelite |
| legacy/buildings/harbor | 3d | 2 | retained-legacy | historically_uploaded_quality_accepted | legacy/2D | plans/art/buildings/harbor |
| legacy/buildings/harbor-israelite | 3d | 2 | retained-legacy | historically_uploaded_quality_accepted | legacy/2D | plans/art/buildings/harbor-israelite |
| legacy/buildings/highway | 3d | 2 | retained-legacy | built_awaiting_validation_upload | legacy/2D | plans/art/buildings/highway |
| legacy/buildings/iron_foundry | 3d | 2 | retained-legacy | built_awaiting_validation_upload | legacy/2D | plans/art/buildings/iron_foundry |
| legacy/buildings/irrigation | 3d | 2 | retained-legacy | historically_uploaded_quality_accepted | legacy/2D | plans/art/buildings/irrigation |
| legacy/buildings/irrigation-israelite | 3d | 2 | retained-legacy | historically_uploaded_quality_accepted | legacy/2D | plans/art/buildings/irrigation-israelite |
| legacy/buildings/library | 3d | 2 | retained-legacy | historically_uploaded_quality_accepted | legacy/2D | plans/art/buildings/library |
| legacy/buildings/library-israelite | 3d | 2 | retained-legacy | historically_uploaded_quality_accepted | legacy/2D | plans/art/buildings/library-israelite |
| legacy/buildings/manufactory | 3d | 2 | retained-legacy | historically_uploaded_quality_accepted | legacy/2D | plans/art/buildings/manufactory |
| legacy/buildings/market | 3d | 2 | retained-legacy | historically_uploaded_quality_accepted | legacy/2D | plans/art/buildings/market |
| legacy/buildings/market-israelite | 3d | 2 | retained-legacy | historically_uploaded_quality_accepted | legacy/2D | plans/art/buildings/market-israelite |
| legacy/buildings/mechanized_farm | 3d | 2 | retained-legacy | historically_uploaded_quality_accepted | legacy/2D | plans/art/buildings/mechanized_farm |
| legacy/buildings/military_academy | 3d | 2 | retained-legacy | historically_uploaded_quality_accepted | legacy/2D | plans/art/buildings/military_academy |
| legacy/buildings/naval_base | 3d | 2 | retained-legacy | built_awaiting_validation_upload | legacy/2D | plans/art/buildings/naval_base |
| legacy/buildings/oil_well | 3d | 2 | retained-legacy | pending | required, no approval stop | plans/art/buildings/oil_well |
| legacy/buildings/rail_depot | 3d | 2 | retained-legacy | built_awaiting_validation_upload | legacy/2D | plans/art/buildings/rail_depot |
| legacy/buildings/research_lab | 3d | 2 | retained-legacy | historically_uploaded_quality_accepted | legacy/2D | plans/art/buildings/research_lab |
| legacy/buildings/road_post | 3d | 2 | retained-legacy | built_awaiting_validation_upload | legacy/2D | plans/art/buildings/road_post |
| legacy/buildings/scriptorium | 3d | 2 | retained-legacy | historically_uploaded_quality_accepted | legacy/2D | plans/art/buildings/scriptorium |
| legacy/buildings/scriptorium-israelite | 3d | 2 | retained-legacy | historically_uploaded_quality_accepted | legacy/2D | plans/art/buildings/scriptorium-israelite |
| legacy/buildings/shipyard | 3d | 2 | retained-legacy | historically_uploaded_quality_accepted | legacy/2D | plans/art/buildings/shipyard |
| legacy/buildings/shrine | 3d | 2 | retained-legacy | historically_uploaded_quality_accepted | legacy/2D | plans/art/buildings/shrine |
| legacy/buildings/shrine-israelite | 3d | 2 | retained-legacy | historically_uploaded_quality_accepted | legacy/2D | plans/art/buildings/shrine-israelite |
| legacy/buildings/stock_exchange | 3d | 2 | retained-legacy | historically_uploaded_quality_accepted | legacy/2D | plans/art/buildings/stock_exchange |
| legacy/buildings/temple | 3d | 2 | retained-legacy | historically_uploaded_quality_accepted | legacy/2D | plans/art/buildings/temple |
| legacy/buildings/university | 3d | 2 | retained-legacy | historically_uploaded_quality_accepted | legacy/2D | plans/art/buildings/university |
| legacy/buildings/war_college | 3d | 2 | retained-legacy | historically_uploaded_quality_accepted | legacy/2D | plans/art/buildings/war_college |
| legacy/buildings/workshop | 3d | 2 | retained-legacy | historically_uploaded_quality_accepted | legacy/2D | plans/art/buildings/workshop |
| legacy/buildings/workshop-israelite | 3d | 2 | retained-legacy | historically_uploaded_quality_accepted | legacy/2D | plans/art/buildings/workshop-israelite |
| legacy/improvements/ancient/farm-israelite | 3d | 2 | retained-map-theme | historically_uploaded_quality_accepted | legacy/2D | plans/art/improvements/ancient/farm-israelite |
| legacy/improvements/ancient/fishing_boats-israelite | 3d | 2 | retained-map-theme | historically_uploaded_quality_accepted | legacy/2D | plans/art/improvements/ancient/fishing_boats-israelite |
| legacy/improvements/ancient/pasture-israelite | 3d | 2 | retained-map-theme | historically_uploaded_quality_accepted | legacy/2D | plans/art/improvements/ancient/pasture-israelite |
| legacy/improvements/ancient/plantation-israelite | 3d | 2 | retained-map-theme | historically_uploaded_quality_accepted | legacy/2D | plans/art/improvements/ancient/plantation-israelite |
| legacy/improvements/bronze/fort-bronze-israelite | 3d | 2 | retained-map-theme | historically_uploaded_quality_accepted | legacy/2D | plans/art/improvements/bronze/fort-bronze-israelite |
| legacy/improvements/modern/fort-modern-israelite | 3d | 2 | retained-map-theme | historically_uploaded_quality_accepted | legacy/2D | plans/art/improvements/modern/fort-modern-israelite |
| legacy/kits/israelite/bronze/houses | 3d | 2 | retained-legacy | historically_uploaded_quality_accepted | legacy/2D | plans/art/kits/israelite/bronze/houses |
| legacy/kits/israelite/bronze/landmark-1 | 3d | 2 | retained-legacy | historically_uploaded_quality_accepted | legacy/2D | plans/art/kits/israelite/bronze/landmark-1 |
| legacy/kits/israelite/bronze/landmark-2 | 3d | 2 | retained-legacy | historically_uploaded_quality_accepted | legacy/2D | plans/art/kits/israelite/bronze/landmark-2 |
| legacy/kits/israelite/bronze/roofscape | 3d | 2 | retained-legacy | historically_uploaded_quality_accepted | legacy/2D | plans/art/kits/israelite/bronze/roofscape |
| legacy/kits/israelite/bronze/street | 3d | 2 | retained-legacy | historically_uploaded_quality_accepted | legacy/2D | plans/art/kits/israelite/bronze/street |
| legacy/kits/israelite/classical/houses | 3d | 2 | retained-legacy | historically_uploaded_quality_accepted | legacy/2D | plans/art/kits/israelite/classical/houses |
| legacy/kits/israelite/classical/landmark-1 | 3d | 2 | retained-legacy | historically_uploaded_quality_accepted | legacy/2D | plans/art/kits/israelite/classical/landmark-1 |
| legacy/kits/israelite/classical/landmark-2 | 3d | 2 | retained-legacy | historically_uploaded_quality_accepted | legacy/2D | plans/art/kits/israelite/classical/landmark-2 |
| legacy/kits/israelite/classical/roofscape | 3d | 2 | retained-legacy | historically_uploaded_quality_accepted | legacy/2D | plans/art/kits/israelite/classical/roofscape |
| legacy/kits/israelite/classical/street | 3d | 2 | retained-legacy | historically_uploaded_quality_accepted | legacy/2D | plans/art/kits/israelite/classical/street |
| legacy/kits/israelite/gunpowder/houses | 3d | 2 | retained-legacy | historically_uploaded_quality_accepted | legacy/2D | plans/art/kits/israelite/gunpowder/houses |
| legacy/kits/israelite/gunpowder/landmark-1 | 3d | 2 | retained-legacy | historically_uploaded_quality_accepted | legacy/2D | plans/art/kits/israelite/gunpowder/landmark-1 |
| legacy/kits/israelite/gunpowder/landmark-2 | 3d | 2 | retained-legacy | historically_uploaded_quality_accepted | legacy/2D | plans/art/kits/israelite/gunpowder/landmark-2 |
| legacy/kits/israelite/gunpowder/roofscape | 3d | 2 | retained-legacy | historically_uploaded_quality_accepted | legacy/2D | plans/art/kits/israelite/gunpowder/roofscape |
| legacy/kits/israelite/gunpowder/street | 3d | 2 | retained-legacy | historically_uploaded_quality_accepted | legacy/2D | plans/art/kits/israelite/gunpowder/street |
| legacy/kits/israelite/kingdoms/houses | 3d | 2 | retained-legacy | historically_uploaded_quality_accepted | legacy/2D | plans/art/kits/israelite/kingdoms/houses |
| legacy/kits/israelite/kingdoms/landmark-1 | 3d | 2 | retained-legacy | historically_uploaded_quality_accepted | legacy/2D | plans/art/kits/israelite/kingdoms/landmark-1 |
| legacy/kits/israelite/kingdoms/landmark-2 | 3d | 2 | retained-legacy | historically_uploaded_quality_accepted | legacy/2D | plans/art/kits/israelite/kingdoms/landmark-2 |
| legacy/kits/israelite/kingdoms/roofscape | 3d | 2 | retained-legacy | historically_uploaded_quality_accepted | legacy/2D | plans/art/kits/israelite/kingdoms/roofscape |
| legacy/kits/israelite/kingdoms/street | 3d | 2 | retained-legacy | historically_uploaded_quality_accepted | legacy/2D | plans/art/kits/israelite/kingdoms/street |
| legacy/kits/israelite/modern/houses | 3d | 2 | retained-legacy | historically_uploaded_quality_accepted | legacy/2D | plans/art/kits/israelite/modern/houses |
| legacy/kits/israelite/modern/landmark-1 | 3d | 2 | retained-legacy | historically_uploaded_quality_accepted | legacy/2D | plans/art/kits/israelite/modern/landmark-1 |
| legacy/kits/israelite/modern/landmark-2 | 3d | 2 | retained-legacy | historically_uploaded_quality_accepted | legacy/2D | plans/art/kits/israelite/modern/landmark-2 |
| legacy/kits/israelite/modern/roofscape | 3d | 2 | retained-legacy | historically_uploaded_quality_accepted | legacy/2D | plans/art/kits/israelite/modern/roofscape |
| legacy/kits/israelite/modern/street | 3d | 2 | retained-legacy | historically_uploaded_quality_accepted | legacy/2D | plans/art/kits/israelite/modern/street |
| legacy/towns/bronze/colony-camp-israelite | 3d | 2 | retained-legacy | historically_uploaded_quality_accepted | legacy/2D | plans/art/towns/bronze/colony-camp-israelite |
| legacy/towns/bronze/field-1-israelite | 3d | 2 | retained-legacy | historically_uploaded_quality_accepted | legacy/2D | plans/art/towns/bronze/field-1-israelite |
| legacy/towns/bronze/field-2-israelite | 3d | 2 | retained-legacy | historically_uploaded_quality_accepted | legacy/2D | plans/art/towns/bronze/field-2-israelite |
| legacy/towns/bronze/field-3-israelite | 3d | 2 | retained-legacy | historically_uploaded_quality_accepted | legacy/2D | plans/art/towns/bronze/field-3-israelite |
| legacy/towns/bronze/field-4-israelite | 3d | 2 | retained-legacy | historically_uploaded_quality_accepted | legacy/2D | plans/art/towns/bronze/field-4-israelite |
| legacy/towns/bronze/palace-israelite | 3d | 2 | retained-legacy | historically_uploaded_quality_accepted | legacy/2D | plans/art/towns/bronze/palace-israelite |
| legacy/towns/bronze/palace-small-israelite | 3d | 2 | retained-legacy | historically_uploaded_quality_accepted | legacy/2D | plans/art/towns/bronze/palace-small-israelite |
| legacy/towns/bronze/walls-medium-israelite | 3d | 2 | retained-legacy | historically_uploaded_quality_accepted | legacy/2D | plans/art/towns/bronze/walls-medium-israelite |
| legacy/towns/classical/palace | 3d | 2 | retained-legacy | historically_uploaded_quality_accepted | legacy/2D | plans/art/towns/classical/palace |
| legacy/towns/classical/palace-israelite | 3d | 2 | retained-legacy | historically_uploaded_quality_accepted | legacy/2D | plans/art/towns/classical/palace-israelite |
| legacy/towns/classical/palace-small | 3d | 2 | retained-legacy | historically_uploaded_quality_accepted | legacy/2D | plans/art/towns/classical/palace-small |
| legacy/towns/classical/palace-small-israelite | 3d | 2 | retained-legacy | historically_uploaded_quality_accepted | legacy/2D | plans/art/towns/classical/palace-small-israelite |
| legacy/towns/classical/walls-medium-israelite | 3d | 2 | retained-legacy | historically_uploaded_quality_accepted | legacy/2D | plans/art/towns/classical/walls-medium-israelite |
| legacy/towns/gunpowder/walls-medium-israelite | 3d | 2 | retained-legacy | historically_uploaded_quality_accepted | legacy/2D | plans/art/towns/gunpowder/walls-medium-israelite |
| legacy/towns/kingdoms/palace-israelite | 3d | 2 | retained-legacy | historically_uploaded_quality_accepted | legacy/2D | plans/art/towns/kingdoms/palace-israelite |
| legacy/towns/kingdoms/palace-small-israelite | 3d | 2 | retained-legacy | historically_uploaded_quality_accepted | legacy/2D | plans/art/towns/kingdoms/palace-small-israelite |
| legacy/towns/modern/colony-camp-israelite | 3d | 2 | retained-legacy | historically_uploaded_quality_accepted | legacy/2D | plans/art/towns/modern/colony-camp-israelite |
| legacy/wonders/arsenal | 3d | 2 | retained-legacy | historically_uploaded_quality_accepted | legacy/2D | plans/art/wonders/arsenal |
| legacy/wonders/atomic_research_center | 3d | 2 | retained-legacy | historically_uploaded_quality_accepted | legacy/2D | plans/art/wonders/atomic_research_center |
| legacy/wonders/colosseum | 3d | 2 | retained-legacy | historically_uploaded_quality_accepted | legacy/2D | plans/art/wonders/colosseum |
| legacy/wonders/forbidden_city | 3d | 2 | retained-legacy | historically_uploaded_quality_accepted | legacy/2D | plans/art/wonders/forbidden_city |
| legacy/wonders/grand_bazaar | 3d | 2 | retained-legacy | historically_uploaded_quality_accepted | legacy/2D | plans/art/wonders/grand_bazaar |
| legacy/wonders/great_cathedral | 3d | 2 | retained-legacy | historically_uploaded_quality_accepted | legacy/2D | plans/art/wonders/great_cathedral |
| legacy/wonders/great_library | 3d | 2 | retained-legacy | historically_uploaded_quality_accepted | legacy/2D | plans/art/wonders/great_library |
| legacy/wonders/great_pyramids | 3d | 2 | retained-legacy | historically_uploaded_quality_accepted | legacy/2D | plans/art/wonders/great_pyramids |
| legacy/wonders/great_wall | 3d | 2 | retained-legacy | historically_uploaded_quality_accepted | legacy/2D | plans/art/wonders/great_wall |
| legacy/wonders/hanging_gardens | 3d | 2 | retained-legacy | historically_uploaded_quality_accepted | legacy/2D | plans/art/wonders/hanging_gardens |
| legacy/wonders/international_exchange | 3d | 2 | retained-legacy | historically_uploaded_quality_accepted | legacy/2D | plans/art/wonders/international_exchange |
| legacy/wonders/lighthouse | 3d | 2 | retained-legacy | historically_uploaded_quality_accepted | legacy/2D | plans/art/wonders/lighthouse |
| legacy/wonders/masada | 3d | 2 | retained-legacy | historically_uploaded_quality_accepted | legacy/2D | plans/art/wonders/masada |
| legacy/wonders/palace_of_versailles | 3d | 2 | retained-legacy | historically_uploaded_quality_accepted | legacy/2D | plans/art/wonders/palace_of_versailles |
| legacy/wonders/royal_observatory | 3d | 2 | retained-legacy | historically_uploaded_quality_accepted | legacy/2D | plans/art/wonders/royal_observatory |
| legacy/wonders/solomons_temple | 3d | 2 | retained-legacy | historically_uploaded_quality_accepted | legacy/2D | plans/art/wonders/solomons_temple |
| legacy/wonders/space_program | 3d | 2 | retained-legacy | historically_uploaded_quality_accepted | legacy/2D | plans/art/wonders/space_program |
| map-improvements/bronze/camp | 3d | 2 | map-improvements | built_awaiting_validation_upload | legacy/2D | plans/art/improvements/ancient/camp |
| map-improvements/bronze/farm | 3d | 2 | map-improvements | built_awaiting_validation_upload | legacy/2D | plans/art/improvements/ancient/farm |
| map-improvements/bronze/farm-maize | 3d | 2 | improvement-theme-variants | pending | required, no approval stop | proposed addition |
| map-improvements/bronze/farm-paddy | 3d | 2 | improvement-theme-variants | pending | required, no approval stop | proposed addition |
| map-improvements/bronze/farm-wheat | 3d | 2 | improvement-theme-variants | pending | required, no approval stop | proposed addition |
| map-improvements/bronze/fishing-boats | 3d | 2 | map-improvements | built_awaiting_validation_upload | legacy/2D | plans/art/improvements/ancient/fishing_boats; plans/art/units/fishing-boat-ancient |
| map-improvements/bronze/fishing-boats-dhow | 3d | 2 | improvement-theme-variants | pending | required, no approval stop | proposed addition |
| map-improvements/bronze/fishing-boats-junk | 3d | 2 | improvement-theme-variants | pending | required, no approval stop | proposed addition |
| map-improvements/bronze/fishing-boats-outrigger | 3d | 2 | improvement-theme-variants | pending | required, no approval stop | proposed addition |
| map-improvements/bronze/lumber-camp | 3d | 2 | map-improvements | built_awaiting_validation_upload | legacy/2D | plans/art/improvements/ancient/lumber_camp |
| map-improvements/bronze/mine | 3d | 2 | map-improvements | built_awaiting_validation_upload | legacy/2D | plans/art/improvements/ancient/mine |
| map-improvements/bronze/pasture | 3d | 2 | map-improvements | built_awaiting_validation_upload | legacy/2D | plans/art/improvements/ancient/pasture |
| map-improvements/bronze/plantation | 3d | 2 | map-improvements | built_awaiting_validation_upload | legacy/2D | plans/art/improvements/ancient/plantation |
| map-improvements/bronze/quarry | 3d | 2 | map-improvements | built_awaiting_validation_upload | legacy/2D | plans/art/improvements/ancient/quarry |
| map-improvements/classical/camp | 3d | 2 | map-improvements | pending | required, no approval stop | proposed addition |
| map-improvements/classical/farm | 3d | 2 | map-improvements | pending | required, no approval stop | proposed addition |
| map-improvements/classical/farm-maize | 3d | 2 | improvement-theme-variants | pending | required, no approval stop | proposed addition |
| map-improvements/classical/farm-paddy | 3d | 2 | improvement-theme-variants | pending | required, no approval stop | proposed addition |
| map-improvements/classical/farm-wheat | 3d | 2 | improvement-theme-variants | pending | required, no approval stop | proposed addition |
| map-improvements/classical/fishing-boats | 3d | 2 | map-improvements | pending | required, no approval stop | proposed addition |
| map-improvements/classical/fishing-boats-dhow | 3d | 2 | improvement-theme-variants | pending | required, no approval stop | proposed addition |
| map-improvements/classical/fishing-boats-junk | 3d | 2 | improvement-theme-variants | pending | required, no approval stop | proposed addition |
| map-improvements/classical/fishing-boats-outrigger | 3d | 2 | improvement-theme-variants | pending | required, no approval stop | proposed addition |
| map-improvements/classical/lumber-camp | 3d | 2 | map-improvements | pending | required, no approval stop | proposed addition |
| map-improvements/classical/mine | 3d | 2 | map-improvements | pending | required, no approval stop | proposed addition |
| map-improvements/classical/pasture | 3d | 2 | map-improvements | pending | required, no approval stop | proposed addition |
| map-improvements/classical/plantation | 3d | 2 | map-improvements | pending | required, no approval stop | proposed addition |
| map-improvements/classical/quarry | 3d | 2 | map-improvements | pending | required, no approval stop | proposed addition |
| map-improvements/gunpowder/camp | 3d | 2 | map-improvements | pending | required, no approval stop | proposed addition |
| map-improvements/gunpowder/farm | 3d | 2 | map-improvements | pending | required, no approval stop | proposed addition |
| map-improvements/gunpowder/farm-maize | 3d | 2 | improvement-theme-variants | pending | required, no approval stop | proposed addition |
| map-improvements/gunpowder/farm-paddy | 3d | 2 | improvement-theme-variants | pending | required, no approval stop | proposed addition |
| map-improvements/gunpowder/farm-wheat | 3d | 2 | improvement-theme-variants | pending | required, no approval stop | proposed addition |
| map-improvements/gunpowder/fishing-boats | 3d | 2 | map-improvements | pending | required, no approval stop | proposed addition |
| map-improvements/gunpowder/fishing-boats-dhow | 3d | 2 | improvement-theme-variants | pending | required, no approval stop | proposed addition |
| map-improvements/gunpowder/fishing-boats-junk | 3d | 2 | improvement-theme-variants | pending | required, no approval stop | proposed addition |
| map-improvements/gunpowder/fishing-boats-outrigger | 3d | 2 | improvement-theme-variants | pending | required, no approval stop | proposed addition |
| map-improvements/gunpowder/lumber-camp | 3d | 2 | map-improvements | pending | required, no approval stop | proposed addition |
| map-improvements/gunpowder/mine | 3d | 2 | map-improvements | pending | required, no approval stop | proposed addition |
| map-improvements/gunpowder/pasture | 3d | 2 | map-improvements | pending | required, no approval stop | proposed addition |
| map-improvements/gunpowder/plantation | 3d | 2 | map-improvements | pending | required, no approval stop | proposed addition |
| map-improvements/gunpowder/quarry | 3d | 2 | map-improvements | pending | required, no approval stop | proposed addition |
| map-improvements/kingdoms/camp | 3d | 2 | map-improvements | pending | required, no approval stop | proposed addition |
| map-improvements/kingdoms/farm | 3d | 2 | map-improvements | pending | required, no approval stop | proposed addition |
| map-improvements/kingdoms/farm-maize | 3d | 2 | improvement-theme-variants | pending | required, no approval stop | proposed addition |
| map-improvements/kingdoms/farm-paddy | 3d | 2 | improvement-theme-variants | pending | required, no approval stop | proposed addition |
| map-improvements/kingdoms/farm-wheat | 3d | 2 | improvement-theme-variants | pending | required, no approval stop | proposed addition |
| map-improvements/kingdoms/fishing-boats | 3d | 2 | map-improvements | pending | required, no approval stop | proposed addition |
| map-improvements/kingdoms/fishing-boats-dhow | 3d | 2 | improvement-theme-variants | pending | required, no approval stop | proposed addition |
| map-improvements/kingdoms/fishing-boats-junk | 3d | 2 | improvement-theme-variants | pending | required, no approval stop | proposed addition |
| map-improvements/kingdoms/fishing-boats-outrigger | 3d | 2 | improvement-theme-variants | pending | required, no approval stop | proposed addition |
| map-improvements/kingdoms/lumber-camp | 3d | 2 | map-improvements | pending | required, no approval stop | proposed addition |
| map-improvements/kingdoms/mine | 3d | 2 | map-improvements | pending | required, no approval stop | proposed addition |
| map-improvements/kingdoms/pasture | 3d | 2 | map-improvements | pending | required, no approval stop | proposed addition |
| map-improvements/kingdoms/plantation | 3d | 2 | map-improvements | pending | required, no approval stop | proposed addition |
| map-improvements/kingdoms/quarry | 3d | 2 | map-improvements | pending | required, no approval stop | proposed addition |
| map-improvements/modern/camp | 3d | 2 | map-improvements | pending | required, no approval stop | proposed addition |
| map-improvements/modern/farm | 3d | 2 | map-improvements | built_awaiting_validation_upload | legacy/2D | plans/art/improvements/modern/farm |
| map-improvements/modern/farm-maize | 3d | 2 | improvement-theme-variants | pending | required, no approval stop | proposed addition |
| map-improvements/modern/farm-paddy | 3d | 2 | improvement-theme-variants | pending | required, no approval stop | proposed addition |
| map-improvements/modern/farm-wheat | 3d | 2 | improvement-theme-variants | pending | required, no approval stop | proposed addition |
| map-improvements/modern/fishing-boats | 3d | 2 | map-improvements | built_awaiting_validation_upload | legacy/2D | plans/art/improvements/modern/fishing_boats; plans/art/units/fishing-boat-modern |
| map-improvements/modern/fishing-boats-dhow | 3d | 2 | improvement-theme-variants | pending | required, no approval stop | proposed addition |
| map-improvements/modern/fishing-boats-junk | 3d | 2 | improvement-theme-variants | pending | required, no approval stop | proposed addition |
| map-improvements/modern/fishing-boats-outrigger | 3d | 2 | improvement-theme-variants | pending | required, no approval stop | proposed addition |
| map-improvements/modern/lumber-camp | 3d | 2 | map-improvements | pending | required, no approval stop | proposed addition |
| map-improvements/modern/mine | 3d | 2 | map-improvements | built_awaiting_validation_upload | legacy/2D | plans/art/improvements/modern/mine |
| map-improvements/modern/oil-well | 3d | 2 | map-improvements | pending | required, no approval stop | plans/art/improvements/ancient/oil_well |
| map-improvements/modern/pasture | 3d | 2 | map-improvements | pending | required, no approval stop | proposed addition |
| map-improvements/modern/plantation | 3d | 2 | map-improvements | pending | required, no approval stop | proposed addition |
| map-improvements/modern/quarry | 3d | 2 | map-improvements | pending | required, no approval stop | proposed addition |
| map-kits/europe/modern/houses | 3d | 2 | named-town-gaps | historically_uploaded_quality_accepted | legacy/2D | plans/art/kits/europe/modern/houses |
| map-kits/europe/modern/landmark-1 | 3d | 2 | named-town-gaps | historically_uploaded_quality_accepted | legacy/2D | plans/art/kits/europe/modern/landmark-1 |
| map-kits/europe/modern/landmark-2 | 3d | 2 | named-town-gaps | historically_uploaded_quality_accepted | legacy/2D | plans/art/kits/europe/modern/landmark-2 |
| map-kits/europe/modern/roofscape | 3d | 2 | named-town-gaps | historically_uploaded_quality_accepted | legacy/2D | plans/art/kits/europe/modern/roofscape |
| map-kits/europe/modern/street | 3d | 2 | named-town-gaps | historically_uploaded_quality_accepted | legacy/2D | plans/art/kits/europe/modern/street |
| map-kits/indic/gunpowder/houses | 3d | 2 | named-town-gaps | historically_uploaded_quality_accepted | legacy/2D | plans/art/kits/indic/gunpowder/houses |
| map-kits/indic/gunpowder/landmark-1 | 3d | 2 | named-town-gaps | historically_uploaded_quality_accepted | legacy/2D | plans/art/kits/indic/gunpowder/landmark-1 |
| map-kits/indic/gunpowder/landmark-2 | 3d | 2 | named-town-gaps | historically_uploaded_quality_accepted | legacy/2D | plans/art/kits/indic/gunpowder/landmark-2 |
| map-kits/indic/gunpowder/roofscape | 3d | 2 | named-town-gaps | historically_uploaded_quality_accepted | legacy/2D | plans/art/kits/indic/gunpowder/roofscape |
| map-kits/indic/gunpowder/street | 3d | 2 | named-town-gaps | historically_uploaded_quality_accepted | legacy/2D | plans/art/kits/indic/gunpowder/street |
| map-kits/indic/modern/houses | 3d | 2 | named-town-gaps | historically_uploaded_quality_accepted | legacy/2D | plans/art/kits/indic/modern/houses |
| map-kits/indic/modern/landmark-1 | 3d | 2 | named-town-gaps | historically_uploaded_quality_accepted | legacy/2D | plans/art/kits/indic/modern/landmark-1 |
| map-kits/indic/modern/landmark-2 | 3d | 2 | named-town-gaps | historically_uploaded_quality_accepted | legacy/2D | plans/art/kits/indic/modern/landmark-2 |
| map-kits/indic/modern/roofscape | 3d | 2 | named-town-gaps | historically_uploaded_quality_accepted | legacy/2D | plans/art/kits/indic/modern/roofscape |
| map-kits/indic/modern/street | 3d | 2 | named-town-gaps | historically_uploaded_quality_accepted | legacy/2D | plans/art/kits/indic/modern/street |
| map-kits/levant/bronze/houses | 3d | 2 | named-town-gaps | historically_uploaded_quality_accepted | legacy/2D | plans/art/kits/levant/bronze/houses |
| map-kits/levant/bronze/landmark-1 | 3d | 2 | named-town-gaps | historically_uploaded_quality_accepted | legacy/2D | plans/art/kits/levant/bronze/landmark-1 |
| map-kits/levant/bronze/landmark-2 | 3d | 2 | named-town-gaps | historically_uploaded_quality_accepted | legacy/2D | plans/art/kits/levant/bronze/landmark-2 |
| map-kits/levant/bronze/roofscape | 3d | 2 | named-town-gaps | historically_uploaded_quality_accepted | legacy/2D | plans/art/kits/levant/bronze/roofscape |
| map-kits/levant/bronze/street | 3d | 2 | named-town-gaps | historically_uploaded_quality_accepted | legacy/2D | plans/art/kits/levant/bronze/street |
| map-kits/steppe/modern/houses | 3d | 2 | named-town-gaps | pending | required, no approval stop | plans/art/kits/steppe/modern/houses |
| map-kits/steppe/modern/landmark-1 | 3d | 2 | named-town-gaps | historically_uploaded_quality_accepted | legacy/2D | plans/art/kits/steppe/modern/landmark-1 |
| map-kits/steppe/modern/landmark-2 | 3d | 2 | named-town-gaps | historically_uploaded_quality_accepted | legacy/2D | plans/art/kits/steppe/modern/landmark-2 |
| map-kits/steppe/modern/roofscape | 3d | 2 | named-town-gaps | pending | required, no approval stop | plans/art/kits/steppe/modern/roofscape |
| map-kits/steppe/modern/street | 3d | 2 | named-town-gaps | pending | required, no approval stop | plans/art/kits/steppe/modern/street |
| map-terrain/cliffs | 3d | 2 | map-terrain-kits | pending | required, no approval stop | plans/art/map-terrain/cliffs |
| map-terrain/coasts | 3d | 2 | map-terrain-kits | pending | required, no approval stop | plans/art/map-terrain/coasts |
| map-terrain/dunes | 3d | 2 | map-terrain-kits | pending | required, no approval stop | plans/art/map-terrain/dunes |
| map-terrain/field-edges | 3d | 2 | map-terrain-kits | pending | required, no approval stop | plans/art/map-terrain/field-edges |
| map-terrain/hills | 3d | 2 | map-terrain-kits | pending | required, no approval stop | plans/art/map-terrain/hills |
| map-terrain/lakes | 3d | 2 | map-terrain-kits | pending | required, no approval stop | plans/art/map-terrain/lakes |
| map-terrain/mountain-ridges | 3d | 2 | map-terrain-kits | pending | required, no approval stop | plans/art/map-terrain/mountain-ridges |
| map-terrain/roads | 3d | 2 | map-terrain-kits | built_awaiting_validation_upload | legacy/2D | plans/art/improvements/ancient/road; plans/art/improvements/modern/road; plans/art/map-terrain/roads |
| map-terrain/shore-harbour | 3d | 2 | map-terrain-kits | pending | required, no approval stop | plans/art/map-terrain/shore-harbour |
| map-terrain/town-ground-bronze | 3d | 2 | town-ground-meshes | pending | required, no approval stop | proposed addition |
| map-terrain/town-ground-classical | 3d | 2 | town-ground-meshes | pending | required, no approval stop | proposed addition |
| map-terrain/town-ground-gunpowder | 3d | 2 | town-ground-meshes | pending | required, no approval stop | proposed addition |
| map-terrain/town-ground-kingdoms | 3d | 2 | town-ground-meshes | pending | required, no approval stop | proposed addition |
| map-terrain/town-ground-modern | 3d | 2 | town-ground-meshes | pending | required, no approval stop | proposed addition |
| map-terrain/wetlands | 3d | 2 | map-terrain-kits | pending | required, no approval stop | plans/art/map-terrain/wetlands |
| map-towns/base/classical/town-big-a | 3d | 2 | named-town-gaps | built_awaiting_validation_upload | legacy/2D | plans/art/towns/classical/town-big |
| map-towns/base/classical/town-big-b | 3d | 2 | named-town-gaps | built_awaiting_validation_upload | legacy/2D | plans/art/towns/classical/town-big |
| map-towns/europe/modern/town-big-a | 3d | 2 | named-town-gaps | pending | required, no approval stop | proposed addition |
| map-towns/europe/modern/town-big-b | 3d | 2 | named-town-gaps | pending | required, no approval stop | proposed addition |
| map-towns/europe/modern/town-medium-a | 3d | 2 | named-town-gaps | pending | required, no approval stop | proposed addition |
| map-towns/europe/modern/town-medium-b | 3d | 2 | named-town-gaps | pending | required, no approval stop | proposed addition |
| map-towns/europe/modern/town-small-a | 3d | 2 | named-town-gaps | pending | required, no approval stop | proposed addition |
| map-towns/europe/modern/town-small-b | 3d | 2 | named-town-gaps | pending | required, no approval stop | proposed addition |
| map-towns/europenorth/classical/town-big-a | 3d | 2 | named-town-gaps | pending | required, no approval stop | proposed addition |
| map-towns/europenorth/classical/town-big-b | 3d | 2 | named-town-gaps | pending | required, no approval stop | proposed addition |
| map-towns/europenorth/classical/town-medium-a | 3d | 2 | named-town-gaps | pending | required, no approval stop | proposed addition |
| map-towns/europenorth/classical/town-medium-b | 3d | 2 | named-town-gaps | pending | required, no approval stop | proposed addition |
| map-towns/indic/gunpowder/town-big-a | 3d | 2 | named-town-gaps | pending | required, no approval stop | proposed addition |
| map-towns/indic/gunpowder/town-big-b | 3d | 2 | named-town-gaps | pending | required, no approval stop | proposed addition |
| map-towns/indic/gunpowder/town-medium-a | 3d | 2 | named-town-gaps | pending | required, no approval stop | proposed addition |
| map-towns/indic/gunpowder/town-medium-b | 3d | 2 | named-town-gaps | pending | required, no approval stop | proposed addition |
| map-towns/indic/gunpowder/town-small-a | 3d | 2 | named-town-gaps | pending | required, no approval stop | proposed addition |
| map-towns/indic/gunpowder/town-small-b | 3d | 2 | named-town-gaps | pending | required, no approval stop | proposed addition |
| map-towns/indic/modern/town-big-a | 3d | 2 | named-town-gaps | pending | required, no approval stop | proposed addition |
| map-towns/indic/modern/town-big-b | 3d | 2 | named-town-gaps | pending | required, no approval stop | proposed addition |
| map-towns/indic/modern/town-medium-a | 3d | 2 | named-town-gaps | pending | required, no approval stop | proposed addition |
| map-towns/indic/modern/town-medium-b | 3d | 2 | named-town-gaps | pending | required, no approval stop | proposed addition |
| map-towns/indic/modern/town-small-a | 3d | 2 | named-town-gaps | pending | required, no approval stop | proposed addition |
| map-towns/indic/modern/town-small-b | 3d | 2 | named-town-gaps | pending | required, no approval stop | proposed addition |
| map-towns/korea/kingdoms/town-big-a | 3d | 2 | named-town-gaps | pending | required, no approval stop | proposed addition |
| map-towns/korea/kingdoms/town-big-b | 3d | 2 | named-town-gaps | pending | required, no approval stop | proposed addition |
| map-towns/levant/bronze/town-big-a | 3d | 2 | named-town-gaps | pending | required, no approval stop | proposed addition |
| map-towns/levant/bronze/town-big-b | 3d | 2 | named-town-gaps | pending | required, no approval stop | proposed addition |
| map-towns/levant/bronze/town-medium-a | 3d | 2 | named-town-gaps | pending | required, no approval stop | proposed addition |
| map-towns/levant/bronze/town-medium-b | 3d | 2 | named-town-gaps | pending | required, no approval stop | proposed addition |
| map-towns/levant/bronze/town-small-a | 3d | 2 | named-town-gaps | pending | required, no approval stop | proposed addition |
| map-towns/levant/bronze/town-small-b | 3d | 2 | named-town-gaps | pending | required, no approval stop | proposed addition |
| map-towns/pacific/bronze/town-big-a | 3d | 2 | named-town-gaps | pending | required, no approval stop | proposed addition |
| map-towns/pacific/bronze/town-big-b | 3d | 2 | named-town-gaps | pending | required, no approval stop | proposed addition |
| map-towns/steppe/modern/town-big-a | 3d | 2 | named-town-gaps | pending | required, no approval stop | proposed addition |
| map-towns/steppe/modern/town-big-b | 3d | 2 | named-town-gaps | pending | required, no approval stop | proposed addition |
| map-towns/steppe/modern/town-medium-a | 3d | 2 | named-town-gaps | pending | required, no approval stop | proposed addition |
| map-towns/steppe/modern/town-medium-b | 3d | 2 | named-town-gaps | pending | required, no approval stop | proposed addition |
| map-towns/steppe/modern/town-small-a | 3d | 2 | named-town-gaps | pending | required, no approval stop | proposed addition |
| map-towns/steppe/modern/town-small-b | 3d | 2 | named-town-gaps | pending | required, no approval stop | proposed addition |
| battle-city/classical/americas/houses-damage | 3d | 3 | house-damage | pending | required, no approval stop | plans/art/battle-city/classical/americas/houses-damage |
| battle-city/classical/base/houses-damage | 3d | 3 | house-damage | pending | required, no approval stop | plans/art/battle-city/classical/base/houses-damage |
| battle-city/classical/eastafrica/houses-damage | 3d | 3 | house-damage | pending | required, no approval stop | plans/art/battle-city/classical/eastafrica/houses-damage |
| battle-city/classical/europe/houses-damage | 3d | 3 | house-damage | pending | required, no approval stop | plans/art/battle-city/classical/europe/houses-damage |
| battle-city/classical/indic/houses-damage | 3d | 3 | house-damage | pending | required, no approval stop | plans/art/battle-city/classical/indic/houses-damage |
| battle-city/classical/israelite/houses-damage | 3d | 3 | house-damage | pending | required, no approval stop | plans/art/battle-city/classical/israelite/houses-damage |
| battle-city/classical/levant/houses-damage | 3d | 3 | house-damage | pending | required, no approval stop | plans/art/battle-city/classical/levant/houses-damage |
| battle-city/classical/maghreb/houses-damage | 3d | 3 | house-damage | pending | required, no approval stop | plans/art/battle-city/classical/maghreb/houses-damage |
| battle-city/classical/monsoon/houses-damage | 3d | 3 | house-damage | pending | required, no approval stop | plans/art/battle-city/classical/monsoon/houses-damage |
| battle-city/classical/nile/houses-damage | 3d | 3 | house-damage | pending | required, no approval stop | plans/art/battle-city/classical/nile/houses-damage |
| battle-city/classical/ruin-library | 3d | 3 | ruin-libraries | pending | required, no approval stop | plans/art/battle-city/classical/ruin-library |
| battle-city/classical/sinic/houses-damage | 3d | 3 | house-damage | pending | required, no approval stop | plans/art/battle-city/classical/sinic/houses-damage |
| battle-city/classical/steppe/houses-damage | 3d | 3 | house-damage | pending | required, no approval stop | plans/art/battle-city/classical/steppe/houses-damage |
| battle-city/classical/wall-kit | 3d | 3 | wall-kits | pending | required, no approval stop | plans/art/battle-city/classical/wall-kit |
| battle-city/classical/westafrica/houses-damage | 3d | 3 | house-damage | pending | required, no approval stop | plans/art/battle-city/classical/westafrica/houses-damage |
| battle-terrain/bridge-stone | 3d | 3 | battle-terrain | pending | required, no approval stop | plans/art/battle-terrain/bridge-stone |
| fort/classical | 3d | 3 | shared-map-battle-forts | pending | required, no approval stop | plans/art/battle-city/classical/fort; plans/art/improvements/classical/fort-classical |
| projectiles/classical | 3d | 3 | projectiles | pending | required, no approval stop | proposed addition |
| props/classical | 3d | 3 | age-props | pending | required, no approval stop | proposed addition |
| rts/classical/aid-post | 3d | 3 | battle-buildings | pending | required, no approval stop | plans/art/rts/classical/aid-post |
| rts/classical/barracks | 3d | 3 | battle-buildings | pending | required, no approval stop | plans/art/rts/classical/barracks |
| rts/classical/construction-set | 3d | 3 | battle-buildings | pending | required, no approval stop | plans/art/rts/classical/construction-set |
| rts/classical/expedition-camp | 3d | 3 | battle-buildings | pending | required, no approval stop | plans/art/rts/classical/expedition-camp |
| rts/classical/farm-plot | 3d | 3 | battle-buildings | pending | required, no approval stop | plans/art/rts/classical/farm-plot |
| rts/classical/food-depot | 3d | 3 | battle-buildings | pending | required, no approval stop | plans/art/rts/classical/food-depot |
| rts/classical/house | 3d | 3 | battle-buildings | pending | required, no approval stop | proposed addition |
| rts/classical/materials-yard | 3d | 3 | battle-buildings | pending | required, no approval stop | plans/art/rts/classical/materials-yard |
| rts/classical/mine | 3d | 3 | battle-buildings | pending | required, no approval stop | plans/art/rts/classical/mine |
| rts/classical/range | 3d | 3 | battle-buildings | pending | required, no approval stop | plans/art/rts/classical/range |
| rts/classical/siege-workshop | 3d | 3 | battle-buildings | pending | required, no approval stop | plans/art/rts/classical/siege-workshop |
| rts/classical/stable | 3d | 3 | battle-buildings | pending | required, no approval stop | plans/art/rts/classical/stable |
| rts/classical/tower | 3d | 3 | battle-buildings | pending | required, no approval stop | plans/art/rts/classical/tower |
| rts/classical/town-hall | 3d | 3 | battle-buildings | pending | required, no approval stop | plans/art/rts/classical/town-hall |
| rts/classical/trade-post | 3d | 3 | battle-buildings | pending | required, no approval stop | plans/art/rts/classical/trade-post |
| unit-rigs/camel | 3d | 3 | mount-rigs | pending | required, no approval stop | proposed addition |
| unit-rigs/elephant | 3d | 3 | mount-rigs | pending | required, no approval stop | proposed addition |
| units/classical-cavalry | 3d | 3 | base-units | pending | required, no approval stop | plans/art/units/classical-cavalry |
| units/classical-general | 3d | 3 | commanders-irregulars | pending | required, no approval stop | plans/art/units/classical-general |
| units/classical-infantry | 3d | 3 | base-units | pending | required, no approval stop | plans/art/units/classical-infantry; plans/art/units/impostors/classical-infantry-lod3 |
| units/classical-mercenary | 3d | 3 | commanders-irregulars | pending | required, no approval stop | plans/art/units/classical-mercenary |
| units/classical-raider | 3d | 3 | commanders-irregulars | pending | required, no approval stop | plans/art/units/classical-raider |
| units/classical-ranged | 3d | 3 | base-units | pending | required, no approval stop | plans/art/units/classical-ranged |
| units/classical-siege | 3d | 3 | base-units | pending | required, no approval stop | plans/art/units/classical-siege |
| units/classical-support | 3d | 3 | base-units | pending | required, no approval stop | plans/art/units/classical-support |
| units/classical-worker | 3d | 3 | base-units | pending | required, no approval stop | plans/art/units/classical-worker; plans/art/units/settler-classical |
| units/signature/aghvank | 3d | 3 | signature-units | pending | required, no approval stop | proposed addition |
| units/signature/arverni | 3d | 3 | signature-units | pending | required, no approval stop | proposed addition |
| units/signature/avanti | 3d | 3 | signature-units | pending | required, no approval stop | proposed addition |
| units/signature/bactria | 3d | 3 | signature-units | pending | required, no approval stop | proposed addition |
| units/signature/belgae | 3d | 3 | signature-units | pending | required, no approval stop | proposed addition |
| units/signature/bosporan-kingdom | 3d | 3 | signature-units | pending | required, no approval stop | proposed addition |
| units/signature/brigantes | 3d | 3 | signature-units | pending | required, no approval stop | proposed addition |
| units/signature/buyeo | 3d | 3 | signature-units | pending | required, no approval stop | proposed addition |
| units/signature/cherusci | 3d | 3 | signature-units | pending | required, no approval stop | proposed addition |
| units/signature/chu | 3d | 3 | signature-units | pending | required, no approval stop | proposed addition |
| units/signature/cyrene | 3d | 3 | signature-units | pending | required, no approval stop | proposed addition |
| units/signature/dian | 3d | 3 | signature-units | pending | required, no approval stop | proposed addition |
| units/signature/durotriges | 3d | 3 | signature-units | pending | required, no approval stop | proposed addition |
| units/signature/hopewell | 3d | 3 | signature-units | pending | required, no approval stop | proposed addition |
| units/signature/kalinga | 3d | 3 | signature-units | pending | required, no approval stop | proposed addition |
| units/signature/kosala | 3d | 3 | signature-units | pending | required, no approval stop | proposed addition |
| units/signature/kroraina | 3d | 3 | signature-units | pending | required, no approval stop | proposed addition |
| units/signature/lydia | 3d | 3 | signature-units | pending | required, no approval stop | proposed addition |
| units/signature/magadha | 3d | 3 | signature-units | pending | required, no approval stop | proposed addition |
| units/signature/mauretania | 3d | 3 | signature-units | pending | required, no approval stop | proposed addition |
| units/signature/media | 3d | 3 | signature-units | pending | required, no approval stop | proposed addition |
| units/signature/nabataea | 3d | 3 | signature-units | pending | required, no approval stop | proposed addition |
| units/signature/nanyue | 3d | 3 | signature-units | pending | required, no approval stop | proposed addition |
| units/signature/nok | 3d | 3 | signature-units | pending | required, no approval stop | proposed addition |
| units/signature/numidia | 3d | 3 | signature-units | pending | required, no approval stop | proposed addition |
| units/signature/parthava | 3d | 3 | signature-units | pending | required, no approval stop | proposed addition |
| units/signature/pontus | 3d | 3 | signature-units | pending | required, no approval stop | proposed addition |
| units/signature/qedar | 3d | 3 | signature-units | pending | required, no approval stop | proposed addition |
| units/signature/qi | 3d | 3 | signature-units | pending | required, no approval stop | proposed addition |
| units/signature/rasenna | 3d | 3 | signature-units | pending | required, no approval stop | proposed addition |
| units/signature/saba | 3d | 3 | signature-units | pending | required, no approval stop | proposed addition |
| units/signature/satavahana | 3d | 3 | signature-units | pending | required, no approval stop | proposed addition |
| units/signature/teotihuacan | 3d | 3 | signature-units | pending | required, no approval stop | proposed addition |
| units/signature/wusun | 3d | 3 | signature-units | pending | required, no approval stop | proposed addition |
| units/signature/xianbei | 3d | 3 | signature-units | pending | required, no approval stop | proposed addition |
| units/signature/yamatai | 3d | 3 | signature-units | pending | required, no approval stop | proposed addition |
| units/signature/yue | 3d | 3 | signature-units | pending | required, no approval stop | proposed addition |
| units/signature/zapotec | 3d | 3 | signature-units | pending | required, no approval stop | proposed addition |
| battle-city/kingdoms/americas/houses-damage | 3d | 4 | house-damage | pending | required, no approval stop | plans/art/battle-city/kingdoms/americas/houses-damage |
| battle-city/kingdoms/base/houses-damage | 3d | 4 | house-damage | pending | required, no approval stop | plans/art/battle-city/kingdoms/base/houses-damage |
| battle-city/kingdoms/eastafrica/houses-damage | 3d | 4 | house-damage | pending | required, no approval stop | plans/art/battle-city/kingdoms/eastafrica/houses-damage |
| battle-city/kingdoms/europe/houses-damage | 3d | 4 | house-damage | pending | required, no approval stop | plans/art/battle-city/kingdoms/europe/houses-damage |
| battle-city/kingdoms/indic/houses-damage | 3d | 4 | house-damage | pending | required, no approval stop | plans/art/battle-city/kingdoms/indic/houses-damage |
| battle-city/kingdoms/israelite/houses-damage | 3d | 4 | house-damage | pending | required, no approval stop | plans/art/battle-city/kingdoms/israelite/houses-damage |
| battle-city/kingdoms/levant/houses-damage | 3d | 4 | house-damage | pending | required, no approval stop | plans/art/battle-city/kingdoms/levant/houses-damage |
| battle-city/kingdoms/maghreb/houses-damage | 3d | 4 | house-damage | pending | required, no approval stop | plans/art/battle-city/kingdoms/maghreb/houses-damage |
| battle-city/kingdoms/monsoon/houses-damage | 3d | 4 | house-damage | pending | required, no approval stop | plans/art/battle-city/kingdoms/monsoon/houses-damage |
| battle-city/kingdoms/nile/houses-damage | 3d | 4 | house-damage | pending | required, no approval stop | plans/art/battle-city/kingdoms/nile/houses-damage |
| battle-city/kingdoms/ruin-library | 3d | 4 | ruin-libraries | pending | required, no approval stop | plans/art/battle-city/kingdoms/ruin-library |
| battle-city/kingdoms/sinic/houses-damage | 3d | 4 | house-damage | pending | required, no approval stop | plans/art/battle-city/kingdoms/sinic/houses-damage |
| battle-city/kingdoms/steppe/houses-damage | 3d | 4 | house-damage | pending | required, no approval stop | plans/art/battle-city/kingdoms/steppe/houses-damage |
| battle-city/kingdoms/wall-kit | 3d | 4 | wall-kits | pending | required, no approval stop | plans/art/battle-city/kingdoms/wall-kit |
| battle-city/kingdoms/westafrica/houses-damage | 3d | 4 | house-damage | pending | required, no approval stop | plans/art/battle-city/kingdoms/westafrica/houses-damage |
| fort/kingdoms | 3d | 4 | shared-map-battle-forts | pending | required, no approval stop | plans/art/battle-city/kingdoms/fort; plans/art/improvements/kingdoms/fort-kingdoms |
| projectiles/kingdoms | 3d | 4 | projectiles | pending | required, no approval stop | proposed addition |
| props/kingdoms | 3d | 4 | age-props | pending | required, no approval stop | proposed addition |
| rts/kingdoms/aid-post | 3d | 4 | battle-buildings | pending | required, no approval stop | plans/art/rts/kingdoms/aid-post |
| rts/kingdoms/barracks | 3d | 4 | battle-buildings | pending | required, no approval stop | plans/art/rts/kingdoms/barracks |
| rts/kingdoms/construction-set | 3d | 4 | battle-buildings | pending | required, no approval stop | plans/art/rts/kingdoms/construction-set |
| rts/kingdoms/expedition-camp | 3d | 4 | battle-buildings | pending | required, no approval stop | plans/art/rts/kingdoms/expedition-camp |
| rts/kingdoms/farm-plot | 3d | 4 | battle-buildings | pending | required, no approval stop | plans/art/rts/kingdoms/farm-plot |
| rts/kingdoms/food-depot | 3d | 4 | battle-buildings | pending | required, no approval stop | plans/art/rts/kingdoms/food-depot |
| rts/kingdoms/house | 3d | 4 | battle-buildings | pending | required, no approval stop | proposed addition |
| rts/kingdoms/materials-yard | 3d | 4 | battle-buildings | pending | required, no approval stop | plans/art/rts/kingdoms/materials-yard |
| rts/kingdoms/mine | 3d | 4 | battle-buildings | pending | required, no approval stop | plans/art/rts/kingdoms/mine |
| rts/kingdoms/range | 3d | 4 | battle-buildings | pending | required, no approval stop | plans/art/rts/kingdoms/range |
| rts/kingdoms/siege-workshop | 3d | 4 | battle-buildings | pending | required, no approval stop | plans/art/rts/kingdoms/siege-workshop |
| rts/kingdoms/stable | 3d | 4 | battle-buildings | pending | required, no approval stop | plans/art/rts/kingdoms/stable |
| rts/kingdoms/tower | 3d | 4 | battle-buildings | pending | required, no approval stop | plans/art/rts/kingdoms/tower |
| rts/kingdoms/town-hall | 3d | 4 | battle-buildings | pending | required, no approval stop | plans/art/rts/kingdoms/town-hall |
| rts/kingdoms/trade-post | 3d | 4 | battle-buildings | pending | required, no approval stop | plans/art/rts/kingdoms/trade-post |
| units/kingdoms-cavalry | 3d | 4 | base-units | pending | required, no approval stop | plans/art/units/kingdoms-cavalry |
| units/kingdoms-general | 3d | 4 | commanders-irregulars | pending | required, no approval stop | plans/art/units/kingdoms-general |
| units/kingdoms-infantry | 3d | 4 | base-units | pending | required, no approval stop | plans/art/units/kingdoms-infantry |
| units/kingdoms-mercenary | 3d | 4 | commanders-irregulars | pending | required, no approval stop | plans/art/units/kingdoms-mercenary |
| units/kingdoms-raider | 3d | 4 | commanders-irregulars | pending | required, no approval stop | plans/art/units/kingdoms-raider |
| units/kingdoms-ranged | 3d | 4 | base-units | pending | required, no approval stop | plans/art/units/kingdoms-ranged |
| units/kingdoms-siege | 3d | 4 | base-units | pending | required, no approval stop | plans/art/units/kingdoms-siege |
| units/kingdoms-support | 3d | 4 | base-units | pending | required, no approval stop | plans/art/units/kingdoms-support |
| units/kingdoms-worker | 3d | 4 | base-units | pending | required, no approval stop | plans/art/units/kingdoms-worker; plans/art/units/settler-kingdoms |
| units/signature/alodia | 3d | 4 | signature-units | pending | required, no approval stop | proposed addition |
| units/signature/baekje | 3d | 4 | signature-units | pending | required, no approval stop | proposed addition |
| units/signature/butuan | 3d | 4 | signature-units | pending | required, no approval stop | proposed addition |
| units/signature/chaco | 3d | 4 | signature-units | pending | required, no approval stop | proposed addition |
| units/signature/champa | 3d | 4 | signature-units | pending | required, no approval stop | proposed addition |
| units/signature/djenne-djeno | 3d | 4 | signature-units | pending | required, no approval stop | proposed addition |
| units/signature/dvaravati | 3d | 4 | signature-units | pending | required, no approval stop | proposed addition |
| units/signature/emishi | 3d | 4 | signature-units | pending | required, no approval stop | proposed addition |
| units/signature/engaruka | 3d | 4 | signature-units | pending | required, no approval stop | proposed addition |
| units/signature/funan | 3d | 4 | signature-units | pending | required, no approval stop | proposed addition |
| units/signature/gokturk | 3d | 4 | signature-units | pending | required, no approval stop | proposed addition |
| units/signature/hohokam | 3d | 4 | signature-units | pending | required, no approval stop | proposed addition |
| units/signature/ife | 3d | 4 | signature-units | pending | required, no approval stop | proposed addition |
| units/signature/kamarupa | 3d | 4 | signature-units | pending | required, no approval stop | proposed addition |
| units/signature/khazaria | 3d | 4 | signature-units | pending | required, no approval stop | proposed addition |
| units/signature/khotan | 3d | 4 | signature-units | pending | required, no approval stop | proposed addition |
| units/signature/khwarazm | 3d | 4 | signature-units | pending | required, no approval stop | proposed addition |
| units/signature/kitara | 3d | 4 | signature-units | pending | required, no approval stop | proposed addition |
| units/signature/mapungubwe | 3d | 4 | signature-units | pending | required, no approval stop | proposed addition |
| units/signature/marajoara | 3d | 4 | signature-units | pending | required, no approval stop | proposed addition |
| units/signature/moche | 3d | 4 | signature-units | pending | required, no approval stop | proposed addition |
| units/signature/mutal | 3d | 4 | signature-units | pending | required, no approval stop | proposed addition |
| units/signature/pandya | 3d | 4 | signature-units | pending | required, no approval stop | proposed addition |
| units/signature/pyu | 3d | 4 | signature-units | pending | required, no approval stop | proposed addition |
| units/signature/rajarata | 3d | 4 | signature-units | pending | required, no approval stop | proposed addition |
| units/signature/san | 3d | 4 | signature-units | pending | required, no approval stop | proposed addition |
| units/signature/saudeleur | 3d | 4 | signature-units | pending | required, no approval stop | proposed addition |
| units/signature/sogdia | 3d | 4 | signature-units | pending | required, no approval stop | proposed addition |
| units/signature/srivijaya | 3d | 4 | signature-units | pending | required, no approval stop | proposed addition |
| units/signature/tarumanagara | 3d | 4 | signature-units | pending | required, no approval stop | proposed addition |
| units/signature/tiwanaku | 3d | 4 | signature-units | pending | required, no approval stop | proposed addition |
| units/signature/vanga | 3d | 4 | signature-units | pending | required, no approval stop | proposed addition |
| units/signature/wagadu | 3d | 4 | signature-units | pending | required, no approval stop | proposed addition |
| units/signature/wari | 3d | 4 | signature-units | pending | required, no approval stop | proposed addition |
| units/signature/yarlung | 3d | 4 | signature-units | pending | required, no approval stop | proposed addition |
| units/signature/zhangzhung | 3d | 4 | signature-units | pending | required, no approval stop | proposed addition |
| battle-city/gunpowder/americas/houses-damage | 3d | 5 | house-damage | pending | required, no approval stop | plans/art/battle-city/gunpowder/americas/houses-damage |
| battle-city/gunpowder/base/houses-damage | 3d | 5 | house-damage | pending | required, no approval stop | plans/art/battle-city/gunpowder/base/houses-damage |
| battle-city/gunpowder/eastafrica/houses-damage | 3d | 5 | house-damage | pending | required, no approval stop | plans/art/battle-city/gunpowder/eastafrica/houses-damage |
| battle-city/gunpowder/europe/houses-damage | 3d | 5 | house-damage | pending | required, no approval stop | plans/art/battle-city/gunpowder/europe/houses-damage |
| battle-city/gunpowder/indic/houses-damage | 3d | 5 | house-damage | pending | required, no approval stop | plans/art/battle-city/gunpowder/indic/houses-damage |
| battle-city/gunpowder/israelite/houses-damage | 3d | 5 | house-damage | pending | required, no approval stop | plans/art/battle-city/gunpowder/israelite/houses-damage |
| battle-city/gunpowder/levant/houses-damage | 3d | 5 | house-damage | pending | required, no approval stop | plans/art/battle-city/gunpowder/levant/houses-damage |
| battle-city/gunpowder/maghreb/houses-damage | 3d | 5 | house-damage | pending | required, no approval stop | plans/art/battle-city/gunpowder/maghreb/houses-damage |
| battle-city/gunpowder/monsoon/houses-damage | 3d | 5 | house-damage | pending | required, no approval stop | plans/art/battle-city/gunpowder/monsoon/houses-damage |
| battle-city/gunpowder/nile/houses-damage | 3d | 5 | house-damage | pending | required, no approval stop | plans/art/battle-city/gunpowder/nile/houses-damage |
| battle-city/gunpowder/ruin-library | 3d | 5 | ruin-libraries | pending | required, no approval stop | plans/art/battle-city/gunpowder/ruin-library |
| battle-city/gunpowder/sinic/houses-damage | 3d | 5 | house-damage | pending | required, no approval stop | plans/art/battle-city/gunpowder/sinic/houses-damage |
| battle-city/gunpowder/steppe/houses-damage | 3d | 5 | house-damage | pending | required, no approval stop | plans/art/battle-city/gunpowder/steppe/houses-damage |
| battle-city/gunpowder/wall-kit | 3d | 5 | wall-kits | pending | required, no approval stop | plans/art/battle-city/gunpowder/wall-kit |
| battle-city/gunpowder/westafrica/houses-damage | 3d | 5 | house-damage | pending | required, no approval stop | plans/art/battle-city/gunpowder/westafrica/houses-damage |
| fort/gunpowder | 3d | 5 | shared-map-battle-forts | pending | required, no approval stop | plans/art/battle-city/gunpowder/fort; plans/art/improvements/gunpowder/fort-gunpowder |
| projectiles/gunpowder | 3d | 5 | projectiles | pending | required, no approval stop | proposed addition |
| props/gunpowder | 3d | 5 | age-props | pending | required, no approval stop | proposed addition |
| rts/gunpowder/aid-post | 3d | 5 | battle-buildings | pending | required, no approval stop | plans/art/rts/gunpowder/aid-post |
| rts/gunpowder/barracks | 3d | 5 | battle-buildings | pending | required, no approval stop | plans/art/rts/gunpowder/barracks |
| rts/gunpowder/construction-set | 3d | 5 | battle-buildings | pending | required, no approval stop | plans/art/rts/gunpowder/construction-set |
| rts/gunpowder/expedition-camp | 3d | 5 | battle-buildings | pending | required, no approval stop | plans/art/rts/gunpowder/expedition-camp |
| rts/gunpowder/farm-plot | 3d | 5 | battle-buildings | pending | required, no approval stop | plans/art/rts/gunpowder/farm-plot |
| rts/gunpowder/food-depot | 3d | 5 | battle-buildings | pending | required, no approval stop | plans/art/rts/gunpowder/food-depot |
| rts/gunpowder/house | 3d | 5 | battle-buildings | pending | required, no approval stop | proposed addition |
| rts/gunpowder/materials-yard | 3d | 5 | battle-buildings | pending | required, no approval stop | plans/art/rts/gunpowder/materials-yard |
| rts/gunpowder/mine | 3d | 5 | battle-buildings | pending | required, no approval stop | plans/art/rts/gunpowder/mine |
| rts/gunpowder/range | 3d | 5 | battle-buildings | pending | required, no approval stop | plans/art/rts/gunpowder/range |
| rts/gunpowder/siege-workshop | 3d | 5 | battle-buildings | pending | required, no approval stop | plans/art/rts/gunpowder/siege-workshop |
| rts/gunpowder/stable | 3d | 5 | battle-buildings | pending | required, no approval stop | plans/art/rts/gunpowder/stable |
| rts/gunpowder/tower | 3d | 5 | battle-buildings | pending | required, no approval stop | plans/art/rts/gunpowder/tower |
| rts/gunpowder/town-hall | 3d | 5 | battle-buildings | pending | required, no approval stop | plans/art/rts/gunpowder/town-hall |
| rts/gunpowder/trade-post | 3d | 5 | battle-buildings | pending | required, no approval stop | plans/art/rts/gunpowder/trade-post |
| units/gunpowder-cavalry | 3d | 5 | base-units | pending | required, no approval stop | plans/art/units/gunpowder-cavalry |
| units/gunpowder-general | 3d | 5 | commanders-irregulars | pending | required, no approval stop | plans/art/units/gunpowder-general |
| units/gunpowder-infantry | 3d | 5 | base-units | pending | required, no approval stop | plans/art/units/gunpowder-infantry |
| units/gunpowder-mercenary | 3d | 5 | commanders-irregulars | pending | required, no approval stop | plans/art/units/gunpowder-mercenary |
| units/gunpowder-raider | 3d | 5 | commanders-irregulars | pending | required, no approval stop | plans/art/units/gunpowder-raider |
| units/gunpowder-ranged | 3d | 5 | base-units | pending | required, no approval stop | plans/art/units/gunpowder-ranged |
| units/gunpowder-siege | 3d | 5 | base-units | pending | required, no approval stop | plans/art/units/gunpowder-siege |
| units/gunpowder-support | 3d | 5 | base-units | pending | required, no approval stop | plans/art/units/gunpowder-support |
| units/gunpowder-worker | 3d | 5 | base-units | pending | required, no approval stop | plans/art/units/gunpowder-worker; plans/art/units/settler-gunpowder |
| units/signature/ajuran | 3d | 5 | signature-units | pending | required, no approval stop | proposed addition |
| units/signature/avaria | 3d | 5 | signature-units | pending | required, no approval stop | proposed addition |
| units/signature/bau | 3d | 5 | signature-units | pending | required, no approval stop | proposed addition |
| units/signature/bono | 3d | 5 | signature-units | pending | required, no approval stop | proposed addition |
| units/signature/calusa | 3d | 5 | signature-units | pending | required, no approval stop | proposed addition |
| units/signature/celtiberia | 3d | 5 | signature-units | pending | required, no approval stop | proposed addition |
| units/signature/diaguita | 3d | 5 | signature-units | pending | required, no approval stop | proposed addition |
| units/signature/fortriu | 3d | 5 | signature-units | pending | required, no approval stop | proposed addition |
| units/signature/gandhara | 3d | 5 | signature-units | pending | required, no approval stop | proposed addition |
| units/signature/geats | 3d | 5 | signature-units | pending | required, no approval stop | proposed addition |
| units/signature/gunditjmara | 3d | 5 | signature-units | pending | required, no approval stop | proposed addition |
| units/signature/haida | 3d | 5 | signature-units | pending | required, no approval stop | proposed addition |
| units/signature/jaragua | 3d | 5 | signature-units | pending | required, no approval stop | proposed addition |
| units/signature/kalinago | 3d | 5 | signature-units | pending | required, no approval stop | proposed addition |
| units/signature/kanem | 3d | 5 | signature-units | pending | required, no approval stop | proposed addition |
| units/signature/khoekhoe | 3d | 5 | signature-units | pending | required, no approval stop | proposed addition |
| units/signature/kilwa | 3d | 5 | signature-units | pending | required, no approval stop | proposed addition |
| units/signature/kutai | 3d | 5 | signature-units | pending | required, no approval stop | proposed addition |
| units/signature/latte-chiefs | 3d | 5 | signature-units | pending | required, no approval stop | proposed addition |
| units/signature/luba | 3d | 5 | signature-units | pending | required, no approval stop | proposed addition |
| units/signature/lunda | 3d | 5 | signature-units | pending | required, no approval stop | proposed addition |
| units/signature/lusitania | 3d | 5 | signature-units | pending | required, no approval stop | proposed addition |
| units/signature/medang | 3d | 5 | signature-units | pending | required, no approval stop | proposed addition |
| units/signature/merina | 3d | 5 | signature-units | pending | required, no approval stop | proposed addition |
| units/signature/muisca | 3d | 5 | signature-units | pending | required, no approval stop | proposed addition |
| units/signature/mutapa | 3d | 5 | signature-units | pending | required, no approval stop | proposed addition |
| units/signature/ndongo | 3d | 5 | signature-units | pending | required, no approval stop | proposed addition |
| units/signature/odrysia | 3d | 5 | signature-units | pending | required, no approval stop | proposed addition |
| units/signature/sarmatians | 3d | 5 | signature-units | pending | required, no approval stop | proposed addition |
| units/signature/tondo | 3d | 5 | signature-units | pending | required, no approval stop | proposed addition |
| units/signature/tupinamba | 3d | 5 | signature-units | pending | required, no approval stop | proposed addition |
| units/signature/ulaid | 3d | 5 | signature-units | pending | required, no approval stop | proposed addition |
| battle-city/modern/americas/houses-damage | 3d | 6 | house-damage | pending | required, no approval stop | plans/art/battle-city/modern/americas/houses-damage |
| battle-city/modern/base/houses-damage | 3d | 6 | house-damage | pending | required, no approval stop | plans/art/battle-city/modern/base/houses-damage |
| battle-city/modern/eastafrica/houses-damage | 3d | 6 | house-damage | pending | required, no approval stop | plans/art/battle-city/modern/eastafrica/houses-damage |
| battle-city/modern/europe/houses-damage | 3d | 6 | house-damage | pending | required, no approval stop | plans/art/battle-city/modern/europe/houses-damage |
| battle-city/modern/indic/houses-damage | 3d | 6 | house-damage | pending | required, no approval stop | plans/art/battle-city/modern/indic/houses-damage |
| battle-city/modern/israelite/houses-damage | 3d | 6 | house-damage | pending | required, no approval stop | plans/art/battle-city/modern/israelite/houses-damage |
| battle-city/modern/levant/houses-damage | 3d | 6 | house-damage | pending | required, no approval stop | plans/art/battle-city/modern/levant/houses-damage |
| battle-city/modern/maghreb/houses-damage | 3d | 6 | house-damage | pending | required, no approval stop | plans/art/battle-city/modern/maghreb/houses-damage |
| battle-city/modern/monsoon/houses-damage | 3d | 6 | house-damage | pending | required, no approval stop | plans/art/battle-city/modern/monsoon/houses-damage |
| battle-city/modern/nile/houses-damage | 3d | 6 | house-damage | pending | required, no approval stop | plans/art/battle-city/modern/nile/houses-damage |
| battle-city/modern/ruin-library | 3d | 6 | ruin-libraries | pending | required, no approval stop | plans/art/battle-city/modern/ruin-library |
| battle-city/modern/sinic/houses-damage | 3d | 6 | house-damage | pending | required, no approval stop | plans/art/battle-city/modern/sinic/houses-damage |
| battle-city/modern/steppe/houses-damage | 3d | 6 | house-damage | pending | required, no approval stop | plans/art/battle-city/modern/steppe/houses-damage |
| battle-city/modern/wall-kit | 3d | 6 | wall-kits | pending | required, no approval stop | plans/art/battle-city/modern/wall-kit |
| battle-city/modern/westafrica/houses-damage | 3d | 6 | house-damage | pending | required, no approval stop | plans/art/battle-city/modern/westafrica/houses-damage |
| battle-terrain/bridge-steel | 3d | 6 | battle-terrain | pending | required, no approval stop | plans/art/battle-terrain/bridge-steel |
| fort/modern | 3d | 6 | shared-map-battle-forts | pending | required, no approval stop | plans/art/battle-city/modern/fort; plans/art/improvements/modern/fort-modern |
| projectiles/modern | 3d | 6 | projectiles | pending | required, no approval stop | proposed addition |
| props/modern | 3d | 6 | age-props | pending | required, no approval stop | proposed addition |
| rts/modern/aid-post | 3d | 6 | battle-buildings | pending | required, no approval stop | plans/art/rts/modern/aid-post |
| rts/modern/airfield | 3d | 6 | battle-buildings | pending | required, no approval stop | plans/art/rts/modern/airfield |
| rts/modern/barracks | 3d | 6 | battle-buildings | pending | required, no approval stop | plans/art/rts/modern/barracks |
| rts/modern/construction-set | 3d | 6 | battle-buildings | pending | required, no approval stop | plans/art/rts/modern/construction-set |
| rts/modern/expedition-camp | 3d | 6 | battle-buildings | pending | required, no approval stop | plans/art/rts/modern/expedition-camp |
| rts/modern/farm-plot | 3d | 6 | battle-buildings | pending | required, no approval stop | plans/art/rts/modern/farm-plot |
| rts/modern/food-depot | 3d | 6 | battle-buildings | pending | required, no approval stop | plans/art/rts/modern/food-depot |
| rts/modern/generator | 3d | 6 | battle-buildings | pending | required, no approval stop | plans/art/rts/modern/generator |
| rts/modern/house | 3d | 6 | battle-buildings | pending | required, no approval stop | proposed addition |
| rts/modern/materials-yard | 3d | 6 | battle-buildings | pending | required, no approval stop | plans/art/rts/modern/materials-yard |
| rts/modern/mine | 3d | 6 | battle-buildings | pending | required, no approval stop | plans/art/rts/modern/mine |
| rts/modern/radar-aa | 3d | 6 | battle-buildings | pending | required, no approval stop | plans/art/rts/modern/radar-aa |
| rts/modern/range | 3d | 6 | battle-buildings | pending | required, no approval stop | plans/art/rts/modern/range |
| rts/modern/siege-workshop | 3d | 6 | battle-buildings | pending | required, no approval stop | plans/art/rts/modern/siege-workshop |
| rts/modern/stable | 3d | 6 | battle-buildings | pending | required, no approval stop | plans/art/rts/modern/stable |
| rts/modern/tower | 3d | 6 | battle-buildings | pending | required, no approval stop | plans/art/rts/modern/tower |
| rts/modern/town-hall | 3d | 6 | battle-buildings | pending | required, no approval stop | plans/art/rts/modern/town-hall |
| rts/modern/trade-post | 3d | 6 | battle-buildings | pending | required, no approval stop | plans/art/rts/modern/trade-post |
| units/modern-air | 3d | 6 | base-units | pending | required, no approval stop | plans/art/units/modern-air |
| units/modern-cavalry | 3d | 6 | base-units | pending | required, no approval stop | plans/art/units/modern-cavalry |
| units/modern-general | 3d | 6 | commanders-irregulars | pending | required, no approval stop | plans/art/units/modern-general |
| units/modern-infantry | 3d | 6 | base-units | pending | required, no approval stop | plans/art/units/modern-infantry |
| units/modern-mercenary | 3d | 6 | commanders-irregulars | pending | required, no approval stop | plans/art/units/modern-mercenary |
| units/modern-raider | 3d | 6 | commanders-irregulars | pending | required, no approval stop | plans/art/units/modern-raider |
| units/modern-ranged | 3d | 6 | base-units | pending | required, no approval stop | plans/art/units/modern-ranged |
| units/modern-siege | 3d | 6 | base-units | pending | required, no approval stop | plans/art/units/modern-siege |
| units/modern-support | 3d | 6 | base-units | pending | required, no approval stop | plans/art/units/modern-support |
| units/modern-worker | 3d | 6 | base-units | pending | required, no approval stop | plans/art/units/modern-worker; plans/art/units/settler-modern |
| units/signature/d-mt | 3d | 6 | signature-units | pending | required, no approval stop | proposed addition |
| units/signature/dacia | 3d | 6 | signature-units | pending | required, no approval stop | proposed addition |
| units/signature/dorset | 3d | 6 | signature-units | pending | required, no approval stop | proposed addition |
| units/signature/illyria | 3d | 6 | signature-units | pending | required, no approval stop | proposed addition |
| units/signature/kindah | 3d | 6 | signature-units | pending | required, no approval stop | proposed addition |
| units/signature/kingdom-of-israel | 3d | 6 | signature-units | pending | required, no approval stop | plans/art/units/bronze-cavalry-israelite; plans/art/units/bronze-infantry-israelite; plans/art/units/bronze-ranged-israelite; plans/art/units/classical-cavalry-israelite; plans/art/units/classical-infantry-israelite; plans/art/units/classical-ranged-israelite; plans/art/units/classical-siege-israelite; plans/art/units/modern-cavalry-israelite; plans/art/units/modern-infantry-israelite; plans/art/units/settler-bronze-israelite; plans/art/units/settler-modern-israelite |
| units/signature/marcomannia | 3d | 6 | signature-units | pending | required, no approval stop | proposed addition |
| units/signature/noricum | 3d | 6 | signature-units | pending | required, no approval stop | proposed addition |
| units/signature/nuragi | 3d | 6 | signature-units | pending | required, no approval stop | proposed addition |
| units/signature/rygir | 3d | 6 | signature-units | pending | required, no approval stop | proposed addition |
| battle-city/bronze/palace-damage | 3d | 7 | palace-damage | pending | required, no approval stop | proposed addition |
| battle-city/classical/palace-damage | 3d | 7 | palace-damage | pending | required, no approval stop | proposed addition |
| battle-city/gunpowder/palace-damage | 3d | 7 | palace-damage | pending | required, no approval stop | proposed addition |
| battle-city/kingdoms/palace-damage | 3d | 7 | palace-damage | pending | required, no approval stop | proposed addition |
| battle-city/modern/palace-damage | 3d | 7 | palace-damage | pending | required, no approval stop | proposed addition |
| battle-city/wonders/arsenal-ruin | 3d | 7 | wonder-ruins | pending | required, no approval stop | plans/art/battle-city/wonders/arsenal-ruined |
| battle-city/wonders/atomic_research_center-ruin | 3d | 7 | wonder-ruins | pending | required, no approval stop | plans/art/battle-city/wonders/atomic_research_center-ruined |
| battle-city/wonders/colosseum-ruin | 3d | 7 | wonder-ruins | pending | required, no approval stop | plans/art/battle-city/wonders/colosseum-ruined |
| battle-city/wonders/forbidden_city-ruin | 3d | 7 | wonder-ruins | pending | required, no approval stop | plans/art/battle-city/wonders/forbidden_city-ruined |
| battle-city/wonders/grand_bazaar-ruin | 3d | 7 | wonder-ruins | pending | required, no approval stop | plans/art/battle-city/wonders/grand_bazaar-ruined |
| battle-city/wonders/great_cathedral-ruin | 3d | 7 | wonder-ruins | pending | required, no approval stop | plans/art/battle-city/wonders/great_cathedral-ruined |
| battle-city/wonders/great_library-ruin | 3d | 7 | wonder-ruins | pending | required, no approval stop | plans/art/battle-city/wonders/great_library-ruined |
| battle-city/wonders/great_pyramids-ruin | 3d | 7 | wonder-ruins | pending | required, no approval stop | plans/art/battle-city/wonders/great_pyramids-ruined |
| battle-city/wonders/great_wall-ruin | 3d | 7 | wonder-ruins | pending | required, no approval stop | plans/art/battle-city/wonders/great_wall-ruined |
| battle-city/wonders/hanging_gardens-ruin | 3d | 7 | wonder-ruins | pending | required, no approval stop | plans/art/battle-city/wonders/hanging_gardens-ruined |
| battle-city/wonders/international_exchange-ruin | 3d | 7 | wonder-ruins | pending | required, no approval stop | plans/art/battle-city/wonders/international_exchange-ruined |
| battle-city/wonders/lighthouse-ruin | 3d | 7 | wonder-ruins | pending | required, no approval stop | plans/art/battle-city/wonders/lighthouse-ruined |
| battle-city/wonders/masada-ruin | 3d | 7 | wonder-ruins | pending | required, no approval stop | proposed addition |
| battle-city/wonders/palace_of_versailles-ruin | 3d | 7 | wonder-ruins | pending | required, no approval stop | plans/art/battle-city/wonders/palace_of_versailles-ruined |
| battle-city/wonders/royal_observatory-ruin | 3d | 7 | wonder-ruins | pending | required, no approval stop | plans/art/battle-city/wonders/royal_observatory-ruined |
| battle-city/wonders/solomons_temple-ruin | 3d | 7 | wonder-ruins | pending | required, no approval stop | proposed addition |
| battle-city/wonders/space_program-ruin | 3d | 7 | wonder-ruins | pending | required, no approval stop | plans/art/battle-city/wonders/space_program-ruined |
| fx/arrow-volley-streak | 2d | 7 | effect-sheets | pending | legacy/2D | proposed addition |
| fx/building-burning | 2d | 7 | effect-sheets | pending | legacy/2D | proposed addition |
| fx/cannon-smoke | 2d | 7 | effect-sheets | pending | legacy/2D | proposed addition |
| fx/debris-stone | 2d | 7 | effect-sheets | pending | legacy/2D | proposed addition |
| fx/debris-wood | 2d | 7 | effect-sheets | pending | legacy/2D | proposed addition |
| fx/dust-cavalry | 2d | 7 | effect-sheets | pending | legacy/2D | proposed addition |
| fx/explosion-large | 2d | 7 | effect-sheets | pending | legacy/2D | proposed addition |
| fx/explosion-small | 2d | 7 | effect-sheets | pending | legacy/2D | proposed addition |
| fx/ford-splash | 2d | 7 | effect-sheets | pending | legacy/2D | proposed addition |
| fx/healing-glow | 2d | 7 | effect-sheets | pending | legacy/2D | proposed addition |
| fx/map/ai-battle-smoke | 2d | 7 | effect-sheets | pending | legacy/2D | proposed addition |
| fx/map/burning-town | 2d | 7 | effect-sheets | pending | legacy/2D | plans/art/fx/map/burning-town |
| fx/muzzle-flash | 2d | 7 | effect-sheets | pending | legacy/2D | proposed addition |
| fx/rally-flash | 2d | 7 | effect-sheets | pending | legacy/2D | proposed addition |
| fx/water-splash | 2d | 7 | effect-sheets | pending | legacy/2D | proposed addition |
| nature/vegetation-cold | 3d | 7 | vegetation | pending | required, no approval stop | plans/art/nature/vegetation-cold |
| nature/vegetation-conifer | 3d | 7 | vegetation | pending | required, no approval stop | plans/art/nature/vegetation-conifer |
| nature/vegetation-steppe | 3d | 7 | vegetation | pending | required, no approval stop | plans/art/nature/vegetation-scrub |
| nature/vegetation-tropical | 3d | 7 | vegetation | pending | required, no approval stop | plans/art/nature/vegetation-tropical |
| rts-skins/bronze/americas/barracks | 3d | 7 | building-culture-skins | pending | required, no approval stop | proposed addition |
| rts-skins/bronze/americas/tower | 3d | 7 | building-culture-skins | pending | required, no approval stop | proposed addition |
| rts-skins/bronze/americas/town-hall | 3d | 7 | building-culture-skins | pending | required, no approval stop | proposed addition |
| rts-skins/bronze/americas/trade-post | 3d | 7 | building-culture-skins | pending | required, no approval stop | proposed addition |
| rts-skins/bronze/eastafrica/barracks | 3d | 7 | building-culture-skins | pending | required, no approval stop | proposed addition |
| rts-skins/bronze/eastafrica/tower | 3d | 7 | building-culture-skins | pending | required, no approval stop | proposed addition |
| rts-skins/bronze/eastafrica/town-hall | 3d | 7 | building-culture-skins | pending | required, no approval stop | proposed addition |
| rts-skins/bronze/eastafrica/trade-post | 3d | 7 | building-culture-skins | pending | required, no approval stop | proposed addition |
| rts-skins/bronze/europe/barracks | 3d | 7 | building-culture-skins | pending | required, no approval stop | proposed addition |
| rts-skins/bronze/europe/tower | 3d | 7 | building-culture-skins | pending | required, no approval stop | proposed addition |
| rts-skins/bronze/europe/town-hall | 3d | 7 | building-culture-skins | pending | required, no approval stop | proposed addition |
| rts-skins/bronze/europe/trade-post | 3d | 7 | building-culture-skins | pending | required, no approval stop | proposed addition |
| rts-skins/bronze/indic/barracks | 3d | 7 | building-culture-skins | pending | required, no approval stop | proposed addition |
| rts-skins/bronze/indic/tower | 3d | 7 | building-culture-skins | pending | required, no approval stop | proposed addition |
| rts-skins/bronze/indic/town-hall | 3d | 7 | building-culture-skins | pending | required, no approval stop | proposed addition |
| rts-skins/bronze/indic/trade-post | 3d | 7 | building-culture-skins | pending | required, no approval stop | proposed addition |
| rts-skins/bronze/israelite/barracks | 3d | 7 | building-culture-skins | pending | required, no approval stop | proposed addition |
| rts-skins/bronze/israelite/tower | 3d | 7 | building-culture-skins | pending | required, no approval stop | proposed addition |
| rts-skins/bronze/israelite/town-hall | 3d | 7 | building-culture-skins | pending | required, no approval stop | proposed addition |
| rts-skins/bronze/israelite/trade-post | 3d | 7 | building-culture-skins | pending | required, no approval stop | proposed addition |
| rts-skins/bronze/japan/barracks | 3d | 7 | building-culture-skins | pending | required, no approval stop | proposed addition |
| rts-skins/bronze/japan/tower | 3d | 7 | building-culture-skins | pending | required, no approval stop | proposed addition |
| rts-skins/bronze/japan/town-hall | 3d | 7 | building-culture-skins | pending | required, no approval stop | proposed addition |
| rts-skins/bronze/japan/trade-post | 3d | 7 | building-culture-skins | pending | required, no approval stop | proposed addition |
| rts-skins/bronze/korea/barracks | 3d | 7 | building-culture-skins | pending | required, no approval stop | proposed addition |
| rts-skins/bronze/korea/tower | 3d | 7 | building-culture-skins | pending | required, no approval stop | proposed addition |
| rts-skins/bronze/korea/town-hall | 3d | 7 | building-culture-skins | pending | required, no approval stop | proposed addition |
| rts-skins/bronze/korea/trade-post | 3d | 7 | building-culture-skins | pending | required, no approval stop | proposed addition |
| rts-skins/bronze/levant/barracks | 3d | 7 | building-culture-skins | pending | required, no approval stop | proposed addition |
| rts-skins/bronze/levant/tower | 3d | 7 | building-culture-skins | pending | required, no approval stop | proposed addition |
| rts-skins/bronze/levant/town-hall | 3d | 7 | building-culture-skins | pending | required, no approval stop | proposed addition |
| rts-skins/bronze/levant/trade-post | 3d | 7 | building-culture-skins | pending | required, no approval stop | proposed addition |
| rts-skins/bronze/maghreb/barracks | 3d | 7 | building-culture-skins | pending | required, no approval stop | proposed addition |
| rts-skins/bronze/maghreb/tower | 3d | 7 | building-culture-skins | pending | required, no approval stop | proposed addition |
| rts-skins/bronze/maghreb/town-hall | 3d | 7 | building-culture-skins | pending | required, no approval stop | proposed addition |
| rts-skins/bronze/maghreb/trade-post | 3d | 7 | building-culture-skins | pending | required, no approval stop | proposed addition |
| rts-skins/bronze/monsoon/barracks | 3d | 7 | building-culture-skins | pending | required, no approval stop | proposed addition |
| rts-skins/bronze/monsoon/tower | 3d | 7 | building-culture-skins | pending | required, no approval stop | proposed addition |
| rts-skins/bronze/monsoon/town-hall | 3d | 7 | building-culture-skins | pending | required, no approval stop | proposed addition |
| rts-skins/bronze/monsoon/trade-post | 3d | 7 | building-culture-skins | pending | required, no approval stop | proposed addition |
| rts-skins/bronze/nile/barracks | 3d | 7 | building-culture-skins | pending | required, no approval stop | proposed addition |
| rts-skins/bronze/nile/tower | 3d | 7 | building-culture-skins | pending | required, no approval stop | proposed addition |
| rts-skins/bronze/nile/town-hall | 3d | 7 | building-culture-skins | pending | required, no approval stop | proposed addition |
| rts-skins/bronze/nile/trade-post | 3d | 7 | building-culture-skins | pending | required, no approval stop | proposed addition |
| rts-skins/bronze/pacific/barracks | 3d | 7 | building-culture-skins | pending | required, no approval stop | proposed addition |
| rts-skins/bronze/pacific/tower | 3d | 7 | building-culture-skins | pending | required, no approval stop | proposed addition |
| rts-skins/bronze/pacific/town-hall | 3d | 7 | building-culture-skins | pending | required, no approval stop | proposed addition |
| rts-skins/bronze/pacific/trade-post | 3d | 7 | building-culture-skins | pending | required, no approval stop | proposed addition |
| rts-skins/bronze/sinic/barracks | 3d | 7 | building-culture-skins | pending | required, no approval stop | proposed addition |
| rts-skins/bronze/sinic/tower | 3d | 7 | building-culture-skins | pending | required, no approval stop | proposed addition |
| rts-skins/bronze/sinic/town-hall | 3d | 7 | building-culture-skins | pending | required, no approval stop | proposed addition |
| rts-skins/bronze/sinic/trade-post | 3d | 7 | building-culture-skins | pending | required, no approval stop | proposed addition |
| rts-skins/bronze/steppe/barracks | 3d | 7 | building-culture-skins | pending | required, no approval stop | proposed addition |
| rts-skins/bronze/steppe/tower | 3d | 7 | building-culture-skins | pending | required, no approval stop | proposed addition |
| rts-skins/bronze/steppe/town-hall | 3d | 7 | building-culture-skins | pending | required, no approval stop | proposed addition |
| rts-skins/bronze/steppe/trade-post | 3d | 7 | building-culture-skins | pending | required, no approval stop | proposed addition |
| rts-skins/bronze/westafrica/barracks | 3d | 7 | building-culture-skins | pending | required, no approval stop | proposed addition |
| rts-skins/bronze/westafrica/tower | 3d | 7 | building-culture-skins | pending | required, no approval stop | proposed addition |
| rts-skins/bronze/westafrica/town-hall | 3d | 7 | building-culture-skins | pending | required, no approval stop | proposed addition |
| rts-skins/bronze/westafrica/trade-post | 3d | 7 | building-culture-skins | pending | required, no approval stop | proposed addition |
| rts-skins/classical/americas/barracks | 3d | 7 | building-culture-skins | pending | required, no approval stop | proposed addition |
| rts-skins/classical/americas/tower | 3d | 7 | building-culture-skins | pending | required, no approval stop | proposed addition |
| rts-skins/classical/americas/town-hall | 3d | 7 | building-culture-skins | pending | required, no approval stop | proposed addition |
| rts-skins/classical/americas/trade-post | 3d | 7 | building-culture-skins | pending | required, no approval stop | proposed addition |
| rts-skins/classical/eastafrica/barracks | 3d | 7 | building-culture-skins | pending | required, no approval stop | proposed addition |
| rts-skins/classical/eastafrica/tower | 3d | 7 | building-culture-skins | pending | required, no approval stop | proposed addition |
| rts-skins/classical/eastafrica/town-hall | 3d | 7 | building-culture-skins | pending | required, no approval stop | proposed addition |
| rts-skins/classical/eastafrica/trade-post | 3d | 7 | building-culture-skins | pending | required, no approval stop | proposed addition |
| rts-skins/classical/europe/barracks | 3d | 7 | building-culture-skins | pending | required, no approval stop | proposed addition |
| rts-skins/classical/europe/tower | 3d | 7 | building-culture-skins | pending | required, no approval stop | proposed addition |
| rts-skins/classical/europe/town-hall | 3d | 7 | building-culture-skins | pending | required, no approval stop | proposed addition |
| rts-skins/classical/europe/trade-post | 3d | 7 | building-culture-skins | pending | required, no approval stop | proposed addition |
| rts-skins/classical/indic/barracks | 3d | 7 | building-culture-skins | pending | required, no approval stop | proposed addition |
| rts-skins/classical/indic/tower | 3d | 7 | building-culture-skins | pending | required, no approval stop | proposed addition |
| rts-skins/classical/indic/town-hall | 3d | 7 | building-culture-skins | pending | required, no approval stop | proposed addition |
| rts-skins/classical/indic/trade-post | 3d | 7 | building-culture-skins | pending | required, no approval stop | proposed addition |
| rts-skins/classical/israelite/barracks | 3d | 7 | building-culture-skins | pending | required, no approval stop | proposed addition |
| rts-skins/classical/israelite/tower | 3d | 7 | building-culture-skins | pending | required, no approval stop | proposed addition |
| rts-skins/classical/israelite/town-hall | 3d | 7 | building-culture-skins | pending | required, no approval stop | proposed addition |
| rts-skins/classical/israelite/trade-post | 3d | 7 | building-culture-skins | pending | required, no approval stop | proposed addition |
| rts-skins/classical/japan/barracks | 3d | 7 | building-culture-skins | pending | required, no approval stop | proposed addition |
| rts-skins/classical/japan/tower | 3d | 7 | building-culture-skins | pending | required, no approval stop | proposed addition |
| rts-skins/classical/japan/town-hall | 3d | 7 | building-culture-skins | pending | required, no approval stop | proposed addition |
| rts-skins/classical/japan/trade-post | 3d | 7 | building-culture-skins | pending | required, no approval stop | proposed addition |
| rts-skins/classical/korea/barracks | 3d | 7 | building-culture-skins | pending | required, no approval stop | proposed addition |
| rts-skins/classical/korea/tower | 3d | 7 | building-culture-skins | pending | required, no approval stop | proposed addition |
| rts-skins/classical/korea/town-hall | 3d | 7 | building-culture-skins | pending | required, no approval stop | proposed addition |
| rts-skins/classical/korea/trade-post | 3d | 7 | building-culture-skins | pending | required, no approval stop | proposed addition |
| rts-skins/classical/levant/barracks | 3d | 7 | building-culture-skins | pending | required, no approval stop | proposed addition |
| rts-skins/classical/levant/tower | 3d | 7 | building-culture-skins | pending | required, no approval stop | proposed addition |
| rts-skins/classical/levant/town-hall | 3d | 7 | building-culture-skins | pending | required, no approval stop | proposed addition |
| rts-skins/classical/levant/trade-post | 3d | 7 | building-culture-skins | pending | required, no approval stop | proposed addition |
| rts-skins/classical/maghreb/barracks | 3d | 7 | building-culture-skins | pending | required, no approval stop | proposed addition |
| rts-skins/classical/maghreb/tower | 3d | 7 | building-culture-skins | pending | required, no approval stop | proposed addition |
| rts-skins/classical/maghreb/town-hall | 3d | 7 | building-culture-skins | pending | required, no approval stop | proposed addition |
| rts-skins/classical/maghreb/trade-post | 3d | 7 | building-culture-skins | pending | required, no approval stop | proposed addition |
| rts-skins/classical/monsoon/barracks | 3d | 7 | building-culture-skins | pending | required, no approval stop | proposed addition |
| rts-skins/classical/monsoon/tower | 3d | 7 | building-culture-skins | pending | required, no approval stop | proposed addition |
| rts-skins/classical/monsoon/town-hall | 3d | 7 | building-culture-skins | pending | required, no approval stop | proposed addition |
| rts-skins/classical/monsoon/trade-post | 3d | 7 | building-culture-skins | pending | required, no approval stop | proposed addition |
| rts-skins/classical/nile/barracks | 3d | 7 | building-culture-skins | pending | required, no approval stop | proposed addition |
| rts-skins/classical/nile/tower | 3d | 7 | building-culture-skins | pending | required, no approval stop | proposed addition |
| rts-skins/classical/nile/town-hall | 3d | 7 | building-culture-skins | pending | required, no approval stop | proposed addition |
| rts-skins/classical/nile/trade-post | 3d | 7 | building-culture-skins | pending | required, no approval stop | proposed addition |
| rts-skins/classical/pacific/barracks | 3d | 7 | building-culture-skins | pending | required, no approval stop | proposed addition |
| rts-skins/classical/pacific/tower | 3d | 7 | building-culture-skins | pending | required, no approval stop | proposed addition |
| rts-skins/classical/pacific/town-hall | 3d | 7 | building-culture-skins | pending | required, no approval stop | proposed addition |
| rts-skins/classical/pacific/trade-post | 3d | 7 | building-culture-skins | pending | required, no approval stop | proposed addition |
| rts-skins/classical/sinic/barracks | 3d | 7 | building-culture-skins | pending | required, no approval stop | proposed addition |
| rts-skins/classical/sinic/tower | 3d | 7 | building-culture-skins | pending | required, no approval stop | proposed addition |
| rts-skins/classical/sinic/town-hall | 3d | 7 | building-culture-skins | pending | required, no approval stop | proposed addition |
| rts-skins/classical/sinic/trade-post | 3d | 7 | building-culture-skins | pending | required, no approval stop | proposed addition |
| rts-skins/classical/steppe/barracks | 3d | 7 | building-culture-skins | pending | required, no approval stop | proposed addition |
| rts-skins/classical/steppe/tower | 3d | 7 | building-culture-skins | pending | required, no approval stop | proposed addition |
| rts-skins/classical/steppe/town-hall | 3d | 7 | building-culture-skins | pending | required, no approval stop | proposed addition |
| rts-skins/classical/steppe/trade-post | 3d | 7 | building-culture-skins | pending | required, no approval stop | proposed addition |
| rts-skins/classical/westafrica/barracks | 3d | 7 | building-culture-skins | pending | required, no approval stop | proposed addition |
| rts-skins/classical/westafrica/tower | 3d | 7 | building-culture-skins | pending | required, no approval stop | proposed addition |
| rts-skins/classical/westafrica/town-hall | 3d | 7 | building-culture-skins | pending | required, no approval stop | proposed addition |
| rts-skins/classical/westafrica/trade-post | 3d | 7 | building-culture-skins | pending | required, no approval stop | proposed addition |
| rts-skins/gunpowder/americas/barracks | 3d | 7 | building-culture-skins | pending | required, no approval stop | proposed addition |
| rts-skins/gunpowder/americas/tower | 3d | 7 | building-culture-skins | pending | required, no approval stop | proposed addition |
| rts-skins/gunpowder/americas/town-hall | 3d | 7 | building-culture-skins | pending | required, no approval stop | proposed addition |
| rts-skins/gunpowder/americas/trade-post | 3d | 7 | building-culture-skins | pending | required, no approval stop | proposed addition |
| rts-skins/gunpowder/eastafrica/barracks | 3d | 7 | building-culture-skins | pending | required, no approval stop | proposed addition |
| rts-skins/gunpowder/eastafrica/tower | 3d | 7 | building-culture-skins | pending | required, no approval stop | proposed addition |
| rts-skins/gunpowder/eastafrica/town-hall | 3d | 7 | building-culture-skins | pending | required, no approval stop | proposed addition |
| rts-skins/gunpowder/eastafrica/trade-post | 3d | 7 | building-culture-skins | pending | required, no approval stop | proposed addition |
| rts-skins/gunpowder/europe/barracks | 3d | 7 | building-culture-skins | pending | required, no approval stop | proposed addition |
| rts-skins/gunpowder/europe/tower | 3d | 7 | building-culture-skins | pending | required, no approval stop | proposed addition |
| rts-skins/gunpowder/europe/town-hall | 3d | 7 | building-culture-skins | pending | required, no approval stop | proposed addition |
| rts-skins/gunpowder/europe/trade-post | 3d | 7 | building-culture-skins | pending | required, no approval stop | proposed addition |
| rts-skins/gunpowder/indic/barracks | 3d | 7 | building-culture-skins | pending | required, no approval stop | proposed addition |
| rts-skins/gunpowder/indic/tower | 3d | 7 | building-culture-skins | pending | required, no approval stop | proposed addition |
| rts-skins/gunpowder/indic/town-hall | 3d | 7 | building-culture-skins | pending | required, no approval stop | proposed addition |
| rts-skins/gunpowder/indic/trade-post | 3d | 7 | building-culture-skins | pending | required, no approval stop | proposed addition |
| rts-skins/gunpowder/israelite/barracks | 3d | 7 | building-culture-skins | pending | required, no approval stop | proposed addition |
| rts-skins/gunpowder/israelite/tower | 3d | 7 | building-culture-skins | pending | required, no approval stop | proposed addition |
| rts-skins/gunpowder/israelite/town-hall | 3d | 7 | building-culture-skins | pending | required, no approval stop | proposed addition |
| rts-skins/gunpowder/israelite/trade-post | 3d | 7 | building-culture-skins | pending | required, no approval stop | proposed addition |
| rts-skins/gunpowder/japan/barracks | 3d | 7 | building-culture-skins | pending | required, no approval stop | proposed addition |
| rts-skins/gunpowder/japan/tower | 3d | 7 | building-culture-skins | pending | required, no approval stop | proposed addition |
| rts-skins/gunpowder/japan/town-hall | 3d | 7 | building-culture-skins | pending | required, no approval stop | proposed addition |
| rts-skins/gunpowder/japan/trade-post | 3d | 7 | building-culture-skins | pending | required, no approval stop | proposed addition |
| rts-skins/gunpowder/korea/barracks | 3d | 7 | building-culture-skins | pending | required, no approval stop | proposed addition |
| rts-skins/gunpowder/korea/tower | 3d | 7 | building-culture-skins | pending | required, no approval stop | proposed addition |
| rts-skins/gunpowder/korea/town-hall | 3d | 7 | building-culture-skins | pending | required, no approval stop | proposed addition |
| rts-skins/gunpowder/korea/trade-post | 3d | 7 | building-culture-skins | pending | required, no approval stop | proposed addition |
| rts-skins/gunpowder/levant/barracks | 3d | 7 | building-culture-skins | pending | required, no approval stop | proposed addition |
| rts-skins/gunpowder/levant/tower | 3d | 7 | building-culture-skins | pending | required, no approval stop | proposed addition |
| rts-skins/gunpowder/levant/town-hall | 3d | 7 | building-culture-skins | pending | required, no approval stop | proposed addition |
| rts-skins/gunpowder/levant/trade-post | 3d | 7 | building-culture-skins | pending | required, no approval stop | proposed addition |
| rts-skins/gunpowder/maghreb/barracks | 3d | 7 | building-culture-skins | pending | required, no approval stop | proposed addition |
| rts-skins/gunpowder/maghreb/tower | 3d | 7 | building-culture-skins | pending | required, no approval stop | proposed addition |
| rts-skins/gunpowder/maghreb/town-hall | 3d | 7 | building-culture-skins | pending | required, no approval stop | proposed addition |
| rts-skins/gunpowder/maghreb/trade-post | 3d | 7 | building-culture-skins | pending | required, no approval stop | proposed addition |
| rts-skins/gunpowder/monsoon/barracks | 3d | 7 | building-culture-skins | pending | required, no approval stop | proposed addition |
| rts-skins/gunpowder/monsoon/tower | 3d | 7 | building-culture-skins | pending | required, no approval stop | proposed addition |
| rts-skins/gunpowder/monsoon/town-hall | 3d | 7 | building-culture-skins | pending | required, no approval stop | proposed addition |
| rts-skins/gunpowder/monsoon/trade-post | 3d | 7 | building-culture-skins | pending | required, no approval stop | proposed addition |
| rts-skins/gunpowder/nile/barracks | 3d | 7 | building-culture-skins | pending | required, no approval stop | proposed addition |
| rts-skins/gunpowder/nile/tower | 3d | 7 | building-culture-skins | pending | required, no approval stop | proposed addition |
| rts-skins/gunpowder/nile/town-hall | 3d | 7 | building-culture-skins | pending | required, no approval stop | proposed addition |
| rts-skins/gunpowder/nile/trade-post | 3d | 7 | building-culture-skins | pending | required, no approval stop | proposed addition |
| rts-skins/gunpowder/pacific/barracks | 3d | 7 | building-culture-skins | pending | required, no approval stop | proposed addition |
| rts-skins/gunpowder/pacific/tower | 3d | 7 | building-culture-skins | pending | required, no approval stop | proposed addition |
| rts-skins/gunpowder/pacific/town-hall | 3d | 7 | building-culture-skins | pending | required, no approval stop | proposed addition |
| rts-skins/gunpowder/pacific/trade-post | 3d | 7 | building-culture-skins | pending | required, no approval stop | proposed addition |
| rts-skins/gunpowder/sinic/barracks | 3d | 7 | building-culture-skins | pending | required, no approval stop | proposed addition |
| rts-skins/gunpowder/sinic/tower | 3d | 7 | building-culture-skins | pending | required, no approval stop | proposed addition |
| rts-skins/gunpowder/sinic/town-hall | 3d | 7 | building-culture-skins | pending | required, no approval stop | proposed addition |
| rts-skins/gunpowder/sinic/trade-post | 3d | 7 | building-culture-skins | pending | required, no approval stop | proposed addition |
| rts-skins/gunpowder/steppe/barracks | 3d | 7 | building-culture-skins | pending | required, no approval stop | proposed addition |
| rts-skins/gunpowder/steppe/tower | 3d | 7 | building-culture-skins | pending | required, no approval stop | proposed addition |
| rts-skins/gunpowder/steppe/town-hall | 3d | 7 | building-culture-skins | pending | required, no approval stop | proposed addition |
| rts-skins/gunpowder/steppe/trade-post | 3d | 7 | building-culture-skins | pending | required, no approval stop | proposed addition |
| rts-skins/gunpowder/westafrica/barracks | 3d | 7 | building-culture-skins | pending | required, no approval stop | proposed addition |
| rts-skins/gunpowder/westafrica/tower | 3d | 7 | building-culture-skins | pending | required, no approval stop | proposed addition |
| rts-skins/gunpowder/westafrica/town-hall | 3d | 7 | building-culture-skins | pending | required, no approval stop | proposed addition |
| rts-skins/gunpowder/westafrica/trade-post | 3d | 7 | building-culture-skins | pending | required, no approval stop | proposed addition |
| rts-skins/kingdoms/americas/barracks | 3d | 7 | building-culture-skins | pending | required, no approval stop | proposed addition |
| rts-skins/kingdoms/americas/tower | 3d | 7 | building-culture-skins | pending | required, no approval stop | proposed addition |
| rts-skins/kingdoms/americas/town-hall | 3d | 7 | building-culture-skins | pending | required, no approval stop | proposed addition |
| rts-skins/kingdoms/americas/trade-post | 3d | 7 | building-culture-skins | pending | required, no approval stop | proposed addition |
| rts-skins/kingdoms/eastafrica/barracks | 3d | 7 | building-culture-skins | pending | required, no approval stop | proposed addition |
| rts-skins/kingdoms/eastafrica/tower | 3d | 7 | building-culture-skins | pending | required, no approval stop | proposed addition |
| rts-skins/kingdoms/eastafrica/town-hall | 3d | 7 | building-culture-skins | pending | required, no approval stop | proposed addition |
| rts-skins/kingdoms/eastafrica/trade-post | 3d | 7 | building-culture-skins | pending | required, no approval stop | proposed addition |
| rts-skins/kingdoms/europe/barracks | 3d | 7 | building-culture-skins | pending | required, no approval stop | proposed addition |
| rts-skins/kingdoms/europe/tower | 3d | 7 | building-culture-skins | pending | required, no approval stop | proposed addition |
| rts-skins/kingdoms/europe/town-hall | 3d | 7 | building-culture-skins | pending | required, no approval stop | proposed addition |
| rts-skins/kingdoms/europe/trade-post | 3d | 7 | building-culture-skins | pending | required, no approval stop | proposed addition |
| rts-skins/kingdoms/indic/barracks | 3d | 7 | building-culture-skins | pending | required, no approval stop | proposed addition |
| rts-skins/kingdoms/indic/tower | 3d | 7 | building-culture-skins | pending | required, no approval stop | proposed addition |
| rts-skins/kingdoms/indic/town-hall | 3d | 7 | building-culture-skins | pending | required, no approval stop | proposed addition |
| rts-skins/kingdoms/indic/trade-post | 3d | 7 | building-culture-skins | pending | required, no approval stop | proposed addition |
| rts-skins/kingdoms/israelite/barracks | 3d | 7 | building-culture-skins | pending | required, no approval stop | proposed addition |
| rts-skins/kingdoms/israelite/tower | 3d | 7 | building-culture-skins | pending | required, no approval stop | proposed addition |
| rts-skins/kingdoms/israelite/town-hall | 3d | 7 | building-culture-skins | pending | required, no approval stop | proposed addition |
| rts-skins/kingdoms/israelite/trade-post | 3d | 7 | building-culture-skins | pending | required, no approval stop | proposed addition |
| rts-skins/kingdoms/japan/barracks | 3d | 7 | building-culture-skins | pending | required, no approval stop | proposed addition |
| rts-skins/kingdoms/japan/tower | 3d | 7 | building-culture-skins | pending | required, no approval stop | proposed addition |
| rts-skins/kingdoms/japan/town-hall | 3d | 7 | building-culture-skins | pending | required, no approval stop | proposed addition |
| rts-skins/kingdoms/japan/trade-post | 3d | 7 | building-culture-skins | pending | required, no approval stop | proposed addition |
| rts-skins/kingdoms/korea/barracks | 3d | 7 | building-culture-skins | pending | required, no approval stop | proposed addition |
| rts-skins/kingdoms/korea/tower | 3d | 7 | building-culture-skins | pending | required, no approval stop | proposed addition |
| rts-skins/kingdoms/korea/town-hall | 3d | 7 | building-culture-skins | pending | required, no approval stop | proposed addition |
| rts-skins/kingdoms/korea/trade-post | 3d | 7 | building-culture-skins | pending | required, no approval stop | proposed addition |
| rts-skins/kingdoms/levant/barracks | 3d | 7 | building-culture-skins | pending | required, no approval stop | proposed addition |
| rts-skins/kingdoms/levant/tower | 3d | 7 | building-culture-skins | pending | required, no approval stop | proposed addition |
| rts-skins/kingdoms/levant/town-hall | 3d | 7 | building-culture-skins | pending | required, no approval stop | proposed addition |
| rts-skins/kingdoms/levant/trade-post | 3d | 7 | building-culture-skins | pending | required, no approval stop | proposed addition |
| rts-skins/kingdoms/maghreb/barracks | 3d | 7 | building-culture-skins | pending | required, no approval stop | proposed addition |
| rts-skins/kingdoms/maghreb/tower | 3d | 7 | building-culture-skins | pending | required, no approval stop | proposed addition |
| rts-skins/kingdoms/maghreb/town-hall | 3d | 7 | building-culture-skins | pending | required, no approval stop | proposed addition |
| rts-skins/kingdoms/maghreb/trade-post | 3d | 7 | building-culture-skins | pending | required, no approval stop | proposed addition |
| rts-skins/kingdoms/monsoon/barracks | 3d | 7 | building-culture-skins | pending | required, no approval stop | proposed addition |
| rts-skins/kingdoms/monsoon/tower | 3d | 7 | building-culture-skins | pending | required, no approval stop | proposed addition |
| rts-skins/kingdoms/monsoon/town-hall | 3d | 7 | building-culture-skins | pending | required, no approval stop | proposed addition |
| rts-skins/kingdoms/monsoon/trade-post | 3d | 7 | building-culture-skins | pending | required, no approval stop | proposed addition |
| rts-skins/kingdoms/nile/barracks | 3d | 7 | building-culture-skins | pending | required, no approval stop | proposed addition |
| rts-skins/kingdoms/nile/tower | 3d | 7 | building-culture-skins | pending | required, no approval stop | proposed addition |
| rts-skins/kingdoms/nile/town-hall | 3d | 7 | building-culture-skins | pending | required, no approval stop | proposed addition |
| rts-skins/kingdoms/nile/trade-post | 3d | 7 | building-culture-skins | pending | required, no approval stop | proposed addition |
| rts-skins/kingdoms/pacific/barracks | 3d | 7 | building-culture-skins | pending | required, no approval stop | proposed addition |
| rts-skins/kingdoms/pacific/tower | 3d | 7 | building-culture-skins | pending | required, no approval stop | proposed addition |
| rts-skins/kingdoms/pacific/town-hall | 3d | 7 | building-culture-skins | pending | required, no approval stop | proposed addition |
| rts-skins/kingdoms/pacific/trade-post | 3d | 7 | building-culture-skins | pending | required, no approval stop | proposed addition |
| rts-skins/kingdoms/sinic/barracks | 3d | 7 | building-culture-skins | pending | required, no approval stop | proposed addition |
| rts-skins/kingdoms/sinic/tower | 3d | 7 | building-culture-skins | pending | required, no approval stop | proposed addition |
| rts-skins/kingdoms/sinic/town-hall | 3d | 7 | building-culture-skins | pending | required, no approval stop | proposed addition |
| rts-skins/kingdoms/sinic/trade-post | 3d | 7 | building-culture-skins | pending | required, no approval stop | proposed addition |
| rts-skins/kingdoms/steppe/barracks | 3d | 7 | building-culture-skins | pending | required, no approval stop | proposed addition |
| rts-skins/kingdoms/steppe/tower | 3d | 7 | building-culture-skins | pending | required, no approval stop | proposed addition |
| rts-skins/kingdoms/steppe/town-hall | 3d | 7 | building-culture-skins | pending | required, no approval stop | proposed addition |
| rts-skins/kingdoms/steppe/trade-post | 3d | 7 | building-culture-skins | pending | required, no approval stop | proposed addition |
| rts-skins/kingdoms/westafrica/barracks | 3d | 7 | building-culture-skins | pending | required, no approval stop | proposed addition |
| rts-skins/kingdoms/westafrica/tower | 3d | 7 | building-culture-skins | pending | required, no approval stop | proposed addition |
| rts-skins/kingdoms/westafrica/town-hall | 3d | 7 | building-culture-skins | pending | required, no approval stop | proposed addition |
| rts-skins/kingdoms/westafrica/trade-post | 3d | 7 | building-culture-skins | pending | required, no approval stop | proposed addition |
| rts-skins/modern/americas/barracks | 3d | 7 | building-culture-skins | pending | required, no approval stop | proposed addition |
| rts-skins/modern/americas/tower | 3d | 7 | building-culture-skins | pending | required, no approval stop | proposed addition |
| rts-skins/modern/americas/town-hall | 3d | 7 | building-culture-skins | pending | required, no approval stop | proposed addition |
| rts-skins/modern/americas/trade-post | 3d | 7 | building-culture-skins | pending | required, no approval stop | proposed addition |
| rts-skins/modern/eastafrica/barracks | 3d | 7 | building-culture-skins | pending | required, no approval stop | proposed addition |
| rts-skins/modern/eastafrica/tower | 3d | 7 | building-culture-skins | pending | required, no approval stop | proposed addition |
| rts-skins/modern/eastafrica/town-hall | 3d | 7 | building-culture-skins | pending | required, no approval stop | proposed addition |
| rts-skins/modern/eastafrica/trade-post | 3d | 7 | building-culture-skins | pending | required, no approval stop | proposed addition |
| rts-skins/modern/europe/barracks | 3d | 7 | building-culture-skins | pending | required, no approval stop | proposed addition |
| rts-skins/modern/europe/tower | 3d | 7 | building-culture-skins | pending | required, no approval stop | proposed addition |
| rts-skins/modern/europe/town-hall | 3d | 7 | building-culture-skins | pending | required, no approval stop | proposed addition |
| rts-skins/modern/europe/trade-post | 3d | 7 | building-culture-skins | pending | required, no approval stop | proposed addition |
| rts-skins/modern/indic/barracks | 3d | 7 | building-culture-skins | pending | required, no approval stop | proposed addition |
| rts-skins/modern/indic/tower | 3d | 7 | building-culture-skins | pending | required, no approval stop | proposed addition |
| rts-skins/modern/indic/town-hall | 3d | 7 | building-culture-skins | pending | required, no approval stop | proposed addition |
| rts-skins/modern/indic/trade-post | 3d | 7 | building-culture-skins | pending | required, no approval stop | proposed addition |
| rts-skins/modern/israelite/barracks | 3d | 7 | building-culture-skins | pending | required, no approval stop | proposed addition |
| rts-skins/modern/israelite/tower | 3d | 7 | building-culture-skins | pending | required, no approval stop | proposed addition |
| rts-skins/modern/israelite/town-hall | 3d | 7 | building-culture-skins | pending | required, no approval stop | proposed addition |
| rts-skins/modern/israelite/trade-post | 3d | 7 | building-culture-skins | pending | required, no approval stop | proposed addition |
| rts-skins/modern/japan/barracks | 3d | 7 | building-culture-skins | pending | required, no approval stop | proposed addition |
| rts-skins/modern/japan/tower | 3d | 7 | building-culture-skins | pending | required, no approval stop | proposed addition |
| rts-skins/modern/japan/town-hall | 3d | 7 | building-culture-skins | pending | required, no approval stop | proposed addition |
| rts-skins/modern/japan/trade-post | 3d | 7 | building-culture-skins | pending | required, no approval stop | proposed addition |
| rts-skins/modern/korea/barracks | 3d | 7 | building-culture-skins | pending | required, no approval stop | proposed addition |
| rts-skins/modern/korea/tower | 3d | 7 | building-culture-skins | pending | required, no approval stop | proposed addition |
| rts-skins/modern/korea/town-hall | 3d | 7 | building-culture-skins | pending | required, no approval stop | proposed addition |
| rts-skins/modern/korea/trade-post | 3d | 7 | building-culture-skins | pending | required, no approval stop | proposed addition |
| rts-skins/modern/levant/barracks | 3d | 7 | building-culture-skins | pending | required, no approval stop | proposed addition |
| rts-skins/modern/levant/tower | 3d | 7 | building-culture-skins | pending | required, no approval stop | proposed addition |
| rts-skins/modern/levant/town-hall | 3d | 7 | building-culture-skins | pending | required, no approval stop | proposed addition |
| rts-skins/modern/levant/trade-post | 3d | 7 | building-culture-skins | pending | required, no approval stop | proposed addition |
| rts-skins/modern/maghreb/barracks | 3d | 7 | building-culture-skins | pending | required, no approval stop | proposed addition |
| rts-skins/modern/maghreb/tower | 3d | 7 | building-culture-skins | pending | required, no approval stop | proposed addition |
| rts-skins/modern/maghreb/town-hall | 3d | 7 | building-culture-skins | pending | required, no approval stop | proposed addition |
| rts-skins/modern/maghreb/trade-post | 3d | 7 | building-culture-skins | pending | required, no approval stop | proposed addition |
| rts-skins/modern/monsoon/barracks | 3d | 7 | building-culture-skins | pending | required, no approval stop | proposed addition |
| rts-skins/modern/monsoon/tower | 3d | 7 | building-culture-skins | pending | required, no approval stop | proposed addition |
| rts-skins/modern/monsoon/town-hall | 3d | 7 | building-culture-skins | pending | required, no approval stop | proposed addition |
| rts-skins/modern/monsoon/trade-post | 3d | 7 | building-culture-skins | pending | required, no approval stop | proposed addition |
| rts-skins/modern/nile/barracks | 3d | 7 | building-culture-skins | pending | required, no approval stop | proposed addition |
| rts-skins/modern/nile/tower | 3d | 7 | building-culture-skins | pending | required, no approval stop | proposed addition |
| rts-skins/modern/nile/town-hall | 3d | 7 | building-culture-skins | pending | required, no approval stop | proposed addition |
| rts-skins/modern/nile/trade-post | 3d | 7 | building-culture-skins | pending | required, no approval stop | proposed addition |
| rts-skins/modern/pacific/barracks | 3d | 7 | building-culture-skins | pending | required, no approval stop | proposed addition |
| rts-skins/modern/pacific/tower | 3d | 7 | building-culture-skins | pending | required, no approval stop | proposed addition |
| rts-skins/modern/pacific/town-hall | 3d | 7 | building-culture-skins | pending | required, no approval stop | proposed addition |
| rts-skins/modern/pacific/trade-post | 3d | 7 | building-culture-skins | pending | required, no approval stop | proposed addition |
| rts-skins/modern/sinic/barracks | 3d | 7 | building-culture-skins | pending | required, no approval stop | proposed addition |
| rts-skins/modern/sinic/tower | 3d | 7 | building-culture-skins | pending | required, no approval stop | proposed addition |
| rts-skins/modern/sinic/town-hall | 3d | 7 | building-culture-skins | pending | required, no approval stop | proposed addition |
| rts-skins/modern/sinic/trade-post | 3d | 7 | building-culture-skins | pending | required, no approval stop | proposed addition |
| rts-skins/modern/steppe/barracks | 3d | 7 | building-culture-skins | pending | required, no approval stop | proposed addition |
| rts-skins/modern/steppe/tower | 3d | 7 | building-culture-skins | pending | required, no approval stop | proposed addition |
| rts-skins/modern/steppe/town-hall | 3d | 7 | building-culture-skins | pending | required, no approval stop | proposed addition |
| rts-skins/modern/steppe/trade-post | 3d | 7 | building-culture-skins | pending | required, no approval stop | proposed addition |
| rts-skins/modern/westafrica/barracks | 3d | 7 | building-culture-skins | pending | required, no approval stop | proposed addition |
| rts-skins/modern/westafrica/tower | 3d | 7 | building-culture-skins | pending | required, no approval stop | proposed addition |
| rts-skins/modern/westafrica/town-hall | 3d | 7 | building-culture-skins | pending | required, no approval stop | proposed addition |
| rts-skins/modern/westafrica/trade-post | 3d | 7 | building-culture-skins | pending | required, no approval stop | proposed addition |
| ships/carrier-modern | 3d | 7 | ships | pending | required, no approval stop | plans/art/ships/carrier-modern |
| ships/raider-classical | 3d | 7 | ships | pending | required, no approval stop | plans/art/ships/raider-classical |
| ships/raider-gunpowder | 3d | 7 | ships | pending | required, no approval stop | plans/art/ships/raider-gunpowder |
| ships/raider-kingdoms | 3d | 7 | ships | pending | required, no approval stop | plans/art/ships/raider-kingdoms |
| ships/raider-modern | 3d | 7 | ships | pending | required, no approval stop | plans/art/ships/raider-modern |
| ships/transport-classical | 3d | 7 | ships | pending | required, no approval stop | plans/art/props/landing-ancient; plans/art/ships/transport-classical |
| ships/transport-gunpowder | 3d | 7 | ships | pending | required, no approval stop | plans/art/ships/transport-gunpowder |
| ships/transport-kingdoms | 3d | 7 | ships | pending | required, no approval stop | plans/art/props/landing-middle; plans/art/ships/transport-kingdoms |
| ships/transport-modern | 3d | 7 | ships | pending | required, no approval stop | plans/art/props/landing-modern; plans/art/ships/transport-modern |
| ships/warship-bronze | 3d | 7 | ships | built_awaiting_validation_upload | legacy/2D | plans/art/ships/warship-bronze |
| ships/warship-classical | 3d | 7 | ships | built_awaiting_validation_upload | legacy/2D | plans/art/ships/warship-classical |
| ships/warship-gunpowder | 3d | 7 | ships | pending | required, no approval stop | plans/art/ships/warship-gunpowder |
| ships/warship-kingdoms | 3d | 7 | ships | built_awaiting_validation_upload | legacy/2D | plans/art/ships/warship-kingdoms |
| ships/warship-modern | 3d | 7 | ships | pending | required, no approval stop | plans/art/ships/warship-modern |
| fog/last-seen-lut | 2d | 8 | M01-M29-2d | pending | legacy/2D | plans/art/fog/last-seen-lut |
| fog/style-frame | 2d | 8 | M01-M29-2d | pending | legacy/2D | plans/art/fog/style-frame |
| fog/unexplored-edge | 2d | 8 | M01-M29-2d | pending | legacy/2D | plans/art/fog/unexplored-edge |
| fog/unexplored-mask | 2d | 8 | M01-M29-2d | pending | legacy/2D | plans/art/fog/unexplored-mask |
| fx/projectiles-bronze | 2d | 8 | M01-M29-2d | pending | legacy/2D | plans/art/fx/projectiles-bronze |
| fx/projectiles-classical | 2d | 8 | M01-M29-2d | pending | legacy/2D | plans/art/fx/projectiles-classical |
| fx/projectiles-gunpowder | 2d | 8 | M01-M29-2d | pending | legacy/2D | plans/art/fx/projectiles-gunpowder |
| fx/projectiles-kingdoms | 2d | 8 | M01-M29-2d | pending | legacy/2D | plans/art/fx/projectiles-kingdoms |
| fx/projectiles-modern | 2d | 8 | M01-M29-2d | pending | legacy/2D | plans/art/fx/projectiles-modern |
| icons/battle/build-aid-post | 2d | 8 | M01-M29-2d | pending | legacy/2D | plans/art/icons/battle/build-aid-post |
| icons/battle/build-barracks | 2d | 8 | M01-M29-2d | pending | legacy/2D | plans/art/icons/battle/build-barracks |
| icons/battle/build-expedition-camp | 2d | 8 | M01-M29-2d | pending | legacy/2D | plans/art/icons/battle/build-expedition-camp |
| icons/battle/build-farm-plot | 2d | 8 | M01-M29-2d | pending | legacy/2D | plans/art/icons/battle/build-farm-plot |
| icons/battle/build-food-depot | 2d | 8 | M01-M29-2d | pending | legacy/2D | plans/art/icons/battle/build-food-depot |
| icons/battle/build-gate | 2d | 8 | M01-M29-2d | pending | legacy/2D | plans/art/icons/battle/build-gate |
| icons/battle/build-house | 2d | 8 | M01-M29-2d | pending | legacy/2D | plans/art/icons/battle/build-house |
| icons/battle/build-materials-yard | 2d | 8 | M01-M29-2d | pending | legacy/2D | plans/art/icons/battle/build-materials-yard |
| icons/battle/build-mine | 2d | 8 | M01-M29-2d | pending | legacy/2D | plans/art/icons/battle/build-mine |
| icons/battle/build-range | 2d | 8 | M01-M29-2d | pending | legacy/2D | plans/art/icons/battle/build-range |
| icons/battle/build-siege-workshop | 2d | 8 | M01-M29-2d | pending | legacy/2D | plans/art/icons/battle/build-siege-workshop |
| icons/battle/build-stable | 2d | 8 | M01-M29-2d | pending | legacy/2D | plans/art/icons/battle/build-stable |
| icons/battle/build-tower | 2d | 8 | M01-M29-2d | pending | legacy/2D | plans/art/icons/battle/build-tower |
| icons/battle/build-town-hall | 2d | 8 | M01-M29-2d | pending | legacy/2D | plans/art/icons/battle/build-town-hall |
| icons/battle/build-trade-post | 2d | 8 | M01-M29-2d | pending | legacy/2D | plans/art/icons/battle/build-trade-post |
| icons/battle/build-wall | 2d | 8 | M01-M29-2d | pending | legacy/2D | plans/art/icons/battle/build-wall |
| icons/battle/captives | 2d | 8 | M01-M29-2d | pending | legacy/2D | plans/art/icons/battle/captives |
| icons/battle/cmd-attack-move | 2d | 8 | M01-M29-2d | pending | legacy/2D | plans/art/icons/battle/cmd-attack-move |
| icons/battle/cmd-build | 2d | 8 | M01-M29-2d | pending | legacy/2D | plans/art/icons/battle/cmd-build |
| icons/battle/cmd-formation-column | 2d | 8 | M01-M29-2d | pending | legacy/2D | plans/art/icons/battle/cmd-formation-column |
| icons/battle/cmd-formation-line | 2d | 8 | M01-M29-2d | pending | legacy/2D | plans/art/icons/battle/cmd-formation-line |
| icons/battle/cmd-formation-wedge | 2d | 8 | M01-M29-2d | pending | legacy/2D | plans/art/icons/battle/cmd-formation-wedge |
| icons/battle/cmd-gather | 2d | 8 | M01-M29-2d | pending | legacy/2D | plans/art/icons/battle/cmd-gather |
| icons/battle/cmd-hold | 2d | 8 | M01-M29-2d | pending | legacy/2D | plans/art/icons/battle/cmd-hold |
| icons/battle/cmd-patrol | 2d | 8 | M01-M29-2d | pending | legacy/2D | plans/art/icons/battle/cmd-patrol |
| icons/battle/cmd-rally | 2d | 8 | M01-M29-2d | pending | legacy/2D | plans/art/icons/battle/cmd-rally |
| icons/battle/cmd-repair | 2d | 8 | M01-M29-2d | pending | legacy/2D | plans/art/icons/battle/cmd-repair |
| icons/battle/cmd-retreat | 2d | 8 | M01-M29-2d | pending | legacy/2D | plans/art/icons/battle/cmd-retreat |
| icons/battle/cmd-return-goods | 2d | 8 | M01-M29-2d | pending | legacy/2D | plans/art/icons/battle/cmd-return-goods |
| icons/battle/cmd-stop | 2d | 8 | M01-M29-2d | pending | legacy/2D | plans/art/icons/battle/cmd-stop |
| icons/battle/intel | 2d | 8 | M01-M29-2d | pending | legacy/2D | plans/art/icons/battle/intel |
| icons/battle/kind-field | 2d | 8 | M01-M29-2d | pending | legacy/2D | plans/art/icons/battle/kind-field |
| icons/battle/kind-landing | 2d | 8 | M01-M29-2d | pending | legacy/2D | plans/art/icons/battle/kind-landing |
| icons/battle/kind-raid | 2d | 8 | M01-M29-2d | pending | legacy/2D | plans/art/icons/battle/kind-raid |
| icons/battle/kind-sack | 2d | 8 | M01-M29-2d | pending | legacy/2D | plans/art/icons/battle/kind-sack |
| icons/battle/kind-sally | 2d | 8 | M01-M29-2d | pending | legacy/2D | plans/art/icons/battle/kind-sally |
| icons/battle/kind-sea | 2d | 8 | M01-M29-2d | pending | legacy/2D | plans/art/icons/battle/kind-sea |
| icons/battle/kind-siege | 2d | 8 | M01-M29-2d | pending | legacy/2D | plans/art/icons/battle/kind-siege |
| icons/battle/mode-auto | 2d | 8 | M01-M29-2d | pending | legacy/2D | plans/art/icons/battle/mode-auto |
| icons/battle/mode-command | 2d | 8 | M01-M29-2d | pending | legacy/2D | plans/art/icons/battle/mode-command |
| icons/battle/outcome-city-taken | 2d | 8 | M01-M29-2d | pending | legacy/2D | plans/art/icons/battle/outcome-city-taken |
| icons/battle/outcome-defeat | 2d | 8 | M01-M29-2d | pending | legacy/2D | plans/art/icons/battle/outcome-defeat |
| icons/battle/outcome-victory | 2d | 8 | M01-M29-2d | pending | legacy/2D | plans/art/icons/battle/outcome-victory |
| icons/battle/outcome-withdrawal | 2d | 8 | M01-M29-2d | pending | legacy/2D | plans/art/icons/battle/outcome-withdrawal |
| icons/battle/population | 2d | 8 | M01-M29-2d | pending | legacy/2D | plans/art/icons/battle/population |
| icons/battle/ransom | 2d | 8 | M01-M29-2d | pending | legacy/2D | plans/art/icons/battle/ransom |
| icons/battle/recruit-auxiliary | 2d | 8 | M01-M29-2d | pending | legacy/2D | plans/art/icons/battle/recruit-auxiliary |
| icons/battle/recruit-regular | 2d | 8 | M01-M29-2d | pending | legacy/2D | plans/art/icons/battle/recruit-regular |
| icons/battle/reinforcements | 2d | 8 | M01-M29-2d | pending | legacy/2D | plans/art/icons/battle/reinforcements |
| icons/battle/release | 2d | 8 | M01-M29-2d | pending | legacy/2D | plans/art/icons/battle/release |
| icons/battle/resource-food | 2d | 8 | M01-M29-2d | pending | legacy/2D | plans/art/icons/battle/resource-food |
| icons/battle/resource-gold | 2d | 8 | M01-M29-2d | pending | legacy/2D | plans/art/icons/battle/resource-gold |
| icons/battle/resource-materials | 2d | 8 | M01-M29-2d | pending | legacy/2D | plans/art/icons/battle/resource-materials |
| icons/battle/war-score | 2d | 8 | M01-M29-2d | pending | legacy/2D | plans/art/icons/battle/war-score |
| icons/independents/fortress | 2d | 8 | M01-M29-2d | pending | legacy/2D | plans/art/icons/independents/fortress |
| icons/independents/grudge | 2d | 8 | M01-M29-2d | pending | legacy/2D | plans/art/icons/independents/grudge |
| icons/independents/hire-mercenaries | 2d | 8 | M01-M29-2d | pending | legacy/2D | plans/art/icons/independents/hire-mercenaries |
| icons/independents/mercantile | 2d | 8 | M01-M29-2d | pending | legacy/2D | plans/art/icons/independents/mercantile |
| icons/independents/mercenary-contract | 2d | 8 | M01-M29-2d | pending | legacy/2D | plans/art/icons/independents/mercenary-contract |
| icons/independents/raid-torch | 2d | 8 | M01-M29-2d | pending | legacy/2D | plans/art/icons/independents/raid-torch |
| icons/independents/raiders | 2d | 8 | M01-M29-2d | pending | legacy/2D | plans/art/icons/independents/raiders |
| icons/independents/raze | 2d | 8 | M01-M29-2d | pending | legacy/2D | plans/art/icons/independents/raze |
| icons/independents/submit | 2d | 8 | M01-M29-2d | pending | legacy/2D | plans/art/icons/independents/submit |
| icons/independents/trade-pact | 2d | 8 | M01-M29-2d | pending | legacy/2D | plans/art/icons/independents/trade-pact |
| icons/independents/tribal | 2d | 8 | M01-M29-2d | pending | legacy/2D | plans/art/icons/independents/tribal |
| icons/independents/tribute | 2d | 8 | M01-M29-2d | pending | legacy/2D | plans/art/icons/independents/tribute |
| icons/markers/last-seen | 2d | 8 | M01-M29-2d | pending | legacy/2D | plans/art/icons/markers/last-seen |
| icons/markers/sea-battle | 2d | 8 | M01-M29-2d | pending | legacy/2D | plans/art/icons/markers/sea-battle |
| icons/markers/siege | 2d | 8 | M01-M29-2d | pending | legacy/2D | plans/art/icons/markers/siege |
| icons/markers/unknown-people | 2d | 8 | M01-M29-2d | pending | legacy/2D | plans/art/icons/markers/unknown-people |
| icons/regions/africa | 2d | 8 | M01-M29-2d | pending | legacy/2D | plans/art/icons/regions/africa |
| icons/regions/americas | 2d | 8 | M01-M29-2d | pending | legacy/2D | plans/art/icons/regions/americas |
| icons/regions/asia | 2d | 8 | M01-M29-2d | pending | legacy/2D | plans/art/icons/regions/asia |
| icons/regions/europe | 2d | 8 | M01-M29-2d | pending | legacy/2D | plans/art/icons/regions/europe |
| icons/regions/neareast | 2d | 8 | M01-M29-2d | pending | legacy/2D | plans/art/icons/regions/neareast |
| icons/regions/oceania | 2d | 8 | M01-M29-2d | pending | legacy/2D | plans/art/icons/regions/oceania |
| icons/themes/americas | 2d | 8 | M01-M29-2d | pending | legacy/2D | plans/art/icons/themes/americas |
| icons/themes/eastafrica | 2d | 8 | M01-M29-2d | pending | legacy/2D | plans/art/icons/themes/eastafrica |
| icons/themes/europe | 2d | 8 | M01-M29-2d | pending | legacy/2D | plans/art/icons/themes/europe |
| icons/themes/indic | 2d | 8 | M01-M29-2d | pending | legacy/2D | plans/art/icons/themes/indic |
| icons/themes/israelite | 2d | 8 | M01-M29-2d | pending | legacy/2D | plans/art/icons/themes/israelite |
| icons/themes/japan | 2d | 8 | M01-M29-2d | pending | legacy/2D | plans/art/icons/themes/japan |
| icons/themes/korea | 2d | 8 | M01-M29-2d | pending | legacy/2D | plans/art/icons/themes/korea |
| icons/themes/levant | 2d | 8 | M01-M29-2d | pending | legacy/2D | plans/art/icons/themes/levant |
| icons/themes/maghreb | 2d | 8 | M01-M29-2d | pending | legacy/2D | plans/art/icons/themes/maghreb |
| icons/themes/monsoon | 2d | 8 | M01-M29-2d | pending | legacy/2D | plans/art/icons/themes/monsoon |
| icons/themes/nile | 2d | 8 | M01-M29-2d | pending | legacy/2D | plans/art/icons/themes/nile |
| icons/themes/pacific | 2d | 8 | M01-M29-2d | pending | legacy/2D | plans/art/icons/themes/pacific |
| icons/themes/sinic | 2d | 8 | M01-M29-2d | pending | legacy/2D | plans/art/icons/themes/sinic |
| icons/themes/steppe | 2d | 8 | M01-M29-2d | pending | legacy/2D | plans/art/icons/themes/steppe |
| icons/themes/westafrica | 2d | 8 | M01-M29-2d | pending | legacy/2D | plans/art/icons/themes/westafrica |
| icons/units/worker | 2d | 8 | M01-M29-2d | pending | legacy/2D | plans/art/icons/units/worker |
| legacy/icons/ages/bronze | 2d | 8 | retained-legacy | historically_uploaded_quality_accepted | legacy/2D | plans/art/icons/ages/bronze |
| legacy/icons/ages/classical | 2d | 8 | retained-legacy | historically_uploaded_quality_accepted | legacy/2D | plans/art/icons/ages/classical |
| legacy/icons/ages/gunpowder | 2d | 8 | retained-legacy | historically_uploaded_quality_accepted | legacy/2D | plans/art/icons/ages/gunpowder |
| legacy/icons/ages/kingdoms | 2d | 8 | retained-legacy | historically_uploaded_quality_accepted | legacy/2D | plans/art/icons/ages/kingdoms |
| legacy/icons/ages/modern | 2d | 8 | retained-legacy | historically_uploaded_quality_accepted | legacy/2D | plans/art/icons/ages/modern |
| legacy/icons/buildings/bank | 2d | 8 | retained-legacy | historically_uploaded_quality_accepted | legacy/2D | plans/art/icons/buildings/bank |
| legacy/icons/buildings/barracks | 2d | 8 | retained-legacy | historically_uploaded_quality_accepted | legacy/2D | plans/art/icons/buildings/barracks |
| legacy/icons/buildings/bazaar | 2d | 8 | retained-legacy | historically_uploaded_quality_accepted | legacy/2D | plans/art/icons/buildings/bazaar |
| legacy/icons/buildings/carrier_dock | 2d | 8 | retained-legacy | historically_uploaded_quality_accepted | legacy/2D | plans/art/icons/buildings/carrier_dock |
| legacy/icons/buildings/cathedral | 2d | 8 | retained-legacy | pending | legacy/2D | plans/art/icons/buildings/cathedral |
| legacy/icons/buildings/civic_center | 2d | 8 | retained-legacy | historically_uploaded_quality_accepted | legacy/2D | plans/art/icons/buildings/civic_center |
| legacy/icons/buildings/copper_mine | 2d | 8 | retained-legacy | historically_uploaded_quality_accepted | legacy/2D | plans/art/icons/buildings/copper_mine |
| legacy/icons/buildings/crop_rotation_farm | 2d | 8 | retained-legacy | historically_uploaded_quality_accepted | legacy/2D | plans/art/icons/buildings/crop_rotation_farm |
| legacy/icons/buildings/drill_yard | 2d | 8 | retained-legacy | historically_uploaded_quality_accepted | legacy/2D | plans/art/icons/buildings/drill_yard |
| legacy/icons/buildings/factory | 2d | 8 | retained-legacy | historically_uploaded_quality_accepted | legacy/2D | plans/art/icons/buildings/factory |
| legacy/icons/buildings/farm_estate | 2d | 8 | retained-legacy | historically_uploaded_quality_accepted | legacy/2D | plans/art/icons/buildings/farm_estate |
| legacy/icons/buildings/granary | 2d | 8 | retained-legacy | historically_uploaded_quality_accepted | legacy/2D | plans/art/icons/buildings/granary |
| legacy/icons/buildings/harbor | 2d | 8 | retained-legacy | historically_uploaded_quality_accepted | legacy/2D | plans/art/icons/buildings/harbor |
| legacy/icons/buildings/highway | 2d | 8 | retained-legacy | historically_uploaded_quality_accepted | legacy/2D | plans/art/icons/buildings/highway |
| legacy/icons/buildings/iron_foundry | 2d | 8 | retained-legacy | historically_uploaded_quality_accepted | legacy/2D | plans/art/icons/buildings/iron_foundry |
| legacy/icons/buildings/irrigation | 2d | 8 | retained-legacy | historically_uploaded_quality_accepted | legacy/2D | plans/art/icons/buildings/irrigation |
| legacy/icons/buildings/library | 2d | 8 | retained-legacy | historically_uploaded_quality_accepted | legacy/2D | plans/art/icons/buildings/library |
| legacy/icons/buildings/manufactory | 2d | 8 | retained-legacy | historically_uploaded_quality_accepted | legacy/2D | plans/art/icons/buildings/manufactory |
| legacy/icons/buildings/market | 2d | 8 | retained-legacy | historically_uploaded_quality_accepted | legacy/2D | plans/art/icons/buildings/market |
| legacy/icons/buildings/mechanized_farm | 2d | 8 | retained-legacy | historically_uploaded_quality_accepted | legacy/2D | plans/art/icons/buildings/mechanized_farm |
| legacy/icons/buildings/military_academy | 2d | 8 | retained-legacy | historically_uploaded_quality_accepted | legacy/2D | plans/art/icons/buildings/military_academy |
| legacy/icons/buildings/naval_base | 2d | 8 | retained-legacy | historically_uploaded_quality_accepted | legacy/2D | plans/art/icons/buildings/naval_base |
| legacy/icons/buildings/oil_well | 2d | 8 | retained-legacy | historically_uploaded_quality_accepted | legacy/2D | plans/art/icons/buildings/oil_well |
| legacy/icons/buildings/rail_depot | 2d | 8 | retained-legacy | historically_uploaded_quality_accepted | legacy/2D | plans/art/icons/buildings/rail_depot |
| legacy/icons/buildings/research_lab | 2d | 8 | retained-legacy | historically_uploaded_quality_accepted | legacy/2D | plans/art/icons/buildings/research_lab |
| legacy/icons/buildings/road_post | 2d | 8 | retained-legacy | historically_uploaded_quality_accepted | legacy/2D | plans/art/icons/buildings/road_post |
| legacy/icons/buildings/scriptorium | 2d | 8 | retained-legacy | historically_uploaded_quality_accepted | legacy/2D | plans/art/icons/buildings/scriptorium |
| legacy/icons/buildings/shipyard | 2d | 8 | retained-legacy | historically_uploaded_quality_accepted | legacy/2D | plans/art/icons/buildings/shipyard |
| legacy/icons/buildings/shrine | 2d | 8 | retained-legacy | historically_uploaded_quality_accepted | legacy/2D | plans/art/icons/buildings/shrine |
| legacy/icons/buildings/stock_exchange | 2d | 8 | retained-legacy | historically_uploaded_quality_accepted | legacy/2D | plans/art/icons/buildings/stock_exchange |
| legacy/icons/buildings/temple | 2d | 8 | retained-legacy | historically_uploaded_quality_accepted | legacy/2D | plans/art/icons/buildings/temple |
| legacy/icons/buildings/university | 2d | 8 | retained-legacy | historically_uploaded_quality_accepted | legacy/2D | plans/art/icons/buildings/university |
| legacy/icons/buildings/war_college | 2d | 8 | retained-legacy | historically_uploaded_quality_accepted | legacy/2D | plans/art/icons/buildings/war_college |
| legacy/icons/buildings/workshop | 2d | 8 | retained-legacy | historically_uploaded_quality_accepted | legacy/2D | plans/art/icons/buildings/workshop |
| legacy/icons/cities/city-big-bronze | 2d | 8 | retained-legacy | historically_uploaded_quality_accepted | legacy/2D | plans/art/icons/cities/city-big-bronze |
| legacy/icons/cities/city-big-classical | 2d | 8 | retained-legacy | historically_uploaded_quality_accepted | legacy/2D | plans/art/icons/cities/city-big-classical |
| legacy/icons/cities/city-big-gunpowder | 2d | 8 | retained-legacy | historically_uploaded_quality_accepted | legacy/2D | plans/art/icons/cities/city-big-gunpowder |
| legacy/icons/cities/city-big-kingdoms | 2d | 8 | retained-legacy | historically_uploaded_quality_accepted | legacy/2D | plans/art/icons/cities/city-big-kingdoms |
| legacy/icons/cities/city-big-modern | 2d | 8 | retained-legacy | historically_uploaded_quality_accepted | legacy/2D | plans/art/icons/cities/city-big-modern |
| legacy/icons/cities/city-medium-bronze | 2d | 8 | retained-legacy | historically_uploaded_quality_accepted | legacy/2D | plans/art/icons/cities/city-medium-bronze |
| legacy/icons/cities/city-medium-classical | 2d | 8 | retained-legacy | historically_uploaded_quality_accepted | legacy/2D | plans/art/icons/cities/city-medium-classical |
| legacy/icons/cities/city-medium-gunpowder | 2d | 8 | retained-legacy | historically_uploaded_quality_accepted | legacy/2D | plans/art/icons/cities/city-medium-gunpowder |
| legacy/icons/cities/city-medium-kingdoms | 2d | 8 | retained-legacy | historically_uploaded_quality_accepted | legacy/2D | plans/art/icons/cities/city-medium-kingdoms |
| legacy/icons/cities/city-medium-modern | 2d | 8 | retained-legacy | historically_uploaded_quality_accepted | legacy/2D | plans/art/icons/cities/city-medium-modern |
| legacy/icons/cities/city-small-bronze | 2d | 8 | retained-legacy | historically_uploaded_quality_accepted | legacy/2D | plans/art/icons/cities/city-small-bronze |
| legacy/icons/cities/city-small-classical | 2d | 8 | retained-legacy | historically_uploaded_quality_accepted | legacy/2D | plans/art/icons/cities/city-small-classical |
| legacy/icons/cities/city-small-gunpowder | 2d | 8 | retained-legacy | historically_uploaded_quality_accepted | legacy/2D | plans/art/icons/cities/city-small-gunpowder |
| legacy/icons/cities/city-small-kingdoms | 2d | 8 | retained-legacy | historically_uploaded_quality_accepted | legacy/2D | plans/art/icons/cities/city-small-kingdoms |
| legacy/icons/cities/city-small-modern | 2d | 8 | retained-legacy | historically_uploaded_quality_accepted | legacy/2D | plans/art/icons/cities/city-small-modern |
| legacy/icons/improvements/camp | 2d | 8 | retained-legacy | historically_uploaded_quality_accepted | legacy/2D | plans/art/icons/improvements/camp |
| legacy/icons/improvements/farm | 2d | 8 | retained-legacy | historically_uploaded_quality_accepted | legacy/2D | plans/art/icons/improvements/farm |
| legacy/icons/improvements/fishing_boats | 2d | 8 | retained-legacy | historically_uploaded_quality_accepted | legacy/2D | plans/art/icons/improvements/fishing_boats |
| legacy/icons/improvements/fort | 2d | 8 | retained-legacy | historically_uploaded_quality_accepted | legacy/2D | plans/art/icons/improvements/fort |
| legacy/icons/improvements/lumber_camp | 2d | 8 | retained-legacy | historically_uploaded_quality_accepted | legacy/2D | plans/art/icons/improvements/lumber_camp |
| legacy/icons/improvements/mine | 2d | 8 | retained-legacy | historically_uploaded_quality_accepted | legacy/2D | plans/art/icons/improvements/mine |
| legacy/icons/improvements/oil_well | 2d | 8 | retained-legacy | historically_uploaded_quality_accepted | legacy/2D | plans/art/icons/improvements/oil_well |
| legacy/icons/improvements/pasture | 2d | 8 | retained-legacy | historically_uploaded_quality_accepted | legacy/2D | plans/art/icons/improvements/pasture |
| legacy/icons/improvements/plantation | 2d | 8 | retained-legacy | historically_uploaded_quality_accepted | legacy/2D | plans/art/icons/improvements/plantation |
| legacy/icons/improvements/quarry | 2d | 8 | retained-legacy | historically_uploaded_quality_accepted | legacy/2D | plans/art/icons/improvements/quarry |
| legacy/icons/improvements/road | 2d | 8 | retained-legacy | historically_uploaded_quality_accepted | legacy/2D | plans/art/icons/improvements/road |
| legacy/icons/markers/battle | 2d | 8 | retained-legacy | historically_uploaded_quality_accepted | legacy/2D | plans/art/icons/markers/battle |
| legacy/icons/markers/capital | 2d | 8 | retained-legacy | historically_uploaded_quality_accepted | legacy/2D | plans/art/icons/markers/capital |
| legacy/icons/markers/event | 2d | 8 | retained-legacy | historically_uploaded_quality_accepted | legacy/2D | plans/art/icons/markers/event |
| legacy/icons/markers/wonder | 2d | 8 | retained-legacy | historically_uploaded_quality_accepted | legacy/2D | plans/art/icons/markers/wonder |
| legacy/icons/resources/bananas | 2d | 8 | retained-legacy | historically_uploaded_quality_accepted | legacy/2D | plans/art/icons/resources/bananas |
| legacy/icons/resources/cattle | 2d | 8 | retained-legacy | historically_uploaded_quality_accepted | legacy/2D | plans/art/icons/resources/cattle |
| legacy/icons/resources/coal | 2d | 8 | retained-legacy | historically_uploaded_quality_accepted | legacy/2D | plans/art/icons/resources/coal |
| legacy/icons/resources/copper | 2d | 8 | retained-legacy | historically_uploaded_quality_accepted | legacy/2D | plans/art/icons/resources/copper |
| legacy/icons/resources/cotton | 2d | 8 | retained-legacy | historically_uploaded_quality_accepted | legacy/2D | plans/art/icons/resources/cotton |
| legacy/icons/resources/dates | 2d | 8 | retained-legacy | historically_uploaded_quality_accepted | legacy/2D | plans/art/icons/resources/dates |
| legacy/icons/resources/deer | 2d | 8 | retained-legacy | historically_uploaded_quality_accepted | legacy/2D | plans/art/icons/resources/deer |
| legacy/icons/resources/dyes | 2d | 8 | retained-legacy | historically_uploaded_quality_accepted | legacy/2D | plans/art/icons/resources/dyes |
| legacy/icons/resources/fish | 2d | 8 | retained-legacy | historically_uploaded_quality_accepted | legacy/2D | plans/art/icons/resources/fish |
| legacy/icons/resources/furs | 2d | 8 | retained-legacy | historically_uploaded_quality_accepted | legacy/2D | plans/art/icons/resources/furs |
| legacy/icons/resources/gems | 2d | 8 | retained-legacy | historically_uploaded_quality_accepted | legacy/2D | plans/art/icons/resources/gems |
| legacy/icons/resources/gold | 2d | 8 | retained-legacy | historically_uploaded_quality_accepted | legacy/2D | plans/art/icons/resources/gold |
| legacy/icons/resources/honey | 2d | 8 | retained-legacy | historically_uploaded_quality_accepted | legacy/2D | plans/art/icons/resources/honey |
| legacy/icons/resources/horses | 2d | 8 | retained-legacy | historically_uploaded_quality_accepted | legacy/2D | plans/art/icons/resources/horses |
| legacy/icons/resources/incense | 2d | 8 | retained-legacy | historically_uploaded_quality_accepted | legacy/2D | plans/art/icons/resources/incense |
| legacy/icons/resources/iron | 2d | 8 | retained-legacy | historically_uploaded_quality_accepted | legacy/2D | plans/art/icons/resources/iron |
| legacy/icons/resources/oil | 2d | 8 | retained-legacy | historically_uploaded_quality_accepted | legacy/2D | plans/art/icons/resources/oil |
| legacy/icons/resources/olives | 2d | 8 | retained-legacy | historically_uploaded_quality_accepted | legacy/2D | plans/art/icons/resources/olives |
| legacy/icons/resources/papyrus | 2d | 8 | retained-legacy | historically_uploaded_quality_accepted | legacy/2D | plans/art/icons/resources/papyrus |
| legacy/icons/resources/reeds | 2d | 8 | retained-legacy | historically_uploaded_quality_accepted | legacy/2D | plans/art/icons/resources/reeds |
| legacy/icons/resources/rice | 2d | 8 | retained-legacy | historically_uploaded_quality_accepted | legacy/2D | plans/art/icons/resources/rice |
| legacy/icons/resources/rubber | 2d | 8 | retained-legacy | historically_uploaded_quality_accepted | legacy/2D | plans/art/icons/resources/rubber |
| legacy/icons/resources/salt | 2d | 8 | retained-legacy | historically_uploaded_quality_accepted | legacy/2D | plans/art/icons/resources/salt |
| legacy/icons/resources/sheep | 2d | 8 | retained-legacy | historically_uploaded_quality_accepted | legacy/2D | plans/art/icons/resources/sheep |
| legacy/icons/resources/silk | 2d | 8 | retained-legacy | historically_uploaded_quality_accepted | legacy/2D | plans/art/icons/resources/silk |
| legacy/icons/resources/silver | 2d | 8 | retained-legacy | historically_uploaded_quality_accepted | legacy/2D | plans/art/icons/resources/silver |
| legacy/icons/resources/spices | 2d | 8 | retained-legacy | historically_uploaded_quality_accepted | legacy/2D | plans/art/icons/resources/spices |
| legacy/icons/resources/stone | 2d | 8 | retained-legacy | historically_uploaded_quality_accepted | legacy/2D | plans/art/icons/resources/stone |
| legacy/icons/resources/sugar | 2d | 8 | retained-legacy | historically_uploaded_quality_accepted | legacy/2D | plans/art/icons/resources/sugar |
| legacy/icons/resources/tea | 2d | 8 | retained-legacy | historically_uploaded_quality_accepted | legacy/2D | plans/art/icons/resources/tea |
| legacy/icons/resources/timber | 2d | 8 | retained-legacy | historically_uploaded_quality_accepted | legacy/2D | plans/art/icons/resources/timber |
| legacy/icons/resources/uranium | 2d | 8 | retained-legacy | historically_uploaded_quality_accepted | legacy/2D | plans/art/icons/resources/uranium |
| legacy/icons/resources/whales | 2d | 8 | retained-legacy | historically_uploaded_quality_accepted | legacy/2D | plans/art/icons/resources/whales |
| legacy/icons/resources/wheat | 2d | 8 | retained-legacy | historically_uploaded_quality_accepted | legacy/2D | plans/art/icons/resources/wheat |
| legacy/icons/resources/wine | 2d | 8 | retained-legacy | historically_uploaded_quality_accepted | legacy/2D | plans/art/icons/resources/wine |
| legacy/icons/ships/carrier | 2d | 8 | retained-legacy | historically_uploaded_quality_accepted | legacy/2D | plans/art/icons/ships/carrier |
| legacy/icons/ships/raider | 2d | 8 | retained-legacy | historically_uploaded_quality_accepted | legacy/2D | plans/art/icons/ships/raider |
| legacy/icons/ships/transport | 2d | 8 | retained-legacy | historically_uploaded_quality_accepted | legacy/2D | plans/art/icons/ships/transport |
| legacy/icons/ships/warship | 2d | 8 | retained-legacy | historically_uploaded_quality_accepted | legacy/2D | plans/art/icons/ships/warship |
| legacy/icons/units/air | 2d | 8 | retained-legacy | historically_uploaded_quality_accepted | legacy/2D | plans/art/icons/units/air |
| legacy/icons/units/cavalry | 2d | 8 | retained-legacy | historically_uploaded_quality_accepted | legacy/2D | plans/art/icons/units/cavalry |
| legacy/icons/units/infantry | 2d | 8 | retained-legacy | historically_uploaded_quality_accepted | legacy/2D | plans/art/icons/units/infantry |
| legacy/icons/units/ranged | 2d | 8 | retained-legacy | historically_uploaded_quality_accepted | legacy/2D | plans/art/icons/units/ranged |
| legacy/icons/units/settler | 2d | 8 | retained-legacy | historically_uploaded_quality_accepted | legacy/2D | plans/art/icons/units/settler |
| legacy/icons/units/siege | 2d | 8 | retained-legacy | historically_uploaded_quality_accepted | legacy/2D | plans/art/icons/units/siege |
| legacy/icons/units/support | 2d | 8 | retained-legacy | historically_uploaded_quality_accepted | legacy/2D | plans/art/icons/units/support |
| legacy/icons/wonders/arsenal | 2d | 8 | retained-legacy | historically_uploaded_quality_accepted | legacy/2D | plans/art/icons/wonders/arsenal |
| legacy/icons/wonders/atomic_research_center | 2d | 8 | retained-legacy | historically_uploaded_quality_accepted | legacy/2D | plans/art/icons/wonders/atomic_research_center |
| legacy/icons/wonders/colosseum | 2d | 8 | retained-legacy | historically_uploaded_quality_accepted | legacy/2D | plans/art/icons/wonders/colosseum |
| legacy/icons/wonders/forbidden_city | 2d | 8 | retained-legacy | historically_uploaded_quality_accepted | legacy/2D | plans/art/icons/wonders/forbidden_city |
| legacy/icons/wonders/grand_bazaar | 2d | 8 | retained-legacy | historically_uploaded_quality_accepted | legacy/2D | plans/art/icons/wonders/grand_bazaar |
| legacy/icons/wonders/great_cathedral | 2d | 8 | retained-legacy | historically_uploaded_quality_accepted | legacy/2D | plans/art/icons/wonders/great_cathedral |
| legacy/icons/wonders/great_library | 2d | 8 | retained-legacy | historically_uploaded_quality_accepted | legacy/2D | plans/art/icons/wonders/great_library |
| legacy/icons/wonders/great_pyramids | 2d | 8 | retained-legacy | historically_uploaded_quality_accepted | legacy/2D | plans/art/icons/wonders/great_pyramids |
| legacy/icons/wonders/great_wall | 2d | 8 | retained-legacy | historically_uploaded_quality_accepted | legacy/2D | plans/art/icons/wonders/great_wall |
| legacy/icons/wonders/hanging_gardens | 2d | 8 | retained-legacy | historically_uploaded_quality_accepted | legacy/2D | plans/art/icons/wonders/hanging_gardens |
| legacy/icons/wonders/international_exchange | 2d | 8 | retained-legacy | historically_uploaded_quality_accepted | legacy/2D | plans/art/icons/wonders/international_exchange |
| legacy/icons/wonders/lighthouse | 2d | 8 | retained-legacy | historically_uploaded_quality_accepted | legacy/2D | plans/art/icons/wonders/lighthouse |
| legacy/icons/wonders/palace_of_versailles | 2d | 8 | retained-legacy | historically_uploaded_quality_accepted | legacy/2D | plans/art/icons/wonders/palace_of_versailles |
| legacy/icons/wonders/royal_observatory | 2d | 8 | retained-legacy | historically_uploaded_quality_accepted | legacy/2D | plans/art/icons/wonders/royal_observatory |
| legacy/icons/wonders/space_program | 2d | 8 | retained-legacy | historically_uploaded_quality_accepted | legacy/2D | plans/art/icons/wonders/space_program |
| legacy/kits/europe/modern/materials | 2d | 8 | retained-legacy | historically_uploaded_quality_accepted | legacy/2D | plans/art/kits/europe/modern/materials |
| legacy/kits/indic/gunpowder/materials | 2d | 8 | retained-legacy | historically_uploaded_quality_accepted | legacy/2D | plans/art/kits/indic/gunpowder/materials |
| legacy/kits/indic/modern/materials | 2d | 8 | retained-legacy | pending | legacy/2D | plans/art/kits/indic/modern/materials |
| legacy/kits/israelite/bronze/materials | 2d | 8 | retained-legacy | historically_uploaded_quality_accepted | legacy/2D | plans/art/kits/israelite/bronze/materials |
| legacy/kits/israelite/classical/materials | 2d | 8 | retained-legacy | historically_uploaded_quality_accepted | legacy/2D | plans/art/kits/israelite/classical/materials |
| legacy/kits/israelite/gunpowder/materials | 2d | 8 | retained-legacy | historically_uploaded_quality_accepted | legacy/2D | plans/art/kits/israelite/gunpowder/materials |
| legacy/kits/israelite/kingdoms/materials | 2d | 8 | retained-legacy | historically_uploaded_quality_accepted | legacy/2D | plans/art/kits/israelite/kingdoms/materials |
| legacy/kits/israelite/modern/materials | 2d | 8 | retained-legacy | historically_uploaded_quality_accepted | legacy/2D | plans/art/kits/israelite/modern/materials |
| legacy/kits/levant/bronze/materials | 2d | 8 | retained-legacy | historically_uploaded_quality_accepted | legacy/2D | plans/art/kits/levant/bronze/materials |
| legacy/kits/steppe/modern/materials | 2d | 8 | retained-legacy | historically_uploaded_quality_accepted | legacy/2D | plans/art/kits/steppe/modern/materials |
| map-markers/ai-battle-clash | 2d | 8 | M01-M29-2d | pending | legacy/2D | plans/art/map-markers/ai-battle-clash |
| map-markers/ai-battle-smoke | 2d | 8 | M01-M29-2d | pending | legacy/2D | plans/art/map-markers/ai-battle-smoke |
| map-markers/army-base | 2d | 8 | M01-M29-2d | pending | legacy/2D | plans/art/map-markers/army-base |
| map-markers/badge-plate | 2d | 8 | M01-M29-2d | pending | legacy/2D | plans/art/map-markers/badge-plate |
| map-markers/battle-result | 2d | 8 | M01-M29-2d | pending | legacy/2D | plans/art/map-markers/battle-result |
| map-markers/route-dots | 2d | 8 | M01-M29-2d | pending | legacy/2D | plans/art/map-markers/route-dots |
| map-markers/standard-bronze | 2d | 8 | M01-M29-2d | pending | legacy/2D | plans/art/map-markers/standard-bronze |
| map-markers/standard-classical | 2d | 8 | M01-M29-2d | pending | legacy/2D | plans/art/map-markers/standard-classical |
| map-markers/standard-gunpowder | 2d | 8 | M01-M29-2d | pending | legacy/2D | plans/art/map-markers/standard-gunpowder |
| map-markers/standard-kingdoms | 2d | 8 | M01-M29-2d | pending | legacy/2D | plans/art/map-markers/standard-kingdoms |
| map-markers/standard-modern | 2d | 8 | M01-M29-2d | pending | legacy/2D | plans/art/map-markers/standard-modern |
| map-terrain/ground-tundra | 2d | 8 | M01-M29-2d | pending | legacy/2D | plans/art/map-terrain/ground-tundra |
| peoples/emblems/aghvank | 2d | 8 | M01-M29-2d | pending | legacy/2D | plans/art/peoples/emblems/aghvank |
| peoples/emblems/ahhiyawa | 2d | 8 | M01-M29-2d | pending | legacy/2D | plans/art/peoples/emblems/ahhiyawa |
| peoples/emblems/ajuran | 2d | 8 | M01-M29-2d | pending | legacy/2D | plans/art/peoples/emblems/ajuran |
| peoples/emblems/akkad | 2d | 8 | M01-M29-2d | pending | legacy/2D | plans/art/peoples/emblems/akkad |
| peoples/emblems/alodia | 2d | 8 | M01-M29-2d | pending | legacy/2D | plans/art/peoples/emblems/alodia |
| peoples/emblems/andronovo | 2d | 8 | M01-M29-2d | pending | legacy/2D | plans/art/peoples/emblems/andronovo |
| peoples/emblems/arverni | 2d | 8 | M01-M29-2d | pending | legacy/2D | plans/art/peoples/emblems/arverni |
| peoples/emblems/avanti | 2d | 8 | M01-M29-2d | pending | legacy/2D | plans/art/peoples/emblems/avanti |
| peoples/emblems/avaria | 2d | 8 | M01-M29-2d | pending | legacy/2D | plans/art/peoples/emblems/avaria |
| peoples/emblems/bactria | 2d | 8 | M01-M29-2d | pending | legacy/2D | plans/art/peoples/emblems/bactria |
| peoples/emblems/baekje | 2d | 8 | M01-M29-2d | pending | legacy/2D | plans/art/peoples/emblems/baekje |
| peoples/emblems/bau | 2d | 8 | M01-M29-2d | pending | legacy/2D | plans/art/peoples/emblems/bau |
| peoples/emblems/belgae | 2d | 8 | M01-M29-2d | pending | legacy/2D | plans/art/peoples/emblems/belgae |
| peoples/emblems/bono | 2d | 8 | M01-M29-2d | pending | legacy/2D | plans/art/peoples/emblems/bono |
| peoples/emblems/bosporan | 2d | 8 | M01-M29-2d | pending | legacy/2D | plans/art/peoples/emblems/bosporan |
| peoples/emblems/botai | 2d | 8 | M01-M29-2d | pending | legacy/2D | plans/art/peoples/emblems/botai |
| peoples/emblems/brigantes | 2d | 8 | M01-M29-2d | pending | legacy/2D | plans/art/peoples/emblems/brigantes |
| peoples/emblems/butuan | 2d | 8 | M01-M29-2d | pending | legacy/2D | plans/art/peoples/emblems/butuan |
| peoples/emblems/buyeo | 2d | 8 | M01-M29-2d | pending | legacy/2D | plans/art/peoples/emblems/buyeo |
| peoples/emblems/calusa | 2d | 8 | M01-M29-2d | pending | legacy/2D | plans/art/peoples/emblems/calusa |
| peoples/emblems/caral | 2d | 8 | M01-M29-2d | pending | legacy/2D | plans/art/peoples/emblems/caral |
| peoples/emblems/celtiberia | 2d | 8 | M01-M29-2d | pending | legacy/2D | plans/art/peoples/emblems/celtiberia |
| peoples/emblems/chaco | 2d | 8 | M01-M29-2d | pending | legacy/2D | plans/art/peoples/emblems/chaco |
| peoples/emblems/champa | 2d | 8 | M01-M29-2d | pending | legacy/2D | plans/art/peoples/emblems/champa |
| peoples/emblems/cherusci | 2d | 8 | M01-M29-2d | pending | legacy/2D | plans/art/peoples/emblems/cherusci |
| peoples/emblems/chu | 2d | 8 | M01-M29-2d | pending | legacy/2D | plans/art/peoples/emblems/chu |
| peoples/emblems/colchis | 2d | 8 | M01-M29-2d | pending | legacy/2D | plans/art/peoples/emblems/colchis |
| peoples/emblems/cucuteni | 2d | 8 | M01-M29-2d | pending | legacy/2D | plans/art/peoples/emblems/cucuteni |
| peoples/emblems/cyrene | 2d | 8 | M01-M29-2d | pending | legacy/2D | plans/art/peoples/emblems/cyrene |
| peoples/emblems/dacia | 2d | 8 | M01-M29-2d | pending | legacy/2D | plans/art/peoples/emblems/dacia |
| peoples/emblems/diaguita | 2d | 8 | M01-M29-2d | pending | legacy/2D | plans/art/peoples/emblems/diaguita |
| peoples/emblems/dian | 2d | 8 | M01-M29-2d | pending | legacy/2D | plans/art/peoples/emblems/dian |
| peoples/emblems/dilmun | 2d | 8 | M01-M29-2d | pending | legacy/2D | plans/art/peoples/emblems/dilmun |
| peoples/emblems/djenne-djeno | 2d | 8 | M01-M29-2d | pending | legacy/2D | plans/art/peoples/emblems/djenne-djeno |
| peoples/emblems/dmt | 2d | 8 | M01-M29-2d | pending | legacy/2D | plans/art/peoples/emblems/dmt |
| peoples/emblems/dorset | 2d | 8 | M01-M29-2d | pending | legacy/2D | plans/art/peoples/emblems/dorset |
| peoples/emblems/durotriges | 2d | 8 | M01-M29-2d | pending | legacy/2D | plans/art/peoples/emblems/durotriges |
| peoples/emblems/dvaravati | 2d | 8 | M01-M29-2d | pending | legacy/2D | plans/art/peoples/emblems/dvaravati |
| peoples/emblems/elam | 2d | 8 | M01-M29-2d | pending | legacy/2D | plans/art/peoples/emblems/elam |
| peoples/emblems/emishi | 2d | 8 | M01-M29-2d | pending | legacy/2D | plans/art/peoples/emblems/emishi |
| peoples/emblems/engaruka | 2d | 8 | M01-M29-2d | pending | legacy/2D | plans/art/peoples/emblems/engaruka |
| peoples/emblems/fortriu | 2d | 8 | M01-M29-2d | pending | legacy/2D | plans/art/peoples/emblems/fortriu |
| peoples/emblems/funan | 2d | 8 | M01-M29-2d | pending | legacy/2D | plans/art/peoples/emblems/funan |
| peoples/emblems/gandhara | 2d | 8 | M01-M29-2d | pending | legacy/2D | plans/art/peoples/emblems/gandhara |
| peoples/emblems/garamantes | 2d | 8 | M01-M29-2d | pending | legacy/2D | plans/art/peoples/emblems/garamantes |
| peoples/emblems/geats | 2d | 8 | M01-M29-2d | pending | legacy/2D | plans/art/peoples/emblems/geats |
| peoples/emblems/gojoseon | 2d | 8 | M01-M29-2d | pending | legacy/2D | plans/art/peoples/emblems/gojoseon |
| peoples/emblems/gokturk | 2d | 8 | M01-M29-2d | pending | legacy/2D | plans/art/peoples/emblems/gokturk |
| peoples/emblems/gunditjmara | 2d | 8 | M01-M29-2d | pending | legacy/2D | plans/art/peoples/emblems/gunditjmara |
| peoples/emblems/haida | 2d | 8 | M01-M29-2d | pending | legacy/2D | plans/art/peoples/emblems/haida |
| peoples/emblems/hohokam | 2d | 8 | M01-M29-2d | pending | legacy/2D | plans/art/peoples/emblems/hohokam |
| peoples/emblems/hopewell | 2d | 8 | M01-M29-2d | pending | legacy/2D | plans/art/peoples/emblems/hopewell |
| peoples/emblems/ife | 2d | 8 | M01-M29-2d | pending | legacy/2D | plans/art/peoples/emblems/ife |
| peoples/emblems/illyria | 2d | 8 | M01-M29-2d | pending | legacy/2D | plans/art/peoples/emblems/illyria |
| peoples/emblems/israel | 2d | 8 | M01-M29-2d | pending | legacy/2D | plans/art/peoples/emblems/israel |
| peoples/emblems/jaragua | 2d | 8 | M01-M29-2d | pending | legacy/2D | plans/art/peoples/emblems/jaragua |
| peoples/emblems/kalinago | 2d | 8 | M01-M29-2d | pending | legacy/2D | plans/art/peoples/emblems/kalinago |
| peoples/emblems/kalinga | 2d | 8 | M01-M29-2d | pending | legacy/2D | plans/art/peoples/emblems/kalinga |
| peoples/emblems/kamarupa | 2d | 8 | M01-M29-2d | pending | legacy/2D | plans/art/peoples/emblems/kamarupa |
| peoples/emblems/kanem | 2d | 8 | M01-M29-2d | pending | legacy/2D | plans/art/peoples/emblems/kanem |
| peoples/emblems/kanesh | 2d | 8 | M01-M29-2d | pending | legacy/2D | plans/art/peoples/emblems/kanesh |
| peoples/emblems/keftiu | 2d | 8 | M01-M29-2d | pending | legacy/2D | plans/art/peoples/emblems/keftiu |
| peoples/emblems/kemet | 2d | 8 | M01-M29-2d | pending | legacy/2D | plans/art/peoples/emblems/kemet |
| peoples/emblems/kerma | 2d | 8 | M01-M29-2d | pending | legacy/2D | plans/art/peoples/emblems/kerma |
| peoples/emblems/khazaria | 2d | 8 | M01-M29-2d | pending | legacy/2D | plans/art/peoples/emblems/khazaria |
| peoples/emblems/khoekhoe | 2d | 8 | M01-M29-2d | pending | legacy/2D | plans/art/peoples/emblems/khoekhoe |
| peoples/emblems/khotan | 2d | 8 | M01-M29-2d | pending | legacy/2D | plans/art/peoples/emblems/khotan |
| peoples/emblems/khwarazm | 2d | 8 | M01-M29-2d | pending | legacy/2D | plans/art/peoples/emblems/khwarazm |
| peoples/emblems/kilwa | 2d | 8 | M01-M29-2d | pending | legacy/2D | plans/art/peoples/emblems/kilwa |
| peoples/emblems/kindah | 2d | 8 | M01-M29-2d | pending | legacy/2D | plans/art/peoples/emblems/kindah |
| peoples/emblems/kitara | 2d | 8 | M01-M29-2d | pending | legacy/2D | plans/art/peoples/emblems/kitara |
| peoples/emblems/kosala | 2d | 8 | M01-M29-2d | pending | legacy/2D | plans/art/peoples/emblems/kosala |
| peoples/emblems/kroraina | 2d | 8 | M01-M29-2d | pending | legacy/2D | plans/art/peoples/emblems/kroraina |
| peoples/emblems/kuru | 2d | 8 | M01-M29-2d | pending | legacy/2D | plans/art/peoples/emblems/kuru |
| peoples/emblems/kutai | 2d | 8 | M01-M29-2d | pending | legacy/2D | plans/art/peoples/emblems/kutai |
| peoples/emblems/lapita | 2d | 8 | M01-M29-2d | pending | legacy/2D | plans/art/peoples/emblems/lapita |
| peoples/emblems/latte | 2d | 8 | M01-M29-2d | pending | legacy/2D | plans/art/peoples/emblems/latte |
| peoples/emblems/libu | 2d | 8 | M01-M29-2d | pending | legacy/2D | plans/art/peoples/emblems/libu |
| peoples/emblems/luba | 2d | 8 | M01-M29-2d | pending | legacy/2D | plans/art/peoples/emblems/luba |
| peoples/emblems/lunda | 2d | 8 | M01-M29-2d | pending | legacy/2D | plans/art/peoples/emblems/lunda |
| peoples/emblems/lusitania | 2d | 8 | M01-M29-2d | pending | legacy/2D | plans/art/peoples/emblems/lusitania |
| peoples/emblems/lydia | 2d | 8 | M01-M29-2d | pending | legacy/2D | plans/art/peoples/emblems/lydia |
| peoples/emblems/magadha | 2d | 8 | M01-M29-2d | pending | legacy/2D | plans/art/peoples/emblems/magadha |
| peoples/emblems/magan | 2d | 8 | M01-M29-2d | pending | legacy/2D | plans/art/peoples/emblems/magan |
| peoples/emblems/mapungubwe | 2d | 8 | M01-M29-2d | pending | legacy/2D | plans/art/peoples/emblems/mapungubwe |
| peoples/emblems/marajoara | 2d | 8 | M01-M29-2d | pending | legacy/2D | plans/art/peoples/emblems/marajoara |
| peoples/emblems/marcomannia | 2d | 8 | M01-M29-2d | pending | legacy/2D | plans/art/peoples/emblems/marcomannia |
| peoples/emblems/mari | 2d | 8 | M01-M29-2d | pending | legacy/2D | plans/art/peoples/emblems/mari |
| peoples/emblems/mauretania | 2d | 8 | M01-M29-2d | pending | legacy/2D | plans/art/peoples/emblems/mauretania |
| peoples/emblems/medang | 2d | 8 | M01-M29-2d | pending | legacy/2D | plans/art/peoples/emblems/medang |
| peoples/emblems/media | 2d | 8 | M01-M29-2d | pending | legacy/2D | plans/art/peoples/emblems/media |
| peoples/emblems/meluhha | 2d | 8 | M01-M29-2d | pending | legacy/2D | plans/art/peoples/emblems/meluhha |
| peoples/emblems/merina | 2d | 8 | M01-M29-2d | pending | legacy/2D | plans/art/peoples/emblems/merina |
| peoples/emblems/moche | 2d | 8 | M01-M29-2d | pending | legacy/2D | plans/art/peoples/emblems/moche |
| peoples/emblems/muisca | 2d | 8 | M01-M29-2d | pending | legacy/2D | plans/art/peoples/emblems/muisca |
| peoples/emblems/mutal | 2d | 8 | M01-M29-2d | pending | legacy/2D | plans/art/peoples/emblems/mutal |
| peoples/emblems/mutapa | 2d | 8 | M01-M29-2d | pending | legacy/2D | plans/art/peoples/emblems/mutapa |
| peoples/emblems/nabataea | 2d | 8 | M01-M29-2d | pending | legacy/2D | plans/art/peoples/emblems/nabataea |
| peoples/emblems/nanyue | 2d | 8 | M01-M29-2d | pending | legacy/2D | plans/art/peoples/emblems/nanyue |
| peoples/emblems/ndongo | 2d | 8 | M01-M29-2d | pending | legacy/2D | plans/art/peoples/emblems/ndongo |
| peoples/emblems/nok | 2d | 8 | M01-M29-2d | pending | legacy/2D | plans/art/peoples/emblems/nok |
| peoples/emblems/noricum | 2d | 8 | M01-M29-2d | pending | legacy/2D | plans/art/peoples/emblems/noricum |
| peoples/emblems/numidia | 2d | 8 | M01-M29-2d | pending | legacy/2D | plans/art/peoples/emblems/numidia |
| peoples/emblems/nuragi | 2d | 8 | M01-M29-2d | pending | legacy/2D | plans/art/peoples/emblems/nuragi |
| peoples/emblems/odrysia | 2d | 8 | M01-M29-2d | pending | legacy/2D | plans/art/peoples/emblems/odrysia |
| peoples/emblems/oxus | 2d | 8 | M01-M29-2d | pending | legacy/2D | plans/art/peoples/emblems/oxus |
| peoples/emblems/pandya | 2d | 8 | M01-M29-2d | pending | legacy/2D | plans/art/peoples/emblems/pandya |
| peoples/emblems/parthava | 2d | 8 | M01-M29-2d | pending | legacy/2D | plans/art/peoples/emblems/parthava |
| peoples/emblems/phrygia | 2d | 8 | M01-M29-2d | pending | legacy/2D | plans/art/peoples/emblems/phrygia |
| peoples/emblems/pontus | 2d | 8 | M01-M29-2d | pending | legacy/2D | plans/art/peoples/emblems/pontus |
| peoples/emblems/punt | 2d | 8 | M01-M29-2d | pending | legacy/2D | plans/art/peoples/emblems/punt |
| peoples/emblems/pyu | 2d | 8 | M01-M29-2d | pending | legacy/2D | plans/art/peoples/emblems/pyu |
| peoples/emblems/qedar | 2d | 8 | M01-M29-2d | pending | legacy/2D | plans/art/peoples/emblems/qedar |
| peoples/emblems/qi | 2d | 8 | M01-M29-2d | pending | legacy/2D | plans/art/peoples/emblems/qi |
| peoples/emblems/rajarata | 2d | 8 | M01-M29-2d | pending | legacy/2D | plans/art/peoples/emblems/rajarata |
| peoples/emblems/rasenna | 2d | 8 | M01-M29-2d | pending | legacy/2D | plans/art/peoples/emblems/rasenna |
| peoples/emblems/rygir | 2d | 8 | M01-M29-2d | pending | legacy/2D | plans/art/peoples/emblems/rygir |
| peoples/emblems/saba | 2d | 8 | M01-M29-2d | pending | legacy/2D | plans/art/peoples/emblems/saba |
| peoples/emblems/san | 2d | 8 | M01-M29-2d | pending | legacy/2D | plans/art/peoples/emblems/san |
| peoples/emblems/sarmatians | 2d | 8 | M01-M29-2d | pending | legacy/2D | plans/art/peoples/emblems/sarmatians |
| peoples/emblems/satavahana | 2d | 8 | M01-M29-2d | pending | legacy/2D | plans/art/peoples/emblems/satavahana |
| peoples/emblems/saudeleur | 2d | 8 | M01-M29-2d | pending | legacy/2D | plans/art/peoples/emblems/saudeleur |
| peoples/emblems/saurashtra | 2d | 8 | M01-M29-2d | pending | legacy/2D | plans/art/peoples/emblems/saurashtra |
| peoples/emblems/shang | 2d | 8 | M01-M29-2d | pending | legacy/2D | plans/art/peoples/emblems/shang |
| peoples/emblems/shu | 2d | 8 | M01-M29-2d | pending | legacy/2D | plans/art/peoples/emblems/shu |
| peoples/emblems/sogdia | 2d | 8 | M01-M29-2d | pending | legacy/2D | plans/art/peoples/emblems/sogdia |
| peoples/emblems/srivijaya | 2d | 8 | M01-M29-2d | pending | legacy/2D | plans/art/peoples/emblems/srivijaya |
| peoples/emblems/tartessos | 2d | 8 | M01-M29-2d | pending | legacy/2D | plans/art/peoples/emblems/tartessos |
| peoples/emblems/tarumanagara | 2d | 8 | M01-M29-2d | pending | legacy/2D | plans/art/peoples/emblems/tarumanagara |
| peoples/emblems/teotihuacan | 2d | 8 | M01-M29-2d | pending | legacy/2D | plans/art/peoples/emblems/teotihuacan |
| peoples/emblems/tichitt | 2d | 8 | M01-M29-2d | pending | legacy/2D | plans/art/peoples/emblems/tichitt |
| peoples/emblems/tiwanaku | 2d | 8 | M01-M29-2d | pending | legacy/2D | plans/art/peoples/emblems/tiwanaku |
| peoples/emblems/tondo | 2d | 8 | M01-M29-2d | pending | legacy/2D | plans/art/peoples/emblems/tondo |
| peoples/emblems/tupinamba | 2d | 8 | M01-M29-2d | pending | legacy/2D | plans/art/peoples/emblems/tupinamba |
| peoples/emblems/ugarit | 2d | 8 | M01-M29-2d | pending | legacy/2D | plans/art/peoples/emblems/ugarit |
| peoples/emblems/ulaid | 2d | 8 | M01-M29-2d | pending | legacy/2D | plans/art/peoples/emblems/ulaid |
| peoples/emblems/unknown | 2d | 8 | M01-M29-2d | pending | legacy/2D | plans/art/peoples/emblems/unknown |
| peoples/emblems/urartu | 2d | 8 | M01-M29-2d | pending | legacy/2D | plans/art/peoples/emblems/urartu |
| peoples/emblems/van-lang | 2d | 8 | M01-M29-2d | pending | legacy/2D | plans/art/peoples/emblems/van-lang |
| peoples/emblems/vanga | 2d | 8 | M01-M29-2d | pending | legacy/2D | plans/art/peoples/emblems/vanga |
| peoples/emblems/wagadu | 2d | 8 | M01-M29-2d | pending | legacy/2D | plans/art/peoples/emblems/wagadu |
| peoples/emblems/wahgi | 2d | 8 | M01-M29-2d | pending | legacy/2D | plans/art/peoples/emblems/wahgi |
| peoples/emblems/wari | 2d | 8 | M01-M29-2d | pending | legacy/2D | plans/art/peoples/emblems/wari |
| peoples/emblems/wusun | 2d | 8 | M01-M29-2d | pending | legacy/2D | plans/art/peoples/emblems/wusun |
| peoples/emblems/xianbei | 2d | 8 | M01-M29-2d | pending | legacy/2D | plans/art/peoples/emblems/xianbei |
| peoples/emblems/yamatai | 2d | 8 | M01-M29-2d | pending | legacy/2D | plans/art/peoples/emblems/yamatai |
| peoples/emblems/yarlung | 2d | 8 | M01-M29-2d | pending | legacy/2D | plans/art/peoples/emblems/yarlung |
| peoples/emblems/yue | 2d | 8 | M01-M29-2d | pending | legacy/2D | plans/art/peoples/emblems/yue |
| peoples/emblems/zapotec | 2d | 8 | M01-M29-2d | pending | legacy/2D | plans/art/peoples/emblems/zapotec |
| peoples/emblems/zhangzhung | 2d | 8 | M01-M29-2d | pending | legacy/2D | plans/art/peoples/emblems/zhangzhung |
| peoples/emblems/zhou | 2d | 8 | M01-M29-2d | pending | legacy/2D | plans/art/peoples/emblems/zhou |
| peoples/frames/banner | 2d | 8 | M01-M29-2d | pending | legacy/2D | plans/art/peoples/frames/banner |
| peoples/frames/pennant | 2d | 8 | M01-M29-2d | pending | legacy/2D | plans/art/peoples/frames/pennant |
| peoples/frames/shield | 2d | 8 | M01-M29-2d | pending | legacy/2D | plans/art/peoples/frames/shield |
| props/burnt-field-overlay | 2d | 8 | legacy-overlay | pending | legacy/2D | plans/art/props/burnt-field-overlay |
| props/exit-marker | 2d | 8 | M01-M29-2d | pending | legacy/2D | plans/art/props/exit-marker |
| textures/town-ground-bronze | 2d | 8 | M01-M29-2d | pending | legacy/2D | plans/art/map-terrain/town-ground-bronze |
| textures/town-ground-classical | 2d | 8 | M01-M29-2d | pending | legacy/2D | plans/art/map-terrain/town-ground-classical |
| textures/town-ground-gunpowder | 2d | 8 | M01-M29-2d | pending | legacy/2D | plans/art/map-terrain/town-ground-gunpowder |
| textures/town-ground-kingdoms | 2d | 8 | M01-M29-2d | pending | legacy/2D | plans/art/map-terrain/town-ground-kingdoms |
| textures/town-ground-modern | 2d | 8 | M01-M29-2d | pending | legacy/2D | plans/art/map-terrain/town-ground-modern |
| ui/battle/header-bronze | 2d | 8 | M01-M29-2d | pending | legacy/2D | plans/art/ui/battle/header-bronze |
| ui/battle/header-classical | 2d | 8 | M01-M29-2d | pending | legacy/2D | plans/art/ui/battle/header-classical |
| ui/battle/header-gunpowder | 2d | 8 | M01-M29-2d | pending | legacy/2D | plans/art/ui/battle/header-gunpowder |
| ui/battle/header-kingdoms | 2d | 8 | M01-M29-2d | pending | legacy/2D | plans/art/ui/battle/header-kingdoms |
| ui/battle/header-modern | 2d | 8 | M01-M29-2d | pending | legacy/2D | plans/art/ui/battle/header-modern |
| ui/battle/result-defeat | 2d | 8 | M01-M29-2d | pending | legacy/2D | plans/art/ui/battle/result-defeat |
| ui/battle/result-victory | 2d | 8 | M01-M29-2d | pending | legacy/2D | plans/art/ui/battle/result-victory |
| ui/start/background-phone | 2d | 8 | M01-M29-2d | pending | legacy/2D | plans/art/ui/start/background-phone |
| ui/start/background-wide | 2d | 8 | M01-M29-2d | pending | legacy/2D | plans/art/ui/start/background-wide |
| ui/start/worldsize-large | 2d | 8 | M01-M29-2d | pending | legacy/2D | plans/art/ui/start/worldsize-large |
| ui/start/worldsize-small | 2d | 8 | M01-M29-2d | pending | legacy/2D | plans/art/ui/start/worldsize-small |
| ui/start/worldsize-standard | 2d | 8 | M01-M29-2d | pending | legacy/2D | plans/art/ui/start/worldsize-standard |

| units/shared-neutral-body | 3d | 1 | shared-unit-body | pending | required, no approval stop | proposed addition |

## D10 tier closure: verify presence before adding work

The 444 rows below are explicit required tier combinations not identified as named gaps. Existing assets were not inventoried. The parent should check filenames/manifest metadata and generate sheets/models only for a missing combination.

| Item | Target | Wave |
|---|---|---|
| map-towns/americas/bronze/town-big-a | src/assets/map/towns/bronze-town-big-a-americas.glb | 2 |
| map-towns/americas/bronze/town-big-b | src/assets/map/towns/bronze-town-big-b-americas.glb | 2 |
| map-towns/americas/bronze/town-medium-a | src/assets/map/towns/bronze-town-medium-a-americas.glb | 2 |
| map-towns/americas/bronze/town-medium-b | src/assets/map/towns/bronze-town-medium-b-americas.glb | 2 |
| map-towns/americas/bronze/town-small-a | src/assets/map/towns/bronze-town-small-a-americas.glb | 2 |
| map-towns/americas/bronze/town-small-b | src/assets/map/towns/bronze-town-small-b-americas.glb | 2 |
| map-towns/americas/classical/town-big-a | src/assets/map/towns/classical-town-big-a-americas.glb | 2 |
| map-towns/americas/classical/town-big-b | src/assets/map/towns/classical-town-big-b-americas.glb | 2 |
| map-towns/americas/classical/town-medium-a | src/assets/map/towns/classical-town-medium-a-americas.glb | 2 |
| map-towns/americas/classical/town-medium-b | src/assets/map/towns/classical-town-medium-b-americas.glb | 2 |
| map-towns/americas/classical/town-small-a | src/assets/map/towns/classical-town-small-a-americas.glb | 2 |
| map-towns/americas/classical/town-small-b | src/assets/map/towns/classical-town-small-b-americas.glb | 2 |
| map-towns/americas/gunpowder/town-big-a | src/assets/map/towns/gunpowder-town-big-a-americas.glb | 2 |
| map-towns/americas/gunpowder/town-big-b | src/assets/map/towns/gunpowder-town-big-b-americas.glb | 2 |
| map-towns/americas/gunpowder/town-medium-a | src/assets/map/towns/gunpowder-town-medium-a-americas.glb | 2 |
| map-towns/americas/gunpowder/town-medium-b | src/assets/map/towns/gunpowder-town-medium-b-americas.glb | 2 |
| map-towns/americas/gunpowder/town-small-a | src/assets/map/towns/gunpowder-town-small-a-americas.glb | 2 |
| map-towns/americas/gunpowder/town-small-b | src/assets/map/towns/gunpowder-town-small-b-americas.glb | 2 |
| map-towns/americas/kingdoms/town-big-a | src/assets/map/towns/kingdoms-town-big-a-americas.glb | 2 |
| map-towns/americas/kingdoms/town-big-b | src/assets/map/towns/kingdoms-town-big-b-americas.glb | 2 |
| map-towns/americas/kingdoms/town-medium-a | src/assets/map/towns/kingdoms-town-medium-a-americas.glb | 2 |
| map-towns/americas/kingdoms/town-medium-b | src/assets/map/towns/kingdoms-town-medium-b-americas.glb | 2 |
| map-towns/americas/kingdoms/town-small-a | src/assets/map/towns/kingdoms-town-small-a-americas.glb | 2 |
| map-towns/americas/kingdoms/town-small-b | src/assets/map/towns/kingdoms-town-small-b-americas.glb | 2 |
| map-towns/americas/modern/town-big-a | src/assets/map/towns/modern-town-big-a-americas.glb | 2 |
| map-towns/americas/modern/town-big-b | src/assets/map/towns/modern-town-big-b-americas.glb | 2 |
| map-towns/americas/modern/town-medium-a | src/assets/map/towns/modern-town-medium-a-americas.glb | 2 |
| map-towns/americas/modern/town-medium-b | src/assets/map/towns/modern-town-medium-b-americas.glb | 2 |
| map-towns/americas/modern/town-small-a | src/assets/map/towns/modern-town-small-a-americas.glb | 2 |
| map-towns/americas/modern/town-small-b | src/assets/map/towns/modern-town-small-b-americas.glb | 2 |
| map-towns/base/bronze/town-big-a | src/assets/map/towns/bronze-town-big-a.glb | 2 |
| map-towns/base/bronze/town-big-b | src/assets/map/towns/bronze-town-big-b.glb | 2 |
| map-towns/base/bronze/town-medium-a | src/assets/map/towns/bronze-town-medium-a.glb | 2 |
| map-towns/base/bronze/town-medium-b | src/assets/map/towns/bronze-town-medium-b.glb | 2 |
| map-towns/base/bronze/town-small-a | src/assets/map/towns/bronze-town-small-a.glb | 2 |
| map-towns/base/bronze/town-small-b | src/assets/map/towns/bronze-town-small-b.glb | 2 |
| map-towns/base/classical/town-medium-a | src/assets/map/towns/classical-town-medium-a.glb | 2 |
| map-towns/base/classical/town-medium-b | src/assets/map/towns/classical-town-medium-b.glb | 2 |
| map-towns/base/classical/town-small-a | src/assets/map/towns/classical-town-small-a.glb | 2 |
| map-towns/base/classical/town-small-b | src/assets/map/towns/classical-town-small-b.glb | 2 |
| map-towns/base/gunpowder/town-big-a | src/assets/map/towns/gunpowder-town-big-a.glb | 2 |
| map-towns/base/gunpowder/town-big-b | src/assets/map/towns/gunpowder-town-big-b.glb | 2 |
| map-towns/base/gunpowder/town-medium-a | src/assets/map/towns/gunpowder-town-medium-a.glb | 2 |
| map-towns/base/gunpowder/town-medium-b | src/assets/map/towns/gunpowder-town-medium-b.glb | 2 |
| map-towns/base/gunpowder/town-small-a | src/assets/map/towns/gunpowder-town-small-a.glb | 2 |
| map-towns/base/gunpowder/town-small-b | src/assets/map/towns/gunpowder-town-small-b.glb | 2 |
| map-towns/base/kingdoms/town-big-a | src/assets/map/towns/kingdoms-town-big-a.glb | 2 |
| map-towns/base/kingdoms/town-big-b | src/assets/map/towns/kingdoms-town-big-b.glb | 2 |
| map-towns/base/kingdoms/town-medium-a | src/assets/map/towns/kingdoms-town-medium-a.glb | 2 |
| map-towns/base/kingdoms/town-medium-b | src/assets/map/towns/kingdoms-town-medium-b.glb | 2 |
| map-towns/base/kingdoms/town-small-a | src/assets/map/towns/kingdoms-town-small-a.glb | 2 |
| map-towns/base/kingdoms/town-small-b | src/assets/map/towns/kingdoms-town-small-b.glb | 2 |
| map-towns/base/modern/town-big-a | src/assets/map/towns/modern-town-big-a.glb | 2 |
| map-towns/base/modern/town-big-b | src/assets/map/towns/modern-town-big-b.glb | 2 |
| map-towns/base/modern/town-medium-a | src/assets/map/towns/modern-town-medium-a.glb | 2 |
| map-towns/base/modern/town-medium-b | src/assets/map/towns/modern-town-medium-b.glb | 2 |
| map-towns/base/modern/town-small-a | src/assets/map/towns/modern-town-small-a.glb | 2 |
| map-towns/base/modern/town-small-b | src/assets/map/towns/modern-town-small-b.glb | 2 |
| map-towns/eastafrica/bronze/town-big-a | src/assets/map/towns/bronze-town-big-a-eastafrica.glb | 2 |
| map-towns/eastafrica/bronze/town-big-b | src/assets/map/towns/bronze-town-big-b-eastafrica.glb | 2 |
| map-towns/eastafrica/bronze/town-medium-a | src/assets/map/towns/bronze-town-medium-a-eastafrica.glb | 2 |
| map-towns/eastafrica/bronze/town-medium-b | src/assets/map/towns/bronze-town-medium-b-eastafrica.glb | 2 |
| map-towns/eastafrica/bronze/town-small-a | src/assets/map/towns/bronze-town-small-a-eastafrica.glb | 2 |
| map-towns/eastafrica/bronze/town-small-b | src/assets/map/towns/bronze-town-small-b-eastafrica.glb | 2 |
| map-towns/eastafrica/classical/town-big-a | src/assets/map/towns/classical-town-big-a-eastafrica.glb | 2 |
| map-towns/eastafrica/classical/town-big-b | src/assets/map/towns/classical-town-big-b-eastafrica.glb | 2 |
| map-towns/eastafrica/classical/town-medium-a | src/assets/map/towns/classical-town-medium-a-eastafrica.glb | 2 |
| map-towns/eastafrica/classical/town-medium-b | src/assets/map/towns/classical-town-medium-b-eastafrica.glb | 2 |
| map-towns/eastafrica/classical/town-small-a | src/assets/map/towns/classical-town-small-a-eastafrica.glb | 2 |
| map-towns/eastafrica/classical/town-small-b | src/assets/map/towns/classical-town-small-b-eastafrica.glb | 2 |
| map-towns/eastafrica/gunpowder/town-big-a | src/assets/map/towns/gunpowder-town-big-a-eastafrica.glb | 2 |
| map-towns/eastafrica/gunpowder/town-big-b | src/assets/map/towns/gunpowder-town-big-b-eastafrica.glb | 2 |
| map-towns/eastafrica/gunpowder/town-medium-a | src/assets/map/towns/gunpowder-town-medium-a-eastafrica.glb | 2 |
| map-towns/eastafrica/gunpowder/town-medium-b | src/assets/map/towns/gunpowder-town-medium-b-eastafrica.glb | 2 |
| map-towns/eastafrica/gunpowder/town-small-a | src/assets/map/towns/gunpowder-town-small-a-eastafrica.glb | 2 |
| map-towns/eastafrica/gunpowder/town-small-b | src/assets/map/towns/gunpowder-town-small-b-eastafrica.glb | 2 |
| map-towns/eastafrica/kingdoms/town-big-a | src/assets/map/towns/kingdoms-town-big-a-eastafrica.glb | 2 |
| map-towns/eastafrica/kingdoms/town-big-b | src/assets/map/towns/kingdoms-town-big-b-eastafrica.glb | 2 |
| map-towns/eastafrica/kingdoms/town-medium-a | src/assets/map/towns/kingdoms-town-medium-a-eastafrica.glb | 2 |
| map-towns/eastafrica/kingdoms/town-medium-b | src/assets/map/towns/kingdoms-town-medium-b-eastafrica.glb | 2 |
| map-towns/eastafrica/kingdoms/town-small-a | src/assets/map/towns/kingdoms-town-small-a-eastafrica.glb | 2 |
| map-towns/eastafrica/kingdoms/town-small-b | src/assets/map/towns/kingdoms-town-small-b-eastafrica.glb | 2 |
| map-towns/eastafrica/modern/town-big-a | src/assets/map/towns/modern-town-big-a-eastafrica.glb | 2 |
| map-towns/eastafrica/modern/town-big-b | src/assets/map/towns/modern-town-big-b-eastafrica.glb | 2 |
| map-towns/eastafrica/modern/town-medium-a | src/assets/map/towns/modern-town-medium-a-eastafrica.glb | 2 |
| map-towns/eastafrica/modern/town-medium-b | src/assets/map/towns/modern-town-medium-b-eastafrica.glb | 2 |
| map-towns/eastafrica/modern/town-small-a | src/assets/map/towns/modern-town-small-a-eastafrica.glb | 2 |
| map-towns/eastafrica/modern/town-small-b | src/assets/map/towns/modern-town-small-b-eastafrica.glb | 2 |
| map-towns/europe/bronze/town-big-a | src/assets/map/towns/bronze-town-big-a-europe.glb | 2 |
| map-towns/europe/bronze/town-big-b | src/assets/map/towns/bronze-town-big-b-europe.glb | 2 |
| map-towns/europe/bronze/town-medium-a | src/assets/map/towns/bronze-town-medium-a-europe.glb | 2 |
| map-towns/europe/bronze/town-medium-b | src/assets/map/towns/bronze-town-medium-b-europe.glb | 2 |
| map-towns/europe/bronze/town-small-a | src/assets/map/towns/bronze-town-small-a-europe.glb | 2 |
| map-towns/europe/bronze/town-small-b | src/assets/map/towns/bronze-town-small-b-europe.glb | 2 |
| map-towns/europe/classical/town-big-a | src/assets/map/towns/classical-town-big-a-europe.glb | 2 |
| map-towns/europe/classical/town-big-b | src/assets/map/towns/classical-town-big-b-europe.glb | 2 |
| map-towns/europe/classical/town-medium-a | src/assets/map/towns/classical-town-medium-a-europe.glb | 2 |
| map-towns/europe/classical/town-medium-b | src/assets/map/towns/classical-town-medium-b-europe.glb | 2 |
| map-towns/europe/classical/town-small-a | src/assets/map/towns/classical-town-small-a-europe.glb | 2 |
| map-towns/europe/classical/town-small-b | src/assets/map/towns/classical-town-small-b-europe.glb | 2 |
| map-towns/europe/gunpowder/town-big-a | src/assets/map/towns/gunpowder-town-big-a-europe.glb | 2 |
| map-towns/europe/gunpowder/town-big-b | src/assets/map/towns/gunpowder-town-big-b-europe.glb | 2 |
| map-towns/europe/gunpowder/town-medium-a | src/assets/map/towns/gunpowder-town-medium-a-europe.glb | 2 |
| map-towns/europe/gunpowder/town-medium-b | src/assets/map/towns/gunpowder-town-medium-b-europe.glb | 2 |
| map-towns/europe/gunpowder/town-small-a | src/assets/map/towns/gunpowder-town-small-a-europe.glb | 2 |
| map-towns/europe/gunpowder/town-small-b | src/assets/map/towns/gunpowder-town-small-b-europe.glb | 2 |
| map-towns/europe/kingdoms/town-big-a | src/assets/map/towns/kingdoms-town-big-a-europe.glb | 2 |
| map-towns/europe/kingdoms/town-big-b | src/assets/map/towns/kingdoms-town-big-b-europe.glb | 2 |
| map-towns/europe/kingdoms/town-medium-a | src/assets/map/towns/kingdoms-town-medium-a-europe.glb | 2 |
| map-towns/europe/kingdoms/town-medium-b | src/assets/map/towns/kingdoms-town-medium-b-europe.glb | 2 |
| map-towns/europe/kingdoms/town-small-a | src/assets/map/towns/kingdoms-town-small-a-europe.glb | 2 |
| map-towns/europe/kingdoms/town-small-b | src/assets/map/towns/kingdoms-town-small-b-europe.glb | 2 |
| map-towns/indic/bronze/town-big-a | src/assets/map/towns/bronze-town-big-a-indic.glb | 2 |
| map-towns/indic/bronze/town-big-b | src/assets/map/towns/bronze-town-big-b-indic.glb | 2 |
| map-towns/indic/bronze/town-medium-a | src/assets/map/towns/bronze-town-medium-a-indic.glb | 2 |
| map-towns/indic/bronze/town-medium-b | src/assets/map/towns/bronze-town-medium-b-indic.glb | 2 |
| map-towns/indic/bronze/town-small-a | src/assets/map/towns/bronze-town-small-a-indic.glb | 2 |
| map-towns/indic/bronze/town-small-b | src/assets/map/towns/bronze-town-small-b-indic.glb | 2 |
| map-towns/indic/classical/town-big-a | src/assets/map/towns/classical-town-big-a-indic.glb | 2 |
| map-towns/indic/classical/town-big-b | src/assets/map/towns/classical-town-big-b-indic.glb | 2 |
| map-towns/indic/classical/town-medium-a | src/assets/map/towns/classical-town-medium-a-indic.glb | 2 |
| map-towns/indic/classical/town-medium-b | src/assets/map/towns/classical-town-medium-b-indic.glb | 2 |
| map-towns/indic/classical/town-small-a | src/assets/map/towns/classical-town-small-a-indic.glb | 2 |
| map-towns/indic/classical/town-small-b | src/assets/map/towns/classical-town-small-b-indic.glb | 2 |
| map-towns/indic/kingdoms/town-big-a | src/assets/map/towns/kingdoms-town-big-a-indic.glb | 2 |
| map-towns/indic/kingdoms/town-big-b | src/assets/map/towns/kingdoms-town-big-b-indic.glb | 2 |
| map-towns/indic/kingdoms/town-medium-a | src/assets/map/towns/kingdoms-town-medium-a-indic.glb | 2 |
| map-towns/indic/kingdoms/town-medium-b | src/assets/map/towns/kingdoms-town-medium-b-indic.glb | 2 |
| map-towns/indic/kingdoms/town-small-a | src/assets/map/towns/kingdoms-town-small-a-indic.glb | 2 |
| map-towns/indic/kingdoms/town-small-b | src/assets/map/towns/kingdoms-town-small-b-indic.glb | 2 |
| map-towns/israelite/bronze/town-big-a | src/assets/map/towns/bronze-town-big-a-israelite.glb | 2 |
| map-towns/israelite/bronze/town-big-b | src/assets/map/towns/bronze-town-big-b-israelite.glb | 2 |
| map-towns/israelite/bronze/town-medium-a | src/assets/map/towns/bronze-town-medium-a-israelite.glb | 2 |
| map-towns/israelite/bronze/town-medium-b | src/assets/map/towns/bronze-town-medium-b-israelite.glb | 2 |
| map-towns/israelite/bronze/town-small-a | src/assets/map/towns/bronze-town-small-a-israelite.glb | 2 |
| map-towns/israelite/bronze/town-small-b | src/assets/map/towns/bronze-town-small-b-israelite.glb | 2 |
| map-towns/israelite/classical/town-big-a | src/assets/map/towns/classical-town-big-a-israelite.glb | 2 |
| map-towns/israelite/classical/town-big-b | src/assets/map/towns/classical-town-big-b-israelite.glb | 2 |
| map-towns/israelite/classical/town-medium-a | src/assets/map/towns/classical-town-medium-a-israelite.glb | 2 |
| map-towns/israelite/classical/town-medium-b | src/assets/map/towns/classical-town-medium-b-israelite.glb | 2 |
| map-towns/israelite/classical/town-small-a | src/assets/map/towns/classical-town-small-a-israelite.glb | 2 |
| map-towns/israelite/classical/town-small-b | src/assets/map/towns/classical-town-small-b-israelite.glb | 2 |
| map-towns/israelite/gunpowder/town-big-a | src/assets/map/towns/gunpowder-town-big-a-israelite.glb | 2 |
| map-towns/israelite/gunpowder/town-big-b | src/assets/map/towns/gunpowder-town-big-b-israelite.glb | 2 |
| map-towns/israelite/gunpowder/town-medium-a | src/assets/map/towns/gunpowder-town-medium-a-israelite.glb | 2 |
| map-towns/israelite/gunpowder/town-medium-b | src/assets/map/towns/gunpowder-town-medium-b-israelite.glb | 2 |
| map-towns/israelite/gunpowder/town-small-a | src/assets/map/towns/gunpowder-town-small-a-israelite.glb | 2 |
| map-towns/israelite/gunpowder/town-small-b | src/assets/map/towns/gunpowder-town-small-b-israelite.glb | 2 |
| map-towns/israelite/kingdoms/town-big-a | src/assets/map/towns/kingdoms-town-big-a-israelite.glb | 2 |
| map-towns/israelite/kingdoms/town-big-b | src/assets/map/towns/kingdoms-town-big-b-israelite.glb | 2 |
| map-towns/israelite/kingdoms/town-medium-a | src/assets/map/towns/kingdoms-town-medium-a-israelite.glb | 2 |
| map-towns/israelite/kingdoms/town-medium-b | src/assets/map/towns/kingdoms-town-medium-b-israelite.glb | 2 |
| map-towns/israelite/kingdoms/town-small-a | src/assets/map/towns/kingdoms-town-small-a-israelite.glb | 2 |
| map-towns/israelite/kingdoms/town-small-b | src/assets/map/towns/kingdoms-town-small-b-israelite.glb | 2 |
| map-towns/israelite/modern/town-big-a | src/assets/map/towns/modern-town-big-a-israelite.glb | 2 |
| map-towns/israelite/modern/town-big-b | src/assets/map/towns/modern-town-big-b-israelite.glb | 2 |
| map-towns/israelite/modern/town-medium-a | src/assets/map/towns/modern-town-medium-a-israelite.glb | 2 |
| map-towns/israelite/modern/town-medium-b | src/assets/map/towns/modern-town-medium-b-israelite.glb | 2 |
| map-towns/israelite/modern/town-small-a | src/assets/map/towns/modern-town-small-a-israelite.glb | 2 |
| map-towns/israelite/modern/town-small-b | src/assets/map/towns/modern-town-small-b-israelite.glb | 2 |
| map-towns/japan/bronze/town-big-a | src/assets/map/towns/bronze-town-big-a-japan.glb | 2 |
| map-towns/japan/bronze/town-big-b | src/assets/map/towns/bronze-town-big-b-japan.glb | 2 |
| map-towns/japan/bronze/town-medium-a | src/assets/map/towns/bronze-town-medium-a-japan.glb | 2 |
| map-towns/japan/bronze/town-medium-b | src/assets/map/towns/bronze-town-medium-b-japan.glb | 2 |
| map-towns/japan/bronze/town-small-a | src/assets/map/towns/bronze-town-small-a-japan.glb | 2 |
| map-towns/japan/bronze/town-small-b | src/assets/map/towns/bronze-town-small-b-japan.glb | 2 |
| map-towns/japan/classical/town-big-a | src/assets/map/towns/classical-town-big-a-japan.glb | 2 |
| map-towns/japan/classical/town-big-b | src/assets/map/towns/classical-town-big-b-japan.glb | 2 |
| map-towns/japan/classical/town-medium-a | src/assets/map/towns/classical-town-medium-a-japan.glb | 2 |
| map-towns/japan/classical/town-medium-b | src/assets/map/towns/classical-town-medium-b-japan.glb | 2 |
| map-towns/japan/classical/town-small-a | src/assets/map/towns/classical-town-small-a-japan.glb | 2 |
| map-towns/japan/classical/town-small-b | src/assets/map/towns/classical-town-small-b-japan.glb | 2 |
| map-towns/japan/gunpowder/town-big-a | src/assets/map/towns/gunpowder-town-big-a-japan.glb | 2 |
| map-towns/japan/gunpowder/town-big-b | src/assets/map/towns/gunpowder-town-big-b-japan.glb | 2 |
| map-towns/japan/gunpowder/town-medium-a | src/assets/map/towns/gunpowder-town-medium-a-japan.glb | 2 |
| map-towns/japan/gunpowder/town-medium-b | src/assets/map/towns/gunpowder-town-medium-b-japan.glb | 2 |
| map-towns/japan/gunpowder/town-small-a | src/assets/map/towns/gunpowder-town-small-a-japan.glb | 2 |
| map-towns/japan/gunpowder/town-small-b | src/assets/map/towns/gunpowder-town-small-b-japan.glb | 2 |
| map-towns/japan/kingdoms/town-big-a | src/assets/map/towns/kingdoms-town-big-a-japan.glb | 2 |
| map-towns/japan/kingdoms/town-big-b | src/assets/map/towns/kingdoms-town-big-b-japan.glb | 2 |
| map-towns/japan/kingdoms/town-medium-a | src/assets/map/towns/kingdoms-town-medium-a-japan.glb | 2 |
| map-towns/japan/kingdoms/town-medium-b | src/assets/map/towns/kingdoms-town-medium-b-japan.glb | 2 |
| map-towns/japan/kingdoms/town-small-a | src/assets/map/towns/kingdoms-town-small-a-japan.glb | 2 |
| map-towns/japan/kingdoms/town-small-b | src/assets/map/towns/kingdoms-town-small-b-japan.glb | 2 |
| map-towns/japan/modern/town-big-a | src/assets/map/towns/modern-town-big-a-japan.glb | 2 |
| map-towns/japan/modern/town-big-b | src/assets/map/towns/modern-town-big-b-japan.glb | 2 |
| map-towns/japan/modern/town-medium-a | src/assets/map/towns/modern-town-medium-a-japan.glb | 2 |
| map-towns/japan/modern/town-medium-b | src/assets/map/towns/modern-town-medium-b-japan.glb | 2 |
| map-towns/japan/modern/town-small-a | src/assets/map/towns/modern-town-small-a-japan.glb | 2 |
| map-towns/japan/modern/town-small-b | src/assets/map/towns/modern-town-small-b-japan.glb | 2 |
| map-towns/korea/bronze/town-big-a | src/assets/map/towns/bronze-town-big-a-korea.glb | 2 |
| map-towns/korea/bronze/town-big-b | src/assets/map/towns/bronze-town-big-b-korea.glb | 2 |
| map-towns/korea/bronze/town-medium-a | src/assets/map/towns/bronze-town-medium-a-korea.glb | 2 |
| map-towns/korea/bronze/town-medium-b | src/assets/map/towns/bronze-town-medium-b-korea.glb | 2 |
| map-towns/korea/bronze/town-small-a | src/assets/map/towns/bronze-town-small-a-korea.glb | 2 |
| map-towns/korea/bronze/town-small-b | src/assets/map/towns/bronze-town-small-b-korea.glb | 2 |
| map-towns/korea/classical/town-big-a | src/assets/map/towns/classical-town-big-a-korea.glb | 2 |
| map-towns/korea/classical/town-big-b | src/assets/map/towns/classical-town-big-b-korea.glb | 2 |
| map-towns/korea/classical/town-medium-a | src/assets/map/towns/classical-town-medium-a-korea.glb | 2 |
| map-towns/korea/classical/town-medium-b | src/assets/map/towns/classical-town-medium-b-korea.glb | 2 |
| map-towns/korea/classical/town-small-a | src/assets/map/towns/classical-town-small-a-korea.glb | 2 |
| map-towns/korea/classical/town-small-b | src/assets/map/towns/classical-town-small-b-korea.glb | 2 |
| map-towns/korea/gunpowder/town-big-a | src/assets/map/towns/gunpowder-town-big-a-korea.glb | 2 |
| map-towns/korea/gunpowder/town-big-b | src/assets/map/towns/gunpowder-town-big-b-korea.glb | 2 |
| map-towns/korea/gunpowder/town-medium-a | src/assets/map/towns/gunpowder-town-medium-a-korea.glb | 2 |
| map-towns/korea/gunpowder/town-medium-b | src/assets/map/towns/gunpowder-town-medium-b-korea.glb | 2 |
| map-towns/korea/gunpowder/town-small-a | src/assets/map/towns/gunpowder-town-small-a-korea.glb | 2 |
| map-towns/korea/gunpowder/town-small-b | src/assets/map/towns/gunpowder-town-small-b-korea.glb | 2 |
| map-towns/korea/kingdoms/town-medium-a | src/assets/map/towns/kingdoms-town-medium-a-korea.glb | 2 |
| map-towns/korea/kingdoms/town-medium-b | src/assets/map/towns/kingdoms-town-medium-b-korea.glb | 2 |
| map-towns/korea/kingdoms/town-small-a | src/assets/map/towns/kingdoms-town-small-a-korea.glb | 2 |
| map-towns/korea/kingdoms/town-small-b | src/assets/map/towns/kingdoms-town-small-b-korea.glb | 2 |
| map-towns/korea/modern/town-big-a | src/assets/map/towns/modern-town-big-a-korea.glb | 2 |
| map-towns/korea/modern/town-big-b | src/assets/map/towns/modern-town-big-b-korea.glb | 2 |
| map-towns/korea/modern/town-medium-a | src/assets/map/towns/modern-town-medium-a-korea.glb | 2 |
| map-towns/korea/modern/town-medium-b | src/assets/map/towns/modern-town-medium-b-korea.glb | 2 |
| map-towns/korea/modern/town-small-a | src/assets/map/towns/modern-town-small-a-korea.glb | 2 |
| map-towns/korea/modern/town-small-b | src/assets/map/towns/modern-town-small-b-korea.glb | 2 |
| map-towns/levant/classical/town-big-a | src/assets/map/towns/classical-town-big-a-levant.glb | 2 |
| map-towns/levant/classical/town-big-b | src/assets/map/towns/classical-town-big-b-levant.glb | 2 |
| map-towns/levant/classical/town-medium-a | src/assets/map/towns/classical-town-medium-a-levant.glb | 2 |
| map-towns/levant/classical/town-medium-b | src/assets/map/towns/classical-town-medium-b-levant.glb | 2 |
| map-towns/levant/classical/town-small-a | src/assets/map/towns/classical-town-small-a-levant.glb | 2 |
| map-towns/levant/classical/town-small-b | src/assets/map/towns/classical-town-small-b-levant.glb | 2 |
| map-towns/levant/gunpowder/town-big-a | src/assets/map/towns/gunpowder-town-big-a-levant.glb | 2 |
| map-towns/levant/gunpowder/town-big-b | src/assets/map/towns/gunpowder-town-big-b-levant.glb | 2 |
| map-towns/levant/gunpowder/town-medium-a | src/assets/map/towns/gunpowder-town-medium-a-levant.glb | 2 |
| map-towns/levant/gunpowder/town-medium-b | src/assets/map/towns/gunpowder-town-medium-b-levant.glb | 2 |
| map-towns/levant/gunpowder/town-small-a | src/assets/map/towns/gunpowder-town-small-a-levant.glb | 2 |
| map-towns/levant/gunpowder/town-small-b | src/assets/map/towns/gunpowder-town-small-b-levant.glb | 2 |
| map-towns/levant/kingdoms/town-big-a | src/assets/map/towns/kingdoms-town-big-a-levant.glb | 2 |
| map-towns/levant/kingdoms/town-big-b | src/assets/map/towns/kingdoms-town-big-b-levant.glb | 2 |
| map-towns/levant/kingdoms/town-medium-a | src/assets/map/towns/kingdoms-town-medium-a-levant.glb | 2 |
| map-towns/levant/kingdoms/town-medium-b | src/assets/map/towns/kingdoms-town-medium-b-levant.glb | 2 |
| map-towns/levant/kingdoms/town-small-a | src/assets/map/towns/kingdoms-town-small-a-levant.glb | 2 |
| map-towns/levant/kingdoms/town-small-b | src/assets/map/towns/kingdoms-town-small-b-levant.glb | 2 |
| map-towns/levant/modern/town-big-a | src/assets/map/towns/modern-town-big-a-levant.glb | 2 |
| map-towns/levant/modern/town-big-b | src/assets/map/towns/modern-town-big-b-levant.glb | 2 |
| map-towns/levant/modern/town-medium-a | src/assets/map/towns/modern-town-medium-a-levant.glb | 2 |
| map-towns/levant/modern/town-medium-b | src/assets/map/towns/modern-town-medium-b-levant.glb | 2 |
| map-towns/levant/modern/town-small-a | src/assets/map/towns/modern-town-small-a-levant.glb | 2 |
| map-towns/levant/modern/town-small-b | src/assets/map/towns/modern-town-small-b-levant.glb | 2 |
| map-towns/maghreb/bronze/town-big-a | src/assets/map/towns/bronze-town-big-a-maghreb.glb | 2 |
| map-towns/maghreb/bronze/town-big-b | src/assets/map/towns/bronze-town-big-b-maghreb.glb | 2 |
| map-towns/maghreb/bronze/town-medium-a | src/assets/map/towns/bronze-town-medium-a-maghreb.glb | 2 |
| map-towns/maghreb/bronze/town-medium-b | src/assets/map/towns/bronze-town-medium-b-maghreb.glb | 2 |
| map-towns/maghreb/bronze/town-small-a | src/assets/map/towns/bronze-town-small-a-maghreb.glb | 2 |
| map-towns/maghreb/bronze/town-small-b | src/assets/map/towns/bronze-town-small-b-maghreb.glb | 2 |
| map-towns/maghreb/classical/town-big-a | src/assets/map/towns/classical-town-big-a-maghreb.glb | 2 |
| map-towns/maghreb/classical/town-big-b | src/assets/map/towns/classical-town-big-b-maghreb.glb | 2 |
| map-towns/maghreb/classical/town-medium-a | src/assets/map/towns/classical-town-medium-a-maghreb.glb | 2 |
| map-towns/maghreb/classical/town-medium-b | src/assets/map/towns/classical-town-medium-b-maghreb.glb | 2 |
| map-towns/maghreb/classical/town-small-a | src/assets/map/towns/classical-town-small-a-maghreb.glb | 2 |
| map-towns/maghreb/classical/town-small-b | src/assets/map/towns/classical-town-small-b-maghreb.glb | 2 |
| map-towns/maghreb/gunpowder/town-big-a | src/assets/map/towns/gunpowder-town-big-a-maghreb.glb | 2 |
| map-towns/maghreb/gunpowder/town-big-b | src/assets/map/towns/gunpowder-town-big-b-maghreb.glb | 2 |
| map-towns/maghreb/gunpowder/town-medium-a | src/assets/map/towns/gunpowder-town-medium-a-maghreb.glb | 2 |
| map-towns/maghreb/gunpowder/town-medium-b | src/assets/map/towns/gunpowder-town-medium-b-maghreb.glb | 2 |
| map-towns/maghreb/gunpowder/town-small-a | src/assets/map/towns/gunpowder-town-small-a-maghreb.glb | 2 |
| map-towns/maghreb/gunpowder/town-small-b | src/assets/map/towns/gunpowder-town-small-b-maghreb.glb | 2 |
| map-towns/maghreb/kingdoms/town-big-a | src/assets/map/towns/kingdoms-town-big-a-maghreb.glb | 2 |
| map-towns/maghreb/kingdoms/town-big-b | src/assets/map/towns/kingdoms-town-big-b-maghreb.glb | 2 |
| map-towns/maghreb/kingdoms/town-medium-a | src/assets/map/towns/kingdoms-town-medium-a-maghreb.glb | 2 |
| map-towns/maghreb/kingdoms/town-medium-b | src/assets/map/towns/kingdoms-town-medium-b-maghreb.glb | 2 |
| map-towns/maghreb/kingdoms/town-small-a | src/assets/map/towns/kingdoms-town-small-a-maghreb.glb | 2 |
| map-towns/maghreb/kingdoms/town-small-b | src/assets/map/towns/kingdoms-town-small-b-maghreb.glb | 2 |
| map-towns/maghreb/modern/town-big-a | src/assets/map/towns/modern-town-big-a-maghreb.glb | 2 |
| map-towns/maghreb/modern/town-big-b | src/assets/map/towns/modern-town-big-b-maghreb.glb | 2 |
| map-towns/maghreb/modern/town-medium-a | src/assets/map/towns/modern-town-medium-a-maghreb.glb | 2 |
| map-towns/maghreb/modern/town-medium-b | src/assets/map/towns/modern-town-medium-b-maghreb.glb | 2 |
| map-towns/maghreb/modern/town-small-a | src/assets/map/towns/modern-town-small-a-maghreb.glb | 2 |
| map-towns/maghreb/modern/town-small-b | src/assets/map/towns/modern-town-small-b-maghreb.glb | 2 |
| map-towns/monsoon/bronze/town-big-a | src/assets/map/towns/bronze-town-big-a-monsoon.glb | 2 |
| map-towns/monsoon/bronze/town-big-b | src/assets/map/towns/bronze-town-big-b-monsoon.glb | 2 |
| map-towns/monsoon/bronze/town-medium-a | src/assets/map/towns/bronze-town-medium-a-monsoon.glb | 2 |
| map-towns/monsoon/bronze/town-medium-b | src/assets/map/towns/bronze-town-medium-b-monsoon.glb | 2 |
| map-towns/monsoon/bronze/town-small-a | src/assets/map/towns/bronze-town-small-a-monsoon.glb | 2 |
| map-towns/monsoon/bronze/town-small-b | src/assets/map/towns/bronze-town-small-b-monsoon.glb | 2 |
| map-towns/monsoon/classical/town-big-a | src/assets/map/towns/classical-town-big-a-monsoon.glb | 2 |
| map-towns/monsoon/classical/town-big-b | src/assets/map/towns/classical-town-big-b-monsoon.glb | 2 |
| map-towns/monsoon/classical/town-medium-a | src/assets/map/towns/classical-town-medium-a-monsoon.glb | 2 |
| map-towns/monsoon/classical/town-medium-b | src/assets/map/towns/classical-town-medium-b-monsoon.glb | 2 |
| map-towns/monsoon/classical/town-small-a | src/assets/map/towns/classical-town-small-a-monsoon.glb | 2 |
| map-towns/monsoon/classical/town-small-b | src/assets/map/towns/classical-town-small-b-monsoon.glb | 2 |
| map-towns/monsoon/gunpowder/town-big-a | src/assets/map/towns/gunpowder-town-big-a-monsoon.glb | 2 |
| map-towns/monsoon/gunpowder/town-big-b | src/assets/map/towns/gunpowder-town-big-b-monsoon.glb | 2 |
| map-towns/monsoon/gunpowder/town-medium-a | src/assets/map/towns/gunpowder-town-medium-a-monsoon.glb | 2 |
| map-towns/monsoon/gunpowder/town-medium-b | src/assets/map/towns/gunpowder-town-medium-b-monsoon.glb | 2 |
| map-towns/monsoon/gunpowder/town-small-a | src/assets/map/towns/gunpowder-town-small-a-monsoon.glb | 2 |
| map-towns/monsoon/gunpowder/town-small-b | src/assets/map/towns/gunpowder-town-small-b-monsoon.glb | 2 |
| map-towns/monsoon/kingdoms/town-big-a | src/assets/map/towns/kingdoms-town-big-a-monsoon.glb | 2 |
| map-towns/monsoon/kingdoms/town-big-b | src/assets/map/towns/kingdoms-town-big-b-monsoon.glb | 2 |
| map-towns/monsoon/kingdoms/town-medium-a | src/assets/map/towns/kingdoms-town-medium-a-monsoon.glb | 2 |
| map-towns/monsoon/kingdoms/town-medium-b | src/assets/map/towns/kingdoms-town-medium-b-monsoon.glb | 2 |
| map-towns/monsoon/kingdoms/town-small-a | src/assets/map/towns/kingdoms-town-small-a-monsoon.glb | 2 |
| map-towns/monsoon/kingdoms/town-small-b | src/assets/map/towns/kingdoms-town-small-b-monsoon.glb | 2 |
| map-towns/monsoon/modern/town-big-a | src/assets/map/towns/modern-town-big-a-monsoon.glb | 2 |
| map-towns/monsoon/modern/town-big-b | src/assets/map/towns/modern-town-big-b-monsoon.glb | 2 |
| map-towns/monsoon/modern/town-medium-a | src/assets/map/towns/modern-town-medium-a-monsoon.glb | 2 |
| map-towns/monsoon/modern/town-medium-b | src/assets/map/towns/modern-town-medium-b-monsoon.glb | 2 |
| map-towns/monsoon/modern/town-small-a | src/assets/map/towns/modern-town-small-a-monsoon.glb | 2 |
| map-towns/monsoon/modern/town-small-b | src/assets/map/towns/modern-town-small-b-monsoon.glb | 2 |
| map-towns/nile/bronze/town-big-a | src/assets/map/towns/bronze-town-big-a-nile.glb | 2 |
| map-towns/nile/bronze/town-big-b | src/assets/map/towns/bronze-town-big-b-nile.glb | 2 |
| map-towns/nile/bronze/town-medium-a | src/assets/map/towns/bronze-town-medium-a-nile.glb | 2 |
| map-towns/nile/bronze/town-medium-b | src/assets/map/towns/bronze-town-medium-b-nile.glb | 2 |
| map-towns/nile/bronze/town-small-a | src/assets/map/towns/bronze-town-small-a-nile.glb | 2 |
| map-towns/nile/bronze/town-small-b | src/assets/map/towns/bronze-town-small-b-nile.glb | 2 |
| map-towns/nile/classical/town-big-a | src/assets/map/towns/classical-town-big-a-nile.glb | 2 |
| map-towns/nile/classical/town-big-b | src/assets/map/towns/classical-town-big-b-nile.glb | 2 |
| map-towns/nile/classical/town-medium-a | src/assets/map/towns/classical-town-medium-a-nile.glb | 2 |
| map-towns/nile/classical/town-medium-b | src/assets/map/towns/classical-town-medium-b-nile.glb | 2 |
| map-towns/nile/classical/town-small-a | src/assets/map/towns/classical-town-small-a-nile.glb | 2 |
| map-towns/nile/classical/town-small-b | src/assets/map/towns/classical-town-small-b-nile.glb | 2 |
| map-towns/nile/gunpowder/town-big-a | src/assets/map/towns/gunpowder-town-big-a-nile.glb | 2 |
| map-towns/nile/gunpowder/town-big-b | src/assets/map/towns/gunpowder-town-big-b-nile.glb | 2 |
| map-towns/nile/gunpowder/town-medium-a | src/assets/map/towns/gunpowder-town-medium-a-nile.glb | 2 |
| map-towns/nile/gunpowder/town-medium-b | src/assets/map/towns/gunpowder-town-medium-b-nile.glb | 2 |
| map-towns/nile/gunpowder/town-small-a | src/assets/map/towns/gunpowder-town-small-a-nile.glb | 2 |
| map-towns/nile/gunpowder/town-small-b | src/assets/map/towns/gunpowder-town-small-b-nile.glb | 2 |
| map-towns/nile/kingdoms/town-big-a | src/assets/map/towns/kingdoms-town-big-a-nile.glb | 2 |
| map-towns/nile/kingdoms/town-big-b | src/assets/map/towns/kingdoms-town-big-b-nile.glb | 2 |
| map-towns/nile/kingdoms/town-medium-a | src/assets/map/towns/kingdoms-town-medium-a-nile.glb | 2 |
| map-towns/nile/kingdoms/town-medium-b | src/assets/map/towns/kingdoms-town-medium-b-nile.glb | 2 |
| map-towns/nile/kingdoms/town-small-a | src/assets/map/towns/kingdoms-town-small-a-nile.glb | 2 |
| map-towns/nile/kingdoms/town-small-b | src/assets/map/towns/kingdoms-town-small-b-nile.glb | 2 |
| map-towns/nile/modern/town-big-a | src/assets/map/towns/modern-town-big-a-nile.glb | 2 |
| map-towns/nile/modern/town-big-b | src/assets/map/towns/modern-town-big-b-nile.glb | 2 |
| map-towns/nile/modern/town-medium-a | src/assets/map/towns/modern-town-medium-a-nile.glb | 2 |
| map-towns/nile/modern/town-medium-b | src/assets/map/towns/modern-town-medium-b-nile.glb | 2 |
| map-towns/nile/modern/town-small-a | src/assets/map/towns/modern-town-small-a-nile.glb | 2 |
| map-towns/nile/modern/town-small-b | src/assets/map/towns/modern-town-small-b-nile.glb | 2 |
| map-towns/pacific/bronze/town-medium-a | src/assets/map/towns/bronze-town-medium-a-pacific.glb | 2 |
| map-towns/pacific/bronze/town-medium-b | src/assets/map/towns/bronze-town-medium-b-pacific.glb | 2 |
| map-towns/pacific/bronze/town-small-a | src/assets/map/towns/bronze-town-small-a-pacific.glb | 2 |
| map-towns/pacific/bronze/town-small-b | src/assets/map/towns/bronze-town-small-b-pacific.glb | 2 |
| map-towns/pacific/classical/town-big-a | src/assets/map/towns/classical-town-big-a-pacific.glb | 2 |
| map-towns/pacific/classical/town-big-b | src/assets/map/towns/classical-town-big-b-pacific.glb | 2 |
| map-towns/pacific/classical/town-medium-a | src/assets/map/towns/classical-town-medium-a-pacific.glb | 2 |
| map-towns/pacific/classical/town-medium-b | src/assets/map/towns/classical-town-medium-b-pacific.glb | 2 |
| map-towns/pacific/classical/town-small-a | src/assets/map/towns/classical-town-small-a-pacific.glb | 2 |
| map-towns/pacific/classical/town-small-b | src/assets/map/towns/classical-town-small-b-pacific.glb | 2 |
| map-towns/pacific/gunpowder/town-big-a | src/assets/map/towns/gunpowder-town-big-a-pacific.glb | 2 |
| map-towns/pacific/gunpowder/town-big-b | src/assets/map/towns/gunpowder-town-big-b-pacific.glb | 2 |
| map-towns/pacific/gunpowder/town-medium-a | src/assets/map/towns/gunpowder-town-medium-a-pacific.glb | 2 |
| map-towns/pacific/gunpowder/town-medium-b | src/assets/map/towns/gunpowder-town-medium-b-pacific.glb | 2 |
| map-towns/pacific/gunpowder/town-small-a | src/assets/map/towns/gunpowder-town-small-a-pacific.glb | 2 |
| map-towns/pacific/gunpowder/town-small-b | src/assets/map/towns/gunpowder-town-small-b-pacific.glb | 2 |
| map-towns/pacific/kingdoms/town-big-a | src/assets/map/towns/kingdoms-town-big-a-pacific.glb | 2 |
| map-towns/pacific/kingdoms/town-big-b | src/assets/map/towns/kingdoms-town-big-b-pacific.glb | 2 |
| map-towns/pacific/kingdoms/town-medium-a | src/assets/map/towns/kingdoms-town-medium-a-pacific.glb | 2 |
| map-towns/pacific/kingdoms/town-medium-b | src/assets/map/towns/kingdoms-town-medium-b-pacific.glb | 2 |
| map-towns/pacific/kingdoms/town-small-a | src/assets/map/towns/kingdoms-town-small-a-pacific.glb | 2 |
| map-towns/pacific/kingdoms/town-small-b | src/assets/map/towns/kingdoms-town-small-b-pacific.glb | 2 |
| map-towns/pacific/modern/town-big-a | src/assets/map/towns/modern-town-big-a-pacific.glb | 2 |
| map-towns/pacific/modern/town-big-b | src/assets/map/towns/modern-town-big-b-pacific.glb | 2 |
| map-towns/pacific/modern/town-medium-a | src/assets/map/towns/modern-town-medium-a-pacific.glb | 2 |
| map-towns/pacific/modern/town-medium-b | src/assets/map/towns/modern-town-medium-b-pacific.glb | 2 |
| map-towns/pacific/modern/town-small-a | src/assets/map/towns/modern-town-small-a-pacific.glb | 2 |
| map-towns/pacific/modern/town-small-b | src/assets/map/towns/modern-town-small-b-pacific.glb | 2 |
| map-towns/sinic/bronze/town-big-a | src/assets/map/towns/bronze-town-big-a-sinic.glb | 2 |
| map-towns/sinic/bronze/town-big-b | src/assets/map/towns/bronze-town-big-b-sinic.glb | 2 |
| map-towns/sinic/bronze/town-medium-a | src/assets/map/towns/bronze-town-medium-a-sinic.glb | 2 |
| map-towns/sinic/bronze/town-medium-b | src/assets/map/towns/bronze-town-medium-b-sinic.glb | 2 |
| map-towns/sinic/bronze/town-small-a | src/assets/map/towns/bronze-town-small-a-sinic.glb | 2 |
| map-towns/sinic/bronze/town-small-b | src/assets/map/towns/bronze-town-small-b-sinic.glb | 2 |
| map-towns/sinic/classical/town-big-a | src/assets/map/towns/classical-town-big-a-sinic.glb | 2 |
| map-towns/sinic/classical/town-big-b | src/assets/map/towns/classical-town-big-b-sinic.glb | 2 |
| map-towns/sinic/classical/town-medium-a | src/assets/map/towns/classical-town-medium-a-sinic.glb | 2 |
| map-towns/sinic/classical/town-medium-b | src/assets/map/towns/classical-town-medium-b-sinic.glb | 2 |
| map-towns/sinic/classical/town-small-a | src/assets/map/towns/classical-town-small-a-sinic.glb | 2 |
| map-towns/sinic/classical/town-small-b | src/assets/map/towns/classical-town-small-b-sinic.glb | 2 |
| map-towns/sinic/gunpowder/town-big-a | src/assets/map/towns/gunpowder-town-big-a-sinic.glb | 2 |
| map-towns/sinic/gunpowder/town-big-b | src/assets/map/towns/gunpowder-town-big-b-sinic.glb | 2 |
| map-towns/sinic/gunpowder/town-medium-a | src/assets/map/towns/gunpowder-town-medium-a-sinic.glb | 2 |
| map-towns/sinic/gunpowder/town-medium-b | src/assets/map/towns/gunpowder-town-medium-b-sinic.glb | 2 |
| map-towns/sinic/gunpowder/town-small-a | src/assets/map/towns/gunpowder-town-small-a-sinic.glb | 2 |
| map-towns/sinic/gunpowder/town-small-b | src/assets/map/towns/gunpowder-town-small-b-sinic.glb | 2 |
| map-towns/sinic/kingdoms/town-big-a | src/assets/map/towns/kingdoms-town-big-a-sinic.glb | 2 |
| map-towns/sinic/kingdoms/town-big-b | src/assets/map/towns/kingdoms-town-big-b-sinic.glb | 2 |
| map-towns/sinic/kingdoms/town-medium-a | src/assets/map/towns/kingdoms-town-medium-a-sinic.glb | 2 |
| map-towns/sinic/kingdoms/town-medium-b | src/assets/map/towns/kingdoms-town-medium-b-sinic.glb | 2 |
| map-towns/sinic/kingdoms/town-small-a | src/assets/map/towns/kingdoms-town-small-a-sinic.glb | 2 |
| map-towns/sinic/kingdoms/town-small-b | src/assets/map/towns/kingdoms-town-small-b-sinic.glb | 2 |
| map-towns/sinic/modern/town-big-a | src/assets/map/towns/modern-town-big-a-sinic.glb | 2 |
| map-towns/sinic/modern/town-big-b | src/assets/map/towns/modern-town-big-b-sinic.glb | 2 |
| map-towns/sinic/modern/town-medium-a | src/assets/map/towns/modern-town-medium-a-sinic.glb | 2 |
| map-towns/sinic/modern/town-medium-b | src/assets/map/towns/modern-town-medium-b-sinic.glb | 2 |
| map-towns/sinic/modern/town-small-a | src/assets/map/towns/modern-town-small-a-sinic.glb | 2 |
| map-towns/sinic/modern/town-small-b | src/assets/map/towns/modern-town-small-b-sinic.glb | 2 |
| map-towns/steppe/bronze/town-big-a | src/assets/map/towns/bronze-town-big-a-steppe.glb | 2 |
| map-towns/steppe/bronze/town-big-b | src/assets/map/towns/bronze-town-big-b-steppe.glb | 2 |
| map-towns/steppe/bronze/town-medium-a | src/assets/map/towns/bronze-town-medium-a-steppe.glb | 2 |
| map-towns/steppe/bronze/town-medium-b | src/assets/map/towns/bronze-town-medium-b-steppe.glb | 2 |
| map-towns/steppe/bronze/town-small-a | src/assets/map/towns/bronze-town-small-a-steppe.glb | 2 |
| map-towns/steppe/bronze/town-small-b | src/assets/map/towns/bronze-town-small-b-steppe.glb | 2 |
| map-towns/steppe/classical/town-big-a | src/assets/map/towns/classical-town-big-a-steppe.glb | 2 |
| map-towns/steppe/classical/town-big-b | src/assets/map/towns/classical-town-big-b-steppe.glb | 2 |
| map-towns/steppe/classical/town-medium-a | src/assets/map/towns/classical-town-medium-a-steppe.glb | 2 |
| map-towns/steppe/classical/town-medium-b | src/assets/map/towns/classical-town-medium-b-steppe.glb | 2 |
| map-towns/steppe/classical/town-small-a | src/assets/map/towns/classical-town-small-a-steppe.glb | 2 |
| map-towns/steppe/classical/town-small-b | src/assets/map/towns/classical-town-small-b-steppe.glb | 2 |
| map-towns/steppe/gunpowder/town-big-a | src/assets/map/towns/gunpowder-town-big-a-steppe.glb | 2 |
| map-towns/steppe/gunpowder/town-big-b | src/assets/map/towns/gunpowder-town-big-b-steppe.glb | 2 |
| map-towns/steppe/gunpowder/town-medium-a | src/assets/map/towns/gunpowder-town-medium-a-steppe.glb | 2 |
| map-towns/steppe/gunpowder/town-medium-b | src/assets/map/towns/gunpowder-town-medium-b-steppe.glb | 2 |
| map-towns/steppe/gunpowder/town-small-a | src/assets/map/towns/gunpowder-town-small-a-steppe.glb | 2 |
| map-towns/steppe/gunpowder/town-small-b | src/assets/map/towns/gunpowder-town-small-b-steppe.glb | 2 |
| map-towns/steppe/kingdoms/town-big-a | src/assets/map/towns/kingdoms-town-big-a-steppe.glb | 2 |
| map-towns/steppe/kingdoms/town-big-b | src/assets/map/towns/kingdoms-town-big-b-steppe.glb | 2 |
| map-towns/steppe/kingdoms/town-medium-a | src/assets/map/towns/kingdoms-town-medium-a-steppe.glb | 2 |
| map-towns/steppe/kingdoms/town-medium-b | src/assets/map/towns/kingdoms-town-medium-b-steppe.glb | 2 |
| map-towns/steppe/kingdoms/town-small-a | src/assets/map/towns/kingdoms-town-small-a-steppe.glb | 2 |
| map-towns/steppe/kingdoms/town-small-b | src/assets/map/towns/kingdoms-town-small-b-steppe.glb | 2 |
| map-towns/westafrica/bronze/town-big-a | src/assets/map/towns/bronze-town-big-a-westafrica.glb | 2 |
| map-towns/westafrica/bronze/town-big-b | src/assets/map/towns/bronze-town-big-b-westafrica.glb | 2 |
| map-towns/westafrica/bronze/town-medium-a | src/assets/map/towns/bronze-town-medium-a-westafrica.glb | 2 |
| map-towns/westafrica/bronze/town-medium-b | src/assets/map/towns/bronze-town-medium-b-westafrica.glb | 2 |
| map-towns/westafrica/bronze/town-small-a | src/assets/map/towns/bronze-town-small-a-westafrica.glb | 2 |
| map-towns/westafrica/bronze/town-small-b | src/assets/map/towns/bronze-town-small-b-westafrica.glb | 2 |
| map-towns/westafrica/classical/town-big-a | src/assets/map/towns/classical-town-big-a-westafrica.glb | 2 |
| map-towns/westafrica/classical/town-big-b | src/assets/map/towns/classical-town-big-b-westafrica.glb | 2 |
| map-towns/westafrica/classical/town-medium-a | src/assets/map/towns/classical-town-medium-a-westafrica.glb | 2 |
| map-towns/westafrica/classical/town-medium-b | src/assets/map/towns/classical-town-medium-b-westafrica.glb | 2 |
| map-towns/westafrica/classical/town-small-a | src/assets/map/towns/classical-town-small-a-westafrica.glb | 2 |
| map-towns/westafrica/classical/town-small-b | src/assets/map/towns/classical-town-small-b-westafrica.glb | 2 |
| map-towns/westafrica/gunpowder/town-big-a | src/assets/map/towns/gunpowder-town-big-a-westafrica.glb | 2 |
| map-towns/westafrica/gunpowder/town-big-b | src/assets/map/towns/gunpowder-town-big-b-westafrica.glb | 2 |
| map-towns/westafrica/gunpowder/town-medium-a | src/assets/map/towns/gunpowder-town-medium-a-westafrica.glb | 2 |
| map-towns/westafrica/gunpowder/town-medium-b | src/assets/map/towns/gunpowder-town-medium-b-westafrica.glb | 2 |
| map-towns/westafrica/gunpowder/town-small-a | src/assets/map/towns/gunpowder-town-small-a-westafrica.glb | 2 |
| map-towns/westafrica/gunpowder/town-small-b | src/assets/map/towns/gunpowder-town-small-b-westafrica.glb | 2 |
| map-towns/westafrica/kingdoms/town-big-a | src/assets/map/towns/kingdoms-town-big-a-westafrica.glb | 2 |
| map-towns/westafrica/kingdoms/town-big-b | src/assets/map/towns/kingdoms-town-big-b-westafrica.glb | 2 |
| map-towns/westafrica/kingdoms/town-medium-a | src/assets/map/towns/kingdoms-town-medium-a-westafrica.glb | 2 |
| map-towns/westafrica/kingdoms/town-medium-b | src/assets/map/towns/kingdoms-town-medium-b-westafrica.glb | 2 |
| map-towns/westafrica/kingdoms/town-small-a | src/assets/map/towns/kingdoms-town-small-a-westafrica.glb | 2 |
| map-towns/westafrica/kingdoms/town-small-b | src/assets/map/towns/kingdoms-town-small-b-westafrica.glb | 2 |
| map-towns/westafrica/modern/town-big-a | src/assets/map/towns/modern-town-big-a-westafrica.glb | 2 |
| map-towns/westafrica/modern/town-big-b | src/assets/map/towns/modern-town-big-b-westafrica.glb | 2 |
| map-towns/westafrica/modern/town-medium-a | src/assets/map/towns/modern-town-medium-a-westafrica.glb | 2 |
| map-towns/westafrica/modern/town-medium-b | src/assets/map/towns/modern-town-medium-b-westafrica.glb | 2 |
| map-towns/westafrica/modern/town-small-a | src/assets/map/towns/modern-town-small-a-westafrica.glb | 2 |
| map-towns/westafrica/modern/town-small-b | src/assets/map/towns/modern-town-small-b-westafrica.glb | 2 |
