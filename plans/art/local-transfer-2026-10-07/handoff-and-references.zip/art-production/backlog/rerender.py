import bpy,json,sys,math
from pathlib import Path
from mathutils import Vector
for name in sys.argv[sys.argv.index('--')+1:]:
    out=Path('/workspace/art-production/backlog')/name
    bpy.ops.wm.open_mainfile(filepath=str(out/(name+'.blend')))
    scene=bpy.context.scene
    lods=[bpy.data.objects[x] for x in ['LOD0','LOD1','LOD2']]
    for o in lods[1:]:o.hide_render=True
    # Standard landscape preview. Studio objects never enter the asset files.
    scene.render.resolution_x=844;scene.render.resolution_y=390;scene.render.resolution_percentage=100
    scene.cycles.samples=32;scene.cycles.adaptive_threshold=.06
    scene.view_settings.view_transform='AgX';scene.view_settings.exposure=.7
    world=bpy.data.worlds.new('DeliverySky');world.use_nodes=True;scene.world=world
    world.node_tree.nodes['Background'].inputs['Color'].default_value=(.776,.855,.93,1)
    world.node_tree.nodes['Background'].inputs['Strength'].default_value=.65
    def light(name,kind,pos,power,color,size=None):
        data=bpy.data.lights.new(name,kind);data.energy=power;data.color=color
        if size is not None:data.size=size
        o=bpy.data.objects.new(name,data);scene.collection.objects.link(o);o.location=pos
        o.rotation_euler=(-o.location).to_track_quat('-Z','Y').to_euler();return o
    sun=light('PreviewSun','SUN',(22,10,38),2.4,(1,.799,.54));sun.data.angle=math.radians(2)
    light('PreviewGroundBounce','AREA',(0,-2,.10),30,(.102,.080,.05),4)
    dims=lods[0].dimensions;target=Vector((0,0,dims.z*.43))
    cam=bpy.data.objects.new('PreviewCamera',bpy.data.cameras.new('PreviewCamera'));scene.collection.objects.link(cam)
    cam.location=target+Vector((1,-1,1.25)).normalized()*max(6,max(dims)*5)
    cam.rotation_euler=(target-cam.location).to_track_quat('-Z','Y').to_euler();cam.data.type='ORTHO'
    projected_height=(dims.x+dims.y)*.38+dims.z*.75
    basis=cam.rotation_euler.to_matrix()
    points=[basis.transposed() @ (lods[0].matrix_world @ Vector(c)-cam.location) for c in lods[0].bound_box]
    low=[min(p[i] for p in points) for i in range(2)];high=[max(p[i] for p in points) for i in range(2)]
    cam.data.ortho_scale=max(high[0]-low[0],(high[1]-low[1])*844/390)*1.13
    cam.location+=basis @ Vector(((low[0]+high[0])/2,(low[1]+high[1])/2,0))
    scene.camera=cam;scene.render.film_transparent=True
    scene.render.image_settings.file_format='PNG';scene.render.filepath=str(out/'preview.png')
    bpy.ops.render.render(write_still=True)
    print('RERENDERED',name,flush=True)
