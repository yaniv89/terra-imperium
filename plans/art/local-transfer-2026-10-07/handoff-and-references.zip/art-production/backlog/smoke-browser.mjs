import { chromium } from '/workspace/terra-imperium/node_modules/playwright/index.mjs';
const browser=await chromium.launch({headless:true,args:['--no-sandbox','--enable-webgl','--use-gl=angle','--use-angle=swiftshader']});
const page=await browser.newPage({viewport:{width:844,height:390}});
const errors=[];page.on('pageerror',e=>errors.push(e.message));
await page.goto('http://127.0.0.1:3000/terra-imperium/?battleSandbox&city=medium',{waitUntil:'domcontentloaded',timeout:30000});
await page.waitForTimeout(5000);
console.log(JSON.stringify({title:await page.title(),body:(await page.locator('body').innerText()).slice(0,1600),errors}));
await page.screenshot({path:'/workspace/art-production/backlog/game-start.png'});await browser.close();
