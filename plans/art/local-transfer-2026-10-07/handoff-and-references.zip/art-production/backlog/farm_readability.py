"""Ground-only atlas readability correction for two already-built backlog farms.
Run: blender -b -t 1 --python farm_readability.py -- farm-bronze farm-modern
No new meshes, UVs, LODs, material slots, alpha, Team/Town texels or AO bakes.
World-coordinate strip paint is EMIT baked into existing DeliveryUV, masked by
an independent Ground EMIT bake. The original ORM AO channel is applied once.
Backups make reruns idempotent. Output mutations are confined to these farms.
"""
import bpy, sys, math, json, hashlib, shutil, runpy
from pathlib import Path
from mathutils import Vector
import numpy as np
ROOT=Path('/workspace/art-production/backlog')
N=2048

def pixels(im):
    a=np.empty(N*N*4,np.float32);im.pixels.foreach_get(a);return a.reshape(-1,4)

def digest(a):return hashlib.sha256(a.tobytes()).hexdigest()
def filehash(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def geometry():
    result={}
    for name in ('LOD0','LOD1','LOD2'):
        o=bpy.data.objects[name];m=o.data;m.calc_loop_triangles()
        h=hashlib.sha256()
        for a in (np.array([v.co[:] for v in m.vertices],np.float32),np.array([e.vertices[:] for e in m.edges],np.int32),np.array([(p.loop_start,p.loop_total,p.material_index) for p in m.polygons],np.int32),np.array([l.vertex_index for l in m.loops],np.int32),np.array([v.uv[:] for v in m.uv_layers.active.data],np.float32),np.array(o.matrix_world,np.float32)):h.update(a.tobytes())
        result[name]={'triangles':len(m.loop_triangles),'geometry_uv_material_assignment_sha256':h.hexdigest(),'material_names':[m.name for m in m.materials]}
    return result

def preview(out,name,filename,phone=False):
    scene=bpy.context.scene
    for o in list(scene.objects):
        if o.type in {'LIGHT','CAMERA'}:bpy.data.objects.remove(o,do_unlink=True)
    for lev in ('LOD0','LOD1','LOD2'):bpy.data.objects[lev].hide_render=lev!='LOD0'
    scene.render.engine='CYCLES';scene.cycles.device='CPU';scene.cycles.samples=24
    scene.cycles.use_denoising=False;scene.cycles.adaptive_threshold=.06
    scene.render.threads_mode='FIXED';scene.render.threads=1
    scene.render.resolution_x=211 if phone else 844
    scene.render.resolution_y=98 if phone else 390
    scene.render.resolution_percentage=100
    scene.view_settings.view_transform='AgX';scene.view_settings.exposure=.7
    w=bpy.data.worlds.new('FarmReviewSky');w.use_nodes=True;scene.world=w
    w.node_tree.nodes['Background'].inputs['Color'].default_value=(.776,.855,.93,1)
    w.node_tree.nodes['Background'].inputs['Strength'].default_value=.65
    def light(label,kind,pos,power,color,size=None):
        d=bpy.data.lights.new(label,kind);d.energy=power;d.color=color
        if size is not None:d.size=size
        o=bpy.data.objects.new(label,d);scene.collection.objects.link(o);o.location=pos
        o.rotation_euler=(-o.location).to_track_quat('-Z','Y').to_euler();return o
    sun=light('FarmReviewSun','SUN',(22,10,38),2.4,(1,.799,.54));sun.data.angle=math.radians(2)
    light('FarmReviewBounce','AREA',(0,-2,.1),30,(.102,.080,.05),4)
    o=bpy.data.objects['LOD0'];dims=o.dimensions;target=Vector((0,0,dims.z*.43))
    cam=bpy.data.objects.new('FarmReviewCamera',bpy.data.cameras.new('FarmReviewCamera'));scene.collection.objects.link(cam)
    cam.location=target+Vector((1,-1,1.25)).normalized()*max(6,max(dims)*5)
    cam.rotation_euler=(target-cam.location).to_track_quat('-Z','Y').to_euler();cam.data.type='ORTHO'
    basis=cam.rotation_euler.to_matrix()
    pts=[basis.transposed()@(o.matrix_world@Vector(c)-cam.location) for c in o.bound_box]
    lo=[min(p[i] for p in pts) for i in range(2)];hi=[max(p[i] for p in pts) for i in range(2)]
    cam.data.ortho_scale=max(hi[0]-lo[0],(hi[1]-lo[1])*844/390)*1.13
    cam.location+=basis@Vector(((lo[0]+hi[0])/2,(lo[1]+hi[1])/2,0))
    scene.camera=cam;scene.render.film_transparent=True
    scene.render.image_settings.file_format='PNG';scene.render.filepath=str(out/filename)
    bpy.ops.render.render(write_still=True)

class Paint:
    def __init__(self,mat):self.n=mat.node_tree.nodes;self.l=mat.node_tree.links;self.added=[]
    def node(self,kind):n=self.n.new(kind);self.added.append(n);return n
    def math(self,op,a,b=0):
        n=self.node('ShaderNodeMath');n.operation=op
        for i,v in enumerate((a,b)):
            if isinstance(v,(int,float)):n.inputs[i].default_value=v
            else:self.l.new(v,n.inputs[i])
        return n.outputs[0]
    def mix(self,fac,a,b):
        n=self.node('ShaderNodeMixRGB');n.blend_type='MIX'
        for i,v in enumerate((fac,a,b)):
            if isinstance(v,(int,float)):n.inputs[i].default_value=v
            elif isinstance(v,tuple):n.inputs[i].default_value=v
            else:self.l.new(v,n.inputs[i])
        return n.outputs[0]
    def between(self,v,low,high):return self.math('MULTIPLY',self.math('GREATER_THAN',v,low),self.math('LESS_THAN',v,high))
    def color(self,modern):
        g=self.node('ShaderNodeNewGeometry');sep=self.node('ShaderNodeSeparateXYZ');self.l.new(g.outputs['Position'],sep.inputs[0])
        x=self.math('MULTIPLY',sep.outputs['X'],10);y=self.math('MULTIPLY',sep.outputs['Y'],10)
        noise=self.node('ShaderNodeTexNoise');noise.inputs['Scale'].default_value=9;noise.inputs['Detail'].default_value=2;self.l.new(g.outputs['Position'],noise.inputs['Vector'])
        fine=noise.outputs['Fac'];wiggle=self.math('MULTIPLY',self.math('SUBTRACT',fine,.5),.32)
        # Boundaries derive from the existing 23m strip at x=-6, five stalk lines.
        edge_x=self.math('ADD',x,wiggle);edge_y=self.math('ADD',y,wiggle)
        across=self.between(edge_x,-17.3,5.3)
        bands=self.math('MODULO',self.math('ADD',edge_y,16),6)
        within=self.between(bands,.65,5.35)
        fields=self.math('MULTIPLY',across,self.math('MULTIPLY',within,self.between(edge_y,-15.4,13.4)))
        # Clear the well/tractor footprint, aligned to existing machinery.
        dx=self.math('SUBTRACT',x,-8 if modern else -11);dy=self.math('SUBTRACT',y,-7)
        d2=self.math('ADD',self.math('MULTIPLY',dx,dx),self.math('MULTIPLY',dy,dy))
        fields=self.math('MULTIPLY',fields,self.math('GREATER_THAN',d2,9 if modern else 2.6))
        # Gold ripe cereal / green growing cereal. Large blocks survive phone scale.
        green=self.math('MAXIMUM',self.between(y,-9.5,-4.5),self.between(y,2.5,7.5))
        gold=(.66,.40,.085,1) if modern else (.61,.36,.07,1)
        crop=self.mix(green,gold,(.14,.32,.038,1))
        rows=self.math('MODULO',self.math('ADD',x,17.5),1.1 if modern else .95)
        row=self.math('LESS_THAN',rows,.22 if modern else .18)
        crop=self.mix(row,crop,(.26,.15,.055,1))
        # Period-specific plot organization: ancient narrow strips with tiny cross
        # access breaks; Modern broader blocks with a central implement lane.
        breaks=self.between(x,-6.45,-5.55) if modern else self.math('LESS_THAN',self.math('MODULO',self.math('ADD',x,17.5),7.4),.42)
        fields=self.math('MULTIPLY',fields,self.math('SUBTRACT',1,breaks))
        soil=self.mix(fine,(.31,.21,.115,1),(.43,.32,.185,1))
        painted=self.mix(fields,soil,crop)
        # Subtle broken grass/soil fringe within the existing alpha, no new edge.
        radial=self.math('SQRT',self.math('ADD',self.math('MULTIPLY',x,x),self.math('MULTIPLY',y,y)))
        fringe=self.math('MULTIPLY',self.math('GREATER_THAN',radial,20.5),self.math('GREATER_THAN',fine,.56))
        painted=self.mix(fringe,painted,(.26,.29,.095,1))
        # Carry original actual baked AO through untouched ORM red, exactly once.
        uv=self.node('ShaderNodeUVMap');uv.uv_map='DeliveryUV'
        t=self.node('ShaderNodeTexImage');t.image=bpy.data.images['delivery-orm'];self.l.new(uv.outputs[0],t.inputs['Vector'])
        channels=self.node('ShaderNodeSeparateColor');channels.mode='RGB';self.l.new(t.outputs['Color'],channels.inputs[0])
        mul=self.node('ShaderNodeMixRGB');mul.blend_type='MULTIPLY';mul.inputs[0].default_value=1
        self.l.new(painted,mul.inputs[1]);self.l.new(channels.outputs[0],mul.inputs[2]);return mul.outputs[0]

def emit_bake(obj,label,paint=False,modern=False):
    im=bpy.data.images.new(label,width=N,height=N,alpha=True);im.colorspace_settings.name='Non-Color'
    saved=[]
    for m in obj.data.materials:
        helper=Paint(m);n=m.node_tree.nodes;l=m.node_tree.links
        final=next(z for z in n if z.type=='OUTPUT_MATERIAL');previous=final.inputs['Surface'].links[0].from_socket
        active=n.active;e=helper.node('ShaderNodeEmission')
        if m.name=='Ground':
            if paint:l.new(helper.color(modern),e.inputs['Color'])
            else:e.inputs['Color'].default_value=(1,1,1,1)
        else:e.inputs['Color'].default_value=(0,0,0,1)
        l.new(e.outputs[0],final.inputs['Surface']);target=helper.node('ShaderNodeTexImage');target.image=im;n.active=target
        saved.append((m,helper,final,previous,active))
    bpy.ops.object.select_all(action='DESELECT');obj.select_set(True);bpy.context.view_layer.objects.active=obj
    bpy.context.scene.render.bake.margin=0;bpy.context.scene.render.bake.use_clear=True
    bpy.ops.object.bake(type='EMIT')
    values=pixels(im)
    for m,h,final,previous,active in saved:
        m.node_tree.links.new(previous,final.inputs['Surface'])
        for n in h.added:m.node_tree.nodes.remove(n)
        m.node_tree.nodes.active=active
    bpy.data.images.remove(im);return values

def fix(name):
    assert name in ('farm-bronze','farm-modern'),name
    out=ROOT/name;blend=out/(name+'.blend');backup=out/(name+'.before-farm-readability.blend')
    if not backup.exists():shutil.copy2(blend,backup)
    original_png=out/'basecolor.before-farm-readability.png'
    if not original_png.exists():shutil.copy2(out/'basecolor.png',original_png)
    bpy.ops.wm.open_mainfile(filepath=str(backup))
    before_geometry=geometry();unchanged={n:filehash(out/(n+'.png')) for n in ('normal','orm')}
    base=bpy.data.images['delivery-basecolor'];old=pixels(base).copy();orm_before=digest(pixels(bpy.data.images['delivery-orm']))
    preview(out,name,'phone-before.png',phone=True)
    scene=bpy.context.scene;scene.cycles.samples=1;scene.cycles.use_denoising=False
    obj=bpy.data.objects['LOD0'];mask=emit_bake(obj,'temporary-ground-mask')[:,0]>.999
    painted=emit_bake(obj,'temporary-ground-crop-paint',True,name.endswith('modern'))
    changed=old.copy();changed[mask,:3]=painted[mask,:3]
    assert np.array_equal(changed[:,3],old[:,3]);assert np.array_equal(changed[~mask],old[~mask])
    base.pixels.foreach_set(changed.ravel());base.update();base.filepath_raw=str(out/'basecolor.png');base.file_format='PNG';base.save();base.pack()
    source_after_geometry=geometry();assert source_after_geometry==before_geometry;assert digest(pixels(bpy.data.images['delivery-orm']))==orm_before
    assert all(filehash(out/(n+'.png'))==h for n,h in unchanged.items())
    # Delete review studio before saving and exporting. Keep exactly three atlases.
    for o in list(scene.objects):
        if o.type in {'LIGHT','CAMERA'}:bpy.data.objects.remove(o,do_unlink=True)
    for lev in ('LOD0','LOD1','LOD2'):bpy.data.objects[lev].hide_render=False
    scene.camera=None;bpy.context.preferences.filepaths.save_version=0
    bpy.ops.wm.save_as_mainfile(filepath=str(blend))
    bpy.ops.export_scene.gltf(filepath=str(out/(name+'.glb')),export_format='GLB',export_apply=True,export_yup=True,export_image_format='WEBP',export_image_quality=90,export_cameras=False,export_lights=False,export_all_vertex_colors=False)
    runpy.run_path('/workspace/blender-delivery/all-remaining/glb-utils.py')['alpha_mask'](out/(name+'.glb'))
    preview(out,name,'preview.png');preview(out,name,'phone.png',phone=True)
    report={'id':name,'method':'Existing Ground only, world-position shader -> EMIT -> existing DeliveryUV; original baked ORM AO red applied once','source_strip_bounds_metres':{'x':[-17.5,5.5],'y_centres':[-13,-7,-1,5,11]},'geometry_before':before_geometry,'geometry_after':source_after_geometry,'ground_texels_updated':int(mask.sum()),'non_ground_basecolor_texels_exactly_unchanged':True,'basecolor_alpha_exactly_unchanged':True,'orm_packed_pixels_exactly_unchanged':True,'external_normal_orm_sha256_unchanged':unchanged,'atlas_images':[['basecolor',2048,2048],['normal',2048,2048],['orm',2048,2048]],'phone_dimensions':[211,98],'phone_note':'Rounded quarter of 844x390, rendered directly at 211x98 with identical framing','one_thread':True,'no_new_geometry':True,'backups':[backup.name,original_png.name]}
    (out/'farm-readability.json').write_text(json.dumps(report,indent=2)+'\n')
    delivery=json.loads((out/'delivery.json').read_text());delivery['ground_readability_revision']='Existing field-strip crop rows/gold-green blocks and bright soil, Ground-only EMIT, original alpha/normal/ORM/AO preserved';delivery['phone_preview']=[211,98];(out/'delivery.json').write_text(json.dumps(delivery,indent=2)+'\n')
    print('FARM_READABILITY_COMPLETE',name,json.dumps(report),flush=True)

def audit_saved(name):
    assert name in ('farm-bronze','farm-modern')
    out=ROOT/name;report=json.loads((out/'farm-readability.json').read_text())
    bpy.ops.wm.open_mainfile(filepath=str(out/(name+'.blend')))
    saved=geometry();assert saved==report['geometry_before']==report['geometry_after']
    images=[i for i in bpy.data.images if i.size[0]>0]
    assert len(images)==3 and {i.name for i in images}=={'delivery-basecolor','delivery-normal','delivery-orm'}
    assert all(list(i.size)==[2048,2048] and i.packed_file for i in images)
    assert not any(o.type in {'CAMERA','LIGHT'} for o in bpy.context.scene.objects)
    assert all(filehash(out/(n+'.png'))==h for n,h in report['external_normal_orm_sha256_unchanged'].items())
    validation=json.loads((out/(name+'.validation.json')).read_text());assert validation['passed']
    exported=[validation['objects'][name]['lods'][k]['triangles'] for k in ('LOD0','LOD1','LOD2')]
    delivery=json.loads((out/'delivery.json').read_text());assert exported==delivery['triangles']
    report['saved_blend_geometry_uv_material_assignments_exactly_unchanged']=True
    report['saved_blend_has_exactly_three_packed_2048_images']=True
    report['saved_blend_has_no_cameras_or_lights']=True
    report['exported_triangles_unchanged']=exported
    report['parent_validator_passed']=True
    (out/'farm-readability.json').write_text(json.dumps(report,indent=2)+'\n')
    print('FARM_READABILITY_SAVED_AUDIT_PASS',name,exported,flush=True)

if __name__=='__main__':
    args=sys.argv[sys.argv.index('--')+1:] if '--' in sys.argv else ['farm-bronze','farm-modern']
    if args and args[0]=='--audit-only':
        for name in args[1:]:audit_saved(name)
    else:
        for name in args:fix(name)
