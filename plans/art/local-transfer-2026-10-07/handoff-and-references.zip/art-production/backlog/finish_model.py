"""Repackage an existing authored source under the current map-art contract.

Unique delivery UVs bake the source's actual Cycles AO into base colour once.
The original tiled UV map remains available as an editable source reference.
No geometry, code, or source plans are changed.
"""
import bpy, sys, json, math, runpy, importlib.util
from pathlib import Path
from mathutils import Vector
import numpy as np

ROOT = Path('/workspace/art-production/backlog')
OLD = Path('/workspace/blender-delivery/all-remaining')
REF = Path('/workspace/terra-imperium/scripts/blender')

def source(input_socket):
    return input_socket.links[0].from_socket if input_socket.is_linked else None

def bake_image(obj, name, outputs, colorspace='sRGB'):
    im = bpy.data.images.new(name, width=2048, height=2048, alpha=True)
    im.colorspace_settings.name = colorspace
    for mat, output in outputs:
        nodes, links = mat.node_tree.nodes, mat.node_tree.links
        final = next(n for n in nodes if n.type == 'OUTPUT_MATERIAL')
        emit = nodes.new('ShaderNodeEmission')
        if hasattr(output, 'node'):
            links.new(output, emit.inputs['Color'])
        else:
            emit.inputs['Color'].default_value = output
        links.new(emit.outputs[0], final.inputs['Surface'])
        target = nodes.new('ShaderNodeTexImage'); target.image = im
        nodes.active = target
    bpy.context.view_layer.objects.active = obj
    bpy.ops.object.bake(type='EMIT')
    return im

def image_values(im):
    a = np.empty(2048*2048*4, np.float32)
    im.pixels.foreach_get(a)
    return a.reshape(-1,4)

def finish(item):
    section, ident = item.split('/')[2], item.split('/')[-1]
    kind = 'improvement' if section == 'improvements' else 'landmark'
    if kind == 'improvement':
        age = 'bronze' if item.split('/')[-2] == 'ancient' else item.split('/')[-2]
        name = ident + '-' + age
        game_path = 'src/assets/map/improvements/' + name + '.glb'
    else:
        name = ident
        game_path = 'src/assets/map/buildings/' + name + '.glb'
    out = ROOT/name; out.mkdir(parents=True, exist_ok=True)
    bpy.ops.wm.open_mainfile(filepath=str(OLD/item/'model.blend'))
    meshes = [o for o in bpy.context.scene.objects if o.type == 'MESH']
    assert len(meshes) == 1, (item, [o.name for o in meshes])
    obj = meshes[0]
    for o in list(bpy.context.scene.objects):
        if o != obj: bpy.data.objects.remove(o, do_unlink=True)
    bpy.ops.object.select_all(action='DESELECT'); obj.select_set(True)
    bpy.context.view_layer.objects.active = obj
    old_uv = obj.data.uv_layers.active; old_uv.name = 'SourceUV'
    for mat in obj.data.materials:
        for node in list(mat.node_tree.nodes):
            if node.type == 'TEX_IMAGE':
                uv = mat.node_tree.nodes.new('ShaderNodeUVMap'); uv.uv_map = 'SourceUV'
                mat.node_tree.links.new(uv.outputs['UV'], node.inputs['Vector'])
    atlas = obj.data.uv_layers.new(name='DeliveryUV')
    obj.data.uv_layers.active = atlas; atlas.active_render = True
    bpy.ops.object.mode_set(mode='EDIT'); bpy.ops.mesh.select_all(action='SELECT')
    bpy.ops.uv.smart_project(angle_limit=math.radians(75), island_margin=.003,
                             area_weight=1, correct_aspect=True, scale_to_bounds=True)
    bpy.ops.object.mode_set(mode='OBJECT')
    scene = bpy.context.scene; scene.render.engine = 'CYCLES'
    scene.cycles.device='CPU'; scene.cycles.samples=1; scene.cycles.use_denoising=False
    scene.render.threads_mode='FIXED'; scene.render.threads=1
    scene.render.bake.margin=6; scene.render.bake.use_clear=True
    roles=[]; colors=[]; alphas=[]; orm=[]
    for mat in obj.data.materials:
        bs=next(n for n in mat.node_tree.nodes if n.type=='BSDF_PRINCIPLED')
        roles.append(mat.name)
        colors.append((mat, source(bs.inputs['Base Color']) or tuple(bs.inputs['Base Color'].default_value)))
        a=source(bs.inputs['Alpha'])
        alphas.append((mat, a if a else (1,1,1,1)))
        nodes,links=mat.node_tree.nodes,mat.node_tree.links
        c=nodes.new('ShaderNodeCombineColor');c.mode='RGB'
        vc=next((n for n in nodes if n.type=='VERTEX_COLOR' and n.layer_name=='AOColor'),None)
        if vc:
            sep=nodes.new('ShaderNodeSeparateColor');sep.mode='RGB'
            links.new(vc.outputs['Color'],sep.inputs['Color']);links.new(sep.outputs[0],c.inputs[0])
        else:c.inputs[0].default_value=1
        for channel,key in [(1,'Roughness'),(2,'Metallic')]:
            s=source(bs.inputs[key])
            if s:links.new(s,c.inputs[channel])
            else:c.inputs[channel].default_value=bs.inputs[key].default_value
        orm.append((mat,c.outputs[0]))
    base=bake_image(obj,'delivery-basecolor',colors)
    alpha=bake_image(obj,'delivery-alpha',alphas,'Non-Color')
    b=image_values(base); b[:,3]=image_values(alpha)[:,0]
    base.pixels.foreach_set(b.ravel()); base.update()
    packed=bake_image(obj,'delivery-orm',orm,'Non-Color')
    normal=bpy.data.images.new('delivery-normal',width=2048,height=2048,alpha=False)
    normal.colorspace_settings.name='Non-Color'
    for mat in obj.data.materials:
        nodes,links=mat.node_tree.nodes,mat.node_tree.links
        bs=next(n for n in nodes if n.type=='BSDF_PRINCIPLED')
        final=next(n for n in nodes if n.type=='OUTPUT_MATERIAL')
        links.new(bs.outputs[0],final.inputs['Surface'])
        target=nodes.new('ShaderNodeTexImage');target.image=normal;nodes.active=target
    bpy.ops.object.bake(type='NORMAL')
    for im,label in [(base,'basecolor'),(normal,'normal'),(packed,'orm')]:
        im.filepath_raw=str(out/(label+'.png'));im.file_format='PNG';im.save();im.pack()
    # Replace the tiled material nodes. AO is now in the base-colour atlas;
    # no vertex RGB or second occlusion multiplication is exported.
    for mat,role in zip(obj.data.materials,roles):
        nodes,links=mat.node_tree.nodes,mat.node_tree.links;nodes.clear()
        bs=nodes.new('ShaderNodeBsdfPrincipled');final=nodes.new('ShaderNodeOutputMaterial')
        links.new(bs.outputs[0],final.inputs['Surface'])
        uv=nodes.new('ShaderNodeUVMap');uv.uv_map='DeliveryUV'
        textures=[]
        for im in [base,normal,packed]:
            n=nodes.new('ShaderNodeTexImage');n.image=im;links.new(uv.outputs[0],n.inputs['Vector']);textures.append(n)
        links.new(textures[0].outputs['Color'],bs.inputs['Base Color'])
        nm=nodes.new('ShaderNodeNormalMap');links.new(textures[1].outputs['Color'],nm.inputs['Color']);links.new(nm.outputs[0],bs.inputs['Normal'])
        sep=nodes.new('ShaderNodeSeparateColor');sep.mode='RGB';links.new(textures[2].outputs['Color'],sep.inputs['Color'])
        links.new(sep.outputs[1],bs.inputs['Roughness']);links.new(sep.outputs[2],bs.inputs['Metallic'])
        if role=='Ground':
            links.new(textures[0].outputs['Alpha'],bs.inputs['Alpha']);mat.surface_render_method='DITHERED'
        mat.name=role
    for attr in list(obj.data.color_attributes):obj.data.color_attributes.remove(attr)
    obj.data.uv_layers.remove(obj.data.uv_layers['SourceUV'])
    # Fresh LODs preserve authored LOD0 geometry. The imported model stays editable.
    spec=importlib.util.spec_from_file_location('backlog_importer',REF/'import_model.py')
    helper=importlib.util.module_from_spec(spec);spec.loader.exec_module(helper)
    helper.normalise(obj)
    root,lods=helper.with_lods(obj,name,helper.BUDGETS[kind])
    # Many independent bevelled props cannot collapse to an arbitrarily small
    # budget. Remove the least important disconnected details at distant LODs.
    # Keep Team features and the large structural volumes preferentially.
    for level,o in enumerate(lods):
        target=helper.BUDGETS[kind][level]
        while helper.tris(o)>target:
            import bmesh
            bm=bmesh.new();bm.from_mesh(o.data)
            seen=set();groups=[]
            for v in bm.verts:
                if v in seen:continue
                stack=[v];component=set();seen.add(v)
                while stack:
                    q=stack.pop();component.add(q)
                    for e in q.link_edges:
                        z=e.other_vert(q)
                        if z not in seen:seen.add(z);stack.append(z)
                faces={f for q in component for f in q.link_faces}
                area=sum(f.calc_area() for f in faces)
                team=any(o.data.materials[f.material_index].name=='Team' for f in faces)
                groups.append((area*(8 if team else 1),component))
            assert len(groups)>1,('Cannot simplify without losing silhouette',name,level)
            _,small=min(groups,key=lambda q:q[0])
            bmesh.ops.delete(bm,geom=list(small),context='VERTS')
            bm.to_mesh(o.data);bm.free();o.data.update()
    if kind=='landmark':
        dims=lods[0].dimensions
        sockets={'socket-door':(0,-dims.y*.50,0),'socket-rally':(0,-dims.y*.57,0),
                 'socket-banner':(0,0,dims.z),'socket-drop':(dims.x*.40,-dims.y*.40,0)}
        for i,(x,y) in enumerate([(-1,-1),(1,-1),(-1,1),(1,1)],1):
            sockets['socket-fire-'+str(i)]=(x*dims.x*.30,y*dims.y*.30,dims.z*.55)
        for socket,pos in sockets.items():
            o=bpy.data.objects.new(socket,None);scene.collection.objects.link(o);o.parent=root;o.location=pos
    # Keep the source free of the render studio.
    bpy.ops.wm.save_as_mainfile(filepath=str(out/(name+'.blend')))
    bpy.ops.export_scene.gltf(filepath=str(out/(name+'.glb')),export_format='GLB',
        export_apply=True,export_yup=True,export_image_format='WEBP',export_image_quality=90,
        export_cameras=False,export_lights=False,export_all_vertex_colors=False)
    runpy.run_path(str(OLD/'glb-utils.py'))['alpha_mask'](out/(name+'.glb'))
    for o in lods[1:]:o.hide_render=True
    # Standard landscape preview. Studio objects never enter the asset files.
    scene.render.resolution_x=844;scene.render.resolution_y=390;scene.render.resolution_percentage=100
    scene.cycles.samples=32;scene.cycles.adaptive_threshold=.06
    scene.view_settings.view_transform='AgX';scene.view_settings.exposure=.7
    world=bpy.data.worlds.new('DeliverySky');world.use_nodes=True;scene.world=world
    world.node_tree.nodes['Background'].inputs['Color'].default_value=(.776,.855,.93,1)
    world.node_tree.nodes['Background'].inputs['Strength'].default_value=.65
    def light(name,kind,pos,power,color,size=None):
        data=bpy.data.lights.new(name,kind);data.energy=power;data.color=color
        if size is not None:data.size=size
        o=bpy.data.objects.new(name,data);scene.collection.objects.link(o);o.location=pos
        o.rotation_euler=(-o.location).to_track_quat('-Z','Y').to_euler();return o
    sun=light('PreviewSun','SUN',(22,10,38),2.4,(1,.799,.54));sun.data.angle=math.radians(2)
    light('PreviewGroundBounce','AREA',(0,-2,.10),30,(.102,.080,.05),4)
    dims=lods[0].dimensions;target=Vector((0,0,dims.z*.43))
    cam=bpy.data.objects.new('PreviewCamera',bpy.data.cameras.new('PreviewCamera'));scene.collection.objects.link(cam)
    cam.location=target+Vector((1,-1,1.25)).normalized()*max(6,max(dims)*5)
    cam.rotation_euler=(target-cam.location).to_track_quat('-Z','Y').to_euler();cam.data.type='ORTHO'
    projected_height=(dims.x+dims.y)*.38+dims.z*.75
    basis=cam.rotation_euler.to_matrix()
    points=[basis.transposed() @ (lods[0].matrix_world @ Vector(c)-cam.location) for c in lods[0].bound_box]
    low=[min(p[i] for p in points) for i in range(2)];high=[max(p[i] for p in points) for i in range(2)]
    cam.data.ortho_scale=max(high[0]-low[0],(high[1]-low[1])*844/390)*1.13
    cam.location+=basis @ Vector(((low[0]+high[0])/2,(low[1]+high[1])/2,0))
    scene.camera=cam;scene.render.film_transparent=True
    scene.render.image_settings.file_format='PNG';scene.render.filepath=str(out/'preview.png')
    bpy.ops.render.render(write_still=True)
    rec={'item':item,'id':name,'target_path':game_path,'kind':kind,'source':'Existing authored Blender model',
         'atlas':[2048,2048],'images':['basecolor','normal','orm'],
         'ao':'Source actual Cycles per-corner AO baked into unique basecolour UVs once; vertex RGB removed',
         'triangles':[helper.tris(o) for o in lods], 'preview':[844,390]}
    (out/'delivery.json').write_text(json.dumps(rec,indent=2))
    print('FINISHED_BACKLOG',name,flush=True)

if __name__=='__main__':
    args=sys.argv[sys.argv.index('--')+1:]
    finish(args[0])
