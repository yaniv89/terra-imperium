import bpy,sys,importlib.util,json,runpy
from pathlib import Path
ROOT=Path('/workspace/art-production/backlog')
OLD=Path('/workspace/blender-delivery/all-remaining')
REF=Path('/workspace/terra-imperium/scripts/blender')
for name in sys.argv[sys.argv.index('--')+1:]:
    out=ROOT/name
    rec=json.loads((out/'delivery.json').read_text());kind=rec['kind']
    bpy.ops.wm.open_mainfile(filepath=str(out/(name+'.blend')))
    spec=importlib.util.spec_from_file_location('fix_importer',REF/'import_model.py')
    helper=importlib.util.module_from_spec(spec);spec.loader.exec_module(helper)
    lods=[bpy.data.objects[x] for x in ['LOD0','LOD1','LOD2']]
    # Many independent bevelled props cannot collapse to an arbitrarily small
    # budget. Remove the least important disconnected details at distant LODs.
    # Keep Team features and the large structural volumes preferentially.
    for level,o in enumerate(lods):
        target=helper.BUDGETS[kind][level]
        while helper.tris(o)>target:
            import bmesh
            bm=bmesh.new();bm.from_mesh(o.data)
            seen=set();groups=[]
            for v in bm.verts:
                if v in seen:continue
                stack=[v];component=set();seen.add(v)
                while stack:
                    q=stack.pop();component.add(q)
                    for e in q.link_edges:
                        z=e.other_vert(q)
                        if z not in seen:seen.add(z);stack.append(z)
                faces={f for q in component for f in q.link_faces}
                area=sum(f.calc_area() for f in faces)
                team=any(o.data.materials[f.material_index].name=='Team' for f in faces)
                groups.append((area*(8 if team else 1),component))
            assert len(groups)>1,('Cannot simplify without losing silhouette',name,level)
            _,small=min(groups,key=lambda q:q[0])
            bmesh.ops.delete(bm,geom=list(small),context='VERTS')
            bm.to_mesh(o.data);bm.free();o.data.update()
    bpy.ops.wm.save_as_mainfile(filepath=str(out/(name+'.blend')))
    bpy.ops.export_scene.gltf(filepath=str(out/(name+'.glb')),export_format='GLB',export_apply=True,export_yup=True,export_image_format='WEBP',export_image_quality=90,export_cameras=False,export_lights=False,export_all_vertex_colors=False)
    runpy.run_path(str(OLD/'glb-utils.py'))['alpha_mask'](out/(name+'.glb'))
    rec['triangles']=[helper.tris(o) for o in lods];(out/'delivery.json').write_text(json.dumps(rec,indent=2))
    print('LOD_REPAIRED',name,rec['triangles'],flush=True)
