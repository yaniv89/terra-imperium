import bpy,sys,runpy,json
from pathlib import Path
import numpy as np
r=Path('/workspace/art-production/backlog');out=r/'iron_foundry';name='iron_foundry'
bpy.ops.wm.open_mainfile(filepath=str(out/(name+'.blend')))
o=bpy.data.objects['LOD0'];scene=bpy.context.scene
scene.render.engine='CYCLES';scene.cycles.samples=1;scene.cycles.use_denoising=False
scene.render.threads_mode='FIXED';scene.render.threads=1
bpy.ops.object.select_all(action='DESELECT');o.select_set(True);bpy.context.view_layer.objects.active=o
mask=bpy.data.images.new('temporary-town-tone-mask',width=2048,height=2048,alpha=True);mask.colorspace_settings.name='Non-Color'
nodes_to_remove=[]
for m in o.data.materials:
 n,l=m.node_tree.nodes,m.node_tree.links
 final=next(x for x in n if x.type=='OUTPUT_MATERIAL')
 e=n.new('ShaderNodeEmission');e.inputs['Color'].default_value=(1,1,1,1) if m.name=='Town' else (0,0,0,1)
 l.new(e.outputs[0],final.inputs['Surface'])
 t=n.new('ShaderNodeTexImage');t.image=mask;n.active=t;nodes_to_remove.append((m,e,t))
bpy.ops.object.bake(type='EMIT')
base=bpy.data.images['delivery-basecolor'];a=np.empty(2048*2048*4,np.float32);b=np.empty_like(a)
base.pixels.foreach_get(a);mask.pixels.foreach_get(b);a=a.reshape(-1,4);b=b.reshape(-1,4)
# Lift only the original dark foundry timber/charcoal atlas islands. Neutral Team
# cloth, alpha, normal and ORM stay intact; baked AO contrast stays in basecolour.
a[:,:3]*=1+3*np.clip(b[:,0:1],0,1);a[:,:3]=np.minimum(a[:,:3],1)
base.pixels.foreach_set(a.ravel());base.update();base.filepath_raw=str(out/'basecolor.png');base.file_format='PNG';base.save();base.pack()
for m,e,t in nodes_to_remove:
 n,l=m.node_tree.nodes,m.node_tree.links
 bs=next(x for x in n if x.type=='BSDF_PRINCIPLED');final=next(x for x in n if x.type=='OUTPUT_MATERIAL')
 l.new(bs.outputs[0],final.inputs['Surface']);n.remove(e);n.remove(t)
bpy.data.images.remove(mask)
bpy.ops.wm.save_as_mainfile(filepath=str(out/(name+'.blend')))
bpy.ops.export_scene.gltf(filepath=str(out/(name+'.glb')),export_format='GLB',export_apply=True,export_yup=True,export_image_format='WEBP',export_image_quality=90,export_cameras=False,export_lights=False)
rec=json.loads((out/'delivery.json').read_text());rec['tone_revision']='Town texture islands lifted 4x in linear light to meet integration tone floor; Team/alpha/normal/ORM unchanged.';(out/'delivery.json').write_text(json.dumps(rec,indent=2))
print('FOUNDRY_TONE_CORRECTED',flush=True)
