from pathlib import Path
import subprocess,json,os
r=Path(__file__).parent
items=json.loads(Path('/workspace/blender-delivery/all-remaining/checkpoint-14-items.json').read_text())
for item in items:
    ident=item.split('/')[-1]
    if '/improvements/' in item:ident+='-'+('bronze' if item.split('/')[-2]=='ancient' else item.split('/')[-2])
    out=r/ident
    report=out/(ident+'.validation.json')
    if report.exists() and json.loads(report.read_text())['passed']:continue
    out.mkdir(exist_ok=True)
    with (out/'build.log').open('w') as f:
        p=subprocess.run(['blender','-b','-t','1','--python',str(r/'finish_model.py'),'--',item],stdout=f,stderr=subprocess.STDOUT)
    log=(out/'build.log').read_text()
    if p.returncode or 'Traceback (most recent call last)' in log:raise RuntimeError(item+' '+log[-2000:])
    print('BUILT',ident,flush=True)
    with (out/'validate.log').open('w') as f:
        p=subprocess.run(['python','/workspace/wave1/reference/scripts/blender/validate_model.py',str(out/(ident+'.glb')),str(out), 'improvement' if '/improvements/' in item else 'landmark'],stdout=f,stderr=subprocess.STDOUT)
    assert p.returncode==0,(ident,(out/'validate.log').read_text()[-1500:])
    print('VALIDATED',ident,flush=True)
