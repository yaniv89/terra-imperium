# Wave 1 Bronze unit design handoff

Eight original reference-sheet prompts are in `prompts.json`: one shared neutral body and seven base roles. These are written designs, not generated images or completed models. Parent owns the image-generation calls after the 25-item backlog. The latest user instruction, **2D sheets first for every new model, continue without approval**, supersedes the pasted assignment's earlier instruction to skip sheets. This sidecar changes no plans, code, queues, or production assets.

## Current contracts

Read the new assignment at `/workspace/attachments/42348c40-4436-4d6c-a862-d642ec41e550/Pasted text.txt`, `/workspace/wave1/reference/plans/ART-MODELS-PLAN.md` sections 1, 2 and 4, the units README, `plans/art/AGENT_BRIEF.md`, and `scripts/blender/ti_town.py` / `ti_bronze.py`. All reference paths below are relative to `/workspace/wave1/reference`.

The look is the delivered town family: stylized, warm, clean volumes, flat shading and readable equipment at roughly 30 px. Units use flat material colors without textures or atlases. This is not the superseded realistic-v3 direction and not the old outlined three-paint resource-icon style. Avoid cute faces, muscular anatomy, photographic rendering, ornamental clutter and detailed weave or grain. Use gentle faceted planes and color boundaries rather than black contour strokes. Ordinary Bronze units are culture-neutral, not a costume assigned to a named civilization; signatures belong to another track.

Each sheet is 2048 × 2048 pixels, hence 2048 wide: a plain warm-white background, four equal spacious panels in a 2×2 layout, front / right side / true top / front-right three-quarter in reading order. No labels, dimension text, borders, grids, cast shadows or scenery. Orthographic views and orthographic-like three-quarter use identical scale, equipment, pose and assembly; top view must genuinely look down on the assembled object. Keep 80 px outer clear space. A narrow bottom strip holds up to three isolated tool or gear views, separate from the four assembled views. These are not extra crew or alternative designs. Sheet slots use one common scale per sheet; machinery may occupy more width than a person. Do not independently stretch or shrink a panel to fill its space.

The shared average adult is an original proposed design at 6.5 head-heights, shoulder width 0.26H, simplified mitt hands, a neutral face and a relaxed A-pose with arms about 25 degrees from the torso. H is the standing human height; H = 1.0 in unit exports. Human proportions stay identical across roles and crews. The master wears plain shorts for modesty, has no equipment or team identity, and is approximately 900 triangles. Slim, broad and robed builds remain later derivatives, not additional deliveries here. Six skin tones are shader-owned; one preview hue is not a new canonical skin-tone palette.

## Palette and material separation

`ti_bronze.py` draws on the town modules. Flat preview colors below sample `ti_town.make_materials`; procedural texture features in that module are deliberately not transferred to units.

| Surface | Preview color | Status |
|---|---|---|
| Team cloth and standards | #BFBFBF | Required neutral team material |
| Undyed linen | #D8D2C4 | Existing linen palette |
| Bronze | #A07834 | Existing bronze palette; matte, not gold |
| Main timber | #957250 | Existing log palette |
| Dark timber / mane preview | #6B4F33 | Existing timber palette |
| Blank shield face | #D6C7A6 | Existing plaster hue proposed for Emblem preview |
| Pottery | #A8623A | Existing terracotta palette |
| Skin | #C58F68 | Proposed single preview hue; shader owns final tones |
| Leather and hide covering | #9C744C | Proposed preview hue, not a canonical kit color |
| Horse coat | #957250 | Palette-derived preview only |
| Ox coat | #CDBD9A | Palette-derived preview only |

Canonical person material tags are `Team`, `Skin`, `Emblem`, `Metal`, `Wood`, `Leather`, `Cloth`. Leave shield faces blank for runtime heraldry, standards blank for team recoloring. Team remains neutral grey in every sheet, never faction red or blue. Animal hide, mane and cargo mapping still needs the forthcoming unit module's contract: these preview hues do not introduce new runtime material tags or authorize human skin recoloring on animals. Do not invent shaders to solve this in a design document.

## Role decisions and evidence

| Role | Required silhouette and gear | Historical boundary |
|---|---|---|
| Infantry | Upright 2.2 m leaf spear, round hide/wicker shield, plain conical bronze cap, leather corselet, linen kilt | Leaf spear evidence S1; shaft length and cap are plan choices, not dimensions claimed from an artifact. No Greek hoplite crest, metal cuirass or medieval shield. |
| Ranged | Tall simple self bow, back quiver, short dagger, knee-length tunic | Wooden bow S2 supports a roughly 1.5 m reference. Composite bows also existed; self bow is the base plan's deliberate choice, not a claim that Bronze peoples lacked composites. |
| Cavalry/mobile | One light chariot, exactly two horses, two six-spoke wheels, driver and archer | S3 supports Egyptian two-horse chariot architecture. Six spokes and combat crew are prescribed by the plan. Strip royal gilding, sphinx decoration and national motifs. |
| Siege | One low hide-covered ram, four wheels, four pushers, projecting suspended beam | Required gameplay reconstruction. Clear museum siege-machine references S6 are later Neo-Assyrian, not proof of a Bronze four-wheel covered ram. No Assyrian tower imported. |
| Support | One ox, two-wheel cart, one driver, two jars and two sacks | S4 supports Bronze-period cart use, not this exact traction arrangement or payload. Single ox, solid disc wheels and load arrangement are explicit original design choices. Use withers-yoke and shafts, not a modern horse collar. |
| Worker | Linen kilt, headcloth, basket, short transverse-headed mattock | S5 supports agricultural hand tools, specifically a wooden hoe. The bronze-headed mattock is prescribed generic game equipment; do not claim the hoe artifact was metal-headed. |
| General | One horse-mounted commander, neutral cloak/plume, one foot standard bearer | Requested role-driven abstraction. S7 is an Iron Age riding artifact and cannot prove this Bronze commander. Do not assert riding was universally absent in the Bronze Age. No stirrups, raised saddle, horseshoes, mail or armored horse. |

Proposed relative dimensions in JSON are modelling aids, not archaeological measurements. Infantry spear ratio uses an illustrative adult stature of 1.75 m: 2.2 / 1.75 ≈ 1.26H. Archer bow ratio similarly rounds 1.506 / 1.75 ≈ 0.86H. Animal proportions should be plausible, with clear neck, muzzle, hocks and hooves; no toy-pony heads. The general's importance comes from the mounted silhouette, cloak, plume and standard, not a giant different human body. Extra humans remain part of the same complete assembly and budget. Distinguish the ram's four crew from chariot's two and cart's one.

## Integration notes for later modelling

Use the new person skeleton: `Root`, `Hips`, `Spine`, `Chest`, `Neck`, `Head`, `Arm_L`, `Forearm_L`, `Hand_L`, `Arm_R`, `Forearm_R`, `Hand_R`, `Leg_L`, `Shin_L`, `Foot_L`, `Leg_R`, `Shin_R`, `Foot_R`, `Prop_R`, `Prop_L`, `Prop_Back`. Mounts use `Mount_Root`, `Mount_Spine`, `Mount_Neck`, `Mount_Head`, `Mount_LegFL/FR/BL/BR` with lower bones, and the `Rider` socket. Vehicles use applicable `Hull` and `Wheel_*` parts; a cart or ram does not acquire gun turret/barrel/track bones. Exact lower-leg names, multi-animal namespaces and attachment schema must come from Wave 0, not be invented in these prompts. `ti_units.py` was not present in the inspected reference tree.

In Blender use Z-up / front -Y; in glTF use +Y up / front +Z, feet on y=0. Human H=1 is the unit-file normalization, not the building 10 m scale. Keep neck, shoulders, elbows, hips and knees visibly articulated. Gear has clean separate attachments; no strap, cloak or bow-string merged across joints. Ram beam and wheels must move independently of its frame, and four human crew rig instances stay separate. Chariot horses and ox need independent mount instances. Render bone names or sockets nowhere on the sheets.

Clips are authored at **20 fps**, then VAT when Wave 0b is ready. Exact role clip lists are in JSON. Infantry uses Foot melee, archer Foot ranged, worker Worker, chariot Chariot, ram Siege engine and general Mounted plus Point-order/Rally. The plan does not specify a complete ox-cart archetype: JSON separates its proposed locomotion/driver actions from mandatory named tables. Do not import the Vehicle table's gun actions into the cart. The neutral master is a rest-body reference, not an eighth combat role needing every clip.

Units ship LOD0 only; runtime owns lower soldier LODs and impostors. Person target 1,500, cap 3,000, neutral body approximately 900. Chariot target 2,500; mounted general including bearer target 2,500; ram and cart targets 3,000 including crew and animals. The pasted assignment calls mounted 2,500 and machines 3,000 hard budgets, stricter than D1's older 4,000/5,000 maxima: retain the stricter limits here. Crew derivatives must be simplified versions of the shared topology, not full 900-triangle masters copied repeatedly beyond budget. This is a later builder allocation issue, not permission to change counts. Sheets alone cannot validate triangles, articulation or runtime behavior.

The units README's optional Mixamo/Rigify naming, 300–1,500 generic budget and procedural fallback are older integration background. New plan's named rig, class budgets and authored clips control this handoff. No borrowed source mesh, generated reference art or old image is required. Runtime destinations in JSON are proposed future deliveries, not files created by this sidecar. Shared neutral-body filename remains unassigned until the unit module defines it.

## Research sources

Museum text was researched for equipment and chronology; no images were used as authoring inputs. Sources are bounded examples from different Bronze contexts, not evidence that all eight designs coexisted as one archaeological army.

- **S1 — British Museum, 1890,1113.10:** [Socketed leaf-shaped spearhead](https://www.britishmuseum.org/collection/object/H_1890-1113-10), Late Bronze Age, approximately 1350–800 BCE, Charenton, France. Opened catalog text: copper alloy, pegged socket, leaf blade, head length 12.5 cm. Supports blade construction only.
- **S2 — Metropolitan Museum, 19.3.200:** [Wooden bow](https://www.metmuseum.org/art/collection/search/545659), Middle Kingdom–early New Kingdom, 2030–1650 BCE, Egypt; 150.6 cm tip-to-tip. Opened catalog text. Supports a simple large wooden bow.
- **S3 — Global Egyptian Museum / Egyptian Museum Cairo, JE61990A:** [Tutankhamun chariot](https://globalegyptianmuseum.org/record.aspx?id=15093&lan=E). Opened catalog text describes two-horse Egyptian architecture, linchpins and leather bindings. Ceremonial royal decoration is explicitly excluded. Six spokes are specified by the game plan, not asserted from this catalog's text.
- **S4 — British Museum, 1880.1965:** [Indus Valley cart model](https://www.britishmuseum.org/collection/object/A_1880-1965), 2500–2000 BCE. Catalog search excerpt accessed; direct catalog open returned HTTP 403. Used only for cart chronology, not precise ox harness or payload reconstruction.
- **S5 — Metropolitan Museum, 34.1.193:** [Hoe](https://www.metmuseum.org/art/collection/search/555692), Middle Kingdom, 1961–1917 BCE, wood; handle 54 cm, blade 47 cm. Opened catalog text. A wood agricultural tool, not a bronze mattock specimen.
- **S6 — British Museum, 1849,1222.23:** [Neo-Assyrian siege relief](https://www.britishmuseum.org/collection/object/W_1849-1222-23). Catalog search excerpt describes a siege engine with tower and ram; direct open returned HTTP 403. Later Iron Age comparison only. The design omits the tower and does not relabel this as Bronze evidence.
- **S7 — Metropolitan Museum, 1979.352.2:** [Horse bit cheekpiece with horse and rider](https://www.metmuseum.org/art/collection/search/326620), Iran, Iron Age II–III, 900–750 BCE. Opened catalog text. Chronological caution for the mounted general, not a Bronze cavalry reconstruction source.

Greek Classical pilos helmets and Urartian ninth–seventh-century BCE conical helmets returned by research were rejected as period evidence for this base Bronze cap. Avoid substituting their distinctive decorative details.
