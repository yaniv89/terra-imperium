# Bronze infantry sheet: equipment and modelling handoff

Visually inspected `/workspace/art-production/wave1-unit-design/bronze-infantry.png`. The accepted flat stylized family is consistent: restrained adult face, matte bronze, warm leather, undyed linen sleeves, neutral grey kilt, simple sandals and clean readable equipment. Use the accepted **6.5-head shared neutral body**, dressed with these parts; do not independently derive a new body from the helmeted silhouette or image pixel heights.

## Equipment findings

- **Spear:** straight wooden shaft, pointed broad leaf/diamond-like bronze head, visible socket collar and central ridge. These are suitable simplified socketed spear cues. Keep a modest leaf blade and socket, not an enlarged fantasy diamond or ceremonial ornament. The sheet is a shape reference, not a ruler: the visible shaft-plus-head reaches roughly 640–650 pixels against a roughly 550-pixel person estimate, about 1.16–1.18H rather than the intended 1.26H. Helmet/crown ambiguity prevents precise measurement from this image. **Written 2.2 m total spear length controls**, including blade and socket, not 2.2 m of shaft plus an added head. With the illustrative adult stature 1.75 m and exported person H=1, this is 2.2/1.75 = 1.257H, rounded 1.26H. If production chooses another physical adult stature, recalculate the ratio while retaining 2.2 m; do not shorten the weapon to fit this panel.
- **Shield:** detached face and back views establish a genuinely round shield. The carried shield's oval appearance is consistent with an angled circular plane, and the side silhouette is appropriately narrow. Model a circular face with **diameter 0.36H**, slight shallow curvature, a bound brown rim and a blank pale `Emblem` surface. Do not build an oval shield from the carried projection. Rear broad cross-supports and central grip are useful simplified structure; preserve hand clearance rather than reproducing every small wrap. The back view is a practical design choice, not a claimed uniquely documented Bronze grip system. Hide/wicker construction remains the written material intent; no full bronze shield plate or detailed weave texture.
- **Helmet:** plain conical bronze cap, no plume, cheek plates, horns or national motifs. Correct to the base plan. Its angular planes are stylistic; do not convert it into a Greek pilos/hoplite helmet or claim a specific archaeological cap type. Keep the written compact cap height around 0.09H rather than copying an unusually tall cone from the image.
- **Corselet:** brown torso protection and broad shoulder straps read as the required leather corselet. Faceted chest planes must remain leather, not separate metal plates or a muscular bronze cuirass. Sleeved undyed linen underneath is compatible with the plan. Keep arm joints unobstructed.
- **Kilt and sandals:** neutral grey knee-length kilt is the visible `Team` region; pale sleeve/neck linen is `Cloth`. Brown sandals are practical generic styling. No sword, mail, greaves, modern buckle system, smiling face or ornamental heraldry needs to be added.

This is a coherent generic Bronze gameplay kit, not proof that every detail represents one excavated army. The previously researched Late Bronze socketed leaf spear supports the spearhead concept; its small artifact dimensions do not establish this shaft length. The round hide/wicker shield, compact plain cap, leather protection and 2.2 m spear remain the plan's prescribed generic design. No historical correction requires a new sheet before proceeding to the archer.

## Written geometry contract for later build

| Element | Controlling requirement |
|---|---|
| Body | Accepted shared average adult, 6.5 head-heights, exported standing body H=1 |
| Spear | 2.2 m total; approximately 1.26H for an illustrative 1.75 m adult |
| Shield | Circular diameter 0.36H; carried angle does not change its mesh outline |
| Cap | Compact plain conical bronze cap; approximately 0.09H |
| Equipment sockets | Spear `Prop_R`, shield `Prop_L`; separate movable props |
| Materials | `Team`, `Skin`, `Emblem`, `Metal`, `Wood`, `Leather`, `Cloth`; flat colors, no texture atlas |
| Rig / animation | Current `Root` / `Hips` person rig and Foot melee clips at 20 fps; no old realistic-v3 rig |

Use front and side as the main volume guides, detached shield views for circular shape/grip and written dimensions for scale. Three-quarter is a consistency aid. The approximate downward panel is not a true orthographic construction drawing and visibly uses different framing for its weapon. Do not reconstruct body depth or spear length from that panel, bend the head to imitate it, or force hidden parts into a top projection. Parent's latest direction accepts it as an approximate concept view; no overhead image correction call is requested here.

After the **25 backlog items finish uploading**, the actual model can provide orthographic front/side/top checks at identical pixels per unit, with head upright, fixed assembly transforms and natural occlusion. At that stage verify total spear length, circular shield geometry, cap height and shared-body proportions numerically and in projection. Those are future modelling checks, not validations claimed for this image. No model, render, image edit, code, plan, queue or production-file change was performed for this review.

## Archer continuity note

For parent's next sheet retain the same accepted shared-body proportions, faceted adult face, muted preview skin and warm matte palette. Archer has an undrawn simple wooden self bow approximately 0.86H, back quiver, short sheathed dagger and neutral Team tunic, without corselet, spear, shield or conical infantry cap. Written dimensions again control the eventual mesh; a generated panel is not a measurement substitute. Existing `prompts.json` already contains the standalone archer prompt and remains unchanged.
